"use client";

import { useEffect, useMemo, useState } from "react";

type UserBrief = {
  id: string;
  username: string;
  name: string;
  role: string;
} | null;

type LedgerItem = {
  id: string;
  type: "TOPUP" | "ISSUE" | "USE" | "ADJUST";
  amount: number;
  note?: string;
  createdAt: string;
  refType?: string | null;
  refId?: string | null;
  account: UserBrief;
  user: UserBrief;
  actor: UserBrief;
};

function formatNumber(n: number) {
  return Number(n || 0).toLocaleString();
}

function typeLabel(type: string) {
  if (type === "TOPUP") return "충전";
  if (type === "ISSUE") return "지급";
  if (type === "USE") return "사용";
  if (type === "ADJUST") return "조정";
  return type;
}

function roleLabel(role?: string) {
  if (role === "CUSTOMER") return "고객";
  if (role === "PARTNER") return "제휴사";
  if (role === "ADMIN") return "총괄관리자";
  return role || "-";
}

function renderUser(user: UserBrief) {
  if (!user) return "-";
  return `${user.name} (${user.username})`;
}

function renderUserWithRole(user: UserBrief) {
  if (!user) return "-";
  return `${user.name} (${user.username}) / ${roleLabel(user.role)}`;
}

function amountText(amount: number) {
  if (amount > 0) return `+${formatNumber(amount)}P`;
  if (amount < 0) return `-${formatNumber(Math.abs(amount))}P`;
  return "0P";
}

export default function AdminLedgerPage() {
  const [items, setItems] = useState<LedgerItem[]>([]);
  const [q, setQ] = useState("");
  const [type, setType] = useState("ALL");
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");

  const queryString = useMemo(() => {
    const sp = new URLSearchParams();
    if (q.trim()) sp.set("q", q.trim());
    if (type !== "ALL") sp.set("type", type);
    return sp.toString();
  }, [q, type]);

  const stats = useMemo(() => {
    const total = items.length;
    const topup = items.filter((it) => it.type === "TOPUP").length;
    const issue = items.filter((it) => it.type === "ISSUE").length;
    const use = items.filter((it) => it.type === "USE").length;
    const adjust = items.filter((it) => it.type === "ADJUST").length;

    const positiveAmount = items
      .filter((it) => it.amount > 0)
      .reduce((sum, it) => sum + Number(it.amount || 0), 0);

    const negativeAmount = items
      .filter((it) => it.amount < 0)
      .reduce((sum, it) => sum + Math.abs(Number(it.amount || 0)), 0);

    return {
      total,
      topup,
      issue,
      use,
      adjust,
      positiveAmount,
      negativeAmount,
    };
  }, [items]);

  async function load() {
    setLoading(true);
    setMsg("");

    try {
      const url = queryString
        ? `/api/admin/ledger?${queryString}`
        : "/api/admin/ledger";

      const res = await fetch(url);
      const data = await res.json();

      if (!res.ok || !data.ok) {
        setMsg(data?.message ?? "원장 조회 실패");
        setItems([]);
        return;
      }

      setItems(data.items ?? []);
    } catch {
      setMsg("네트워크 오류");
      setItems([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  return (
    <main className="page-shell">
      <style>{`
        .page-shell {
          max-width: 1240px;
          margin: 0 auto;
          padding: 20px;
          min-height: 100vh;
          background: #f5f7fb;
          color: #111827;
        }

        .page-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 12px;
          margin-bottom: 18px;
        }

        .page-title {
          margin: 0;
          font-size: 28px;
          font-weight: 900;
          letter-spacing: -0.02em;
        }

        .page-sub {
          margin-top: 8px;
          color: #6b7280;
          font-size: 14px;
          line-height: 1.6;
        }

        .top-actions {
          display: flex;
          gap: 8px;
          flex-wrap: wrap;
        }

        .ghost-btn,
        .solid-btn,
        .back-btn,
        .type-chip {
          min-height: 44px;
          padding: 0 14px;
          border-radius: 12px;
          font-weight: 800;
          cursor: pointer;
          text-decoration: none;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          transition: all 0.15s ease;
        }

        .ghost-btn,
        .back-btn,
        .type-chip {
          border: 1px solid #d1d5db;
          background: #fff;
          color: #111827;
        }

        .solid-btn {
          border: 1px solid #111827;
          background: #111827;
          color: #fff;
        }

        .type-chip.active {
          background: #111827;
          color: #fff;
          border-color: #111827;
        }

        .filter-panel,
        .summary-card,
        .list-panel {
          background: #fff;
          border: 1px solid #e5e7eb;
          border-radius: 18px;
          box-shadow: 0 8px 24px rgba(15, 23, 42, 0.04);
        }

        .filter-panel {
          padding: 16px;
          margin-bottom: 16px;
        }

        .filter-row {
          display: flex;
          gap: 10px;
          flex-wrap: wrap;
          align-items: center;
        }

        .search-input,
        .filter-select {
          min-height: 46px;
          border: 1px solid #d1d5db;
          border-radius: 12px;
          background: #fff;
          padding: 0 14px;
          font-size: 14px;
          outline: none;
        }

        .search-input {
          flex: 1 1 320px;
        }

        .filter-select {
          min-width: 160px;
        }

        .chip-row {
          display: flex;
          gap: 8px;
          flex-wrap: wrap;
          margin-top: 12px;
        }

        .summary-grid {
          display: grid;
          grid-template-columns: repeat(4, minmax(0, 1fr));
          gap: 12px;
          margin-bottom: 16px;
        }

        .summary-card {
          padding: 16px;
        }

        .summary-card.primary {
          background: linear-gradient(135deg, #111827, #1f2937);
          border-color: #111827;
          color: #fff;
        }

        .summary-label {
          font-size: 13px;
          color: #6b7280;
        }

        .summary-card.primary .summary-label,
        .summary-card.primary .summary-sub {
          color: rgba(255,255,255,0.8);
        }

        .summary-value {
          margin-top: 8px;
          font-size: 28px;
          font-weight: 900;
          letter-spacing: -0.03em;
        }

        .summary-sub {
          margin-top: 8px;
          font-size: 13px;
          color: #6b7280;
          line-height: 1.5;
        }

        .message-box {
          margin-bottom: 14px;
          padding: 12px 14px;
          border-radius: 12px;
          border: 1px solid #d1d5db;
          background: #fff;
          font-weight: 800;
        }

        .list-panel {
          overflow: hidden;
        }

        .desktop-table {
          display: block;
          overflow-x: auto;
        }

        .table-grid {
          min-width: 1200px;
        }

        .table-head,
        .table-row {
          display: grid;
          grid-template-columns: 110px 140px 220px 220px 220px 140px 1fr 170px;
          gap: 10px;
          padding: 14px 16px;
          align-items: center;
        }

        .table-head {
          background: #f9fafb;
          border-bottom: 1px solid #e5e7eb;
          font-size: 13px;
          font-weight: 900;
          color: #374151;
        }

        .table-row {
          border-bottom: 1px solid #f1f5f9;
          font-size: 14px;
        }

        .table-row:last-child {
          border-bottom: 0;
        }

        .cell-ellipsis {
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .amount-cell {
          text-align: right;
          font-weight: 900;
        }

        .amount-plus { color: #111827; }
        .amount-minus { color: #b91c1c; }

        .type-badge {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          min-height: 32px;
          padding: 0 10px;
          border-radius: 999px;
          font-size: 12px;
          font-weight: 900;
          border: 1px solid #e5e7eb;
          background: #f3f4f6;
          color: #374151;
        }

        .mobile-list {
          display: none;
          gap: 12px;
          padding: 14px;
        }

        .mobile-card {
          border: 1px solid #e5e7eb;
          border-radius: 16px;
          padding: 14px;
          background: #fbfcfe;
        }

        .mobile-top {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 12px;
        }

        .mobile-type-wrap {
          display: flex;
          gap: 8px;
          flex-wrap: wrap;
          align-items: center;
          margin-bottom: 8px;
        }

        .mobile-title {
          font-size: 15px;
          font-weight: 900;
        }

        .mobile-sub {
          margin-top: 6px;
          font-size: 13px;
          color: #6b7280;
          line-height: 1.5;
        }

        .mobile-amount {
          font-size: 20px;
          font-weight: 900;
          white-space: nowrap;
        }

        .mobile-meta {
          margin-top: 12px;
          display: grid;
          gap: 8px;
        }

        .mobile-meta-row {
          display: flex;
          justify-content: space-between;
          gap: 12px;
          font-size: 14px;
        }

        .mobile-label {
          color: #6b7280;
          flex: 0 0 84px;
        }

        .mobile-value {
          flex: 1;
          text-align: right;
          word-break: break-word;
        }

        .empty-box {
          padding: 18px;
          text-align: center;
          color: #6b7280;
        }

        @media (max-width: 960px) {
          .summary-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
          }
        }

        @media (max-width: 760px) {
          .page-shell {
            padding: 16px;
          }

          .page-header {
            flex-direction: column;
            align-items: stretch;
          }

          .filter-row {
            flex-direction: column;
            align-items: stretch;
          }

          .search-input,
          .filter-select,
          .solid-btn,
          .ghost-btn,
          .back-btn {
            width: 100%;
          }

          .summary-grid {
            grid-template-columns: 1fr;
          }

          .desktop-table {
            display: none;
          }

          .mobile-list {
            display: grid;
          }
        }

        @media (max-width: 520px) {
          .mobile-top {
            flex-direction: column;
          }

          .mobile-amount {
            white-space: normal;
          }

          .mobile-meta-row {
            flex-direction: column;
            gap: 4px;
          }

          .mobile-value {
            text-align: left;
          }
        }
      `}</style>

      <header className="page-header">
        <div>
          <h1 className="page-title">원장 조회</h1>
          <div className="page-sub">
            포인트 전체 Ledger 이력을 조회합니다. account는 지갑 주인, actor는 실행자,
            user는 직접 대상 사용자입니다.
          </div>
        </div>

        <div className="top-actions">
          <button onClick={load} className="ghost-btn" type="button">
            새로고침
          </button>
          <a href="/admin" className="back-btn">
            대시보드로
          </a>
        </div>
      </header>

      <section className="filter-panel">
        <div className="filter-row">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="계정 사용자 이름 또는 아이디 검색"
            className="search-input"
          />

          <select
            value={type}
            onChange={(e) => setType(e.target.value)}
            className="filter-select"
          >
            <option value="ALL">전체 유형</option>
            <option value="TOPUP">TOPUP / 충전</option>
            <option value="ISSUE">ISSUE / 지급</option>
            <option value="USE">USE / 사용</option>
            <option value="ADJUST">ADJUST / 조정</option>
          </select>

          <button onClick={load} className="solid-btn" type="button">
            조회
          </button>
        </div>

        <div className="chip-row">
          {["ALL", "TOPUP", "ISSUE", "USE", "ADJUST"].map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => setType(t)}
              className={`type-chip ${type === t ? "active" : ""}`}
            >
              {t === "ALL" ? "전체" : typeLabel(t)}
            </button>
          ))}
        </div>
      </section>

      <section className="summary-grid">
        <div className="summary-card primary">
          <div className="summary-label">조회 건수</div>
          <div className="summary-value">{formatNumber(stats.total)}건</div>
          <div className="summary-sub">
            충전 {formatNumber(stats.topup)} / 지급 {formatNumber(stats.issue)} / 사용{" "}
            {formatNumber(stats.use)} / 조정 {formatNumber(stats.adjust)}
          </div>
        </div>

        <div className="summary-card">
          <div className="summary-label">유입 포인트 합계</div>
          <div className="summary-value">{formatNumber(stats.positiveAmount)}P</div>
          <div className="summary-sub">양수 amount 기준</div>
        </div>

        <div className="summary-card">
          <div className="summary-label">유출 포인트 합계</div>
          <div className="summary-value">{formatNumber(stats.negativeAmount)}P</div>
          <div className="summary-sub">음수 amount 절대값 기준</div>
        </div>

        <div className="summary-card">
          <div className="summary-label">조회 상태</div>
          <div className="summary-value">{loading ? "조회중" : "완료"}</div>
          <div className="summary-sub">필터 변경 후 다시 조회 버튼 실행</div>
        </div>
      </section>

      {msg && <div className="message-box">{msg}</div>}

      <section className="list-panel">
        {loading ? (
          <div className="empty-box">불러오는 중...</div>
        ) : items.length === 0 ? (
          <div className="empty-box">조회된 원장 데이터가 없습니다.</div>
        ) : (
          <>
            <div className="desktop-table">
              <div className="table-grid">
                <div className="table-head">
                  <div>유형</div>
                  <div className="amount-cell">금액</div>
                  <div>지갑 주인(account)</div>
                  <div>직접 대상(user)</div>
                  <div>실행자(actor)</div>
                  <div>참조</div>
                  <div>메모</div>
                  <div>생성시각</div>
                </div>

                {items.map((it) => (
                  <div key={it.id} className="table-row">
                    <div>
                      <span className="type-badge">{typeLabel(it.type)}</span>
                    </div>

                    <div
                      className={`amount-cell ${
                        it.amount < 0 ? "amount-minus" : "amount-plus"
                      }`}
                    >
                      {amountText(it.amount)}
                    </div>

                    <div className="cell-ellipsis">{renderUserWithRole(it.account)}</div>
                    <div className="cell-ellipsis">{renderUserWithRole(it.user)}</div>
                    <div className="cell-ellipsis">{renderUserWithRole(it.actor)}</div>

                    <div className="cell-ellipsis">
                      {it.refType || "-"}
                      {it.refId ? ` / ${it.refId}` : ""}
                    </div>

                    <div className="cell-ellipsis">{it.note || "-"}</div>

                    <div className="cell-ellipsis">
                      {it.createdAt ? new Date(it.createdAt).toLocaleString() : "-"}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="mobile-list">
              {items.map((it) => (
                <article key={it.id} className="mobile-card">
                  <div className="mobile-top">
                    <div>
                      <div className="mobile-type-wrap">
                        <span className="type-badge">{typeLabel(it.type)}</span>
                      </div>
                      <div className="mobile-title">{renderUser(it.account)}</div>
                      <div className="mobile-sub">
                        지갑 주인 역할: {it.account ? roleLabel(it.account.role) : "-"}
                      </div>
                    </div>

                    <div
                      className={`mobile-amount ${
                        it.amount < 0 ? "amount-minus" : "amount-plus"
                      }`}
                    >
                      {amountText(it.amount)}
                    </div>
                  </div>

                  <div className="mobile-meta">
                    <div className="mobile-meta-row">
                      <span className="mobile-label">직접 대상</span>
                      <span className="mobile-value">{renderUserWithRole(it.user)}</span>
                    </div>

                    <div className="mobile-meta-row">
                      <span className="mobile-label">실행자</span>
                      <span className="mobile-value">{renderUserWithRole(it.actor)}</span>
                    </div>

                    <div className="mobile-meta-row">
                      <span className="mobile-label">참조</span>
                      <span className="mobile-value">
                        {it.refType || "-"}
                        {it.refId ? ` / ${it.refId}` : ""}
                      </span>
                    </div>

                    <div className="mobile-meta-row">
                      <span className="mobile-label">메모</span>
                      <span className="mobile-value">{it.note || "-"}</span>
                    </div>

                    <div className="mobile-meta-row">
                      <span className="mobile-label">생성시각</span>
                      <span className="mobile-value">
                        {it.createdAt ? new Date(it.createdAt).toLocaleString() : "-"}
                      </span>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </>
        )}
      </section>
    </main>
  );
}