// src/app/admin/fee-policies/page.tsx
// =======================================================
// ADMIN: 수수료 정책 관리 페이지
// -------------------------------------------------------
// ✔ 업체(PARTNER) 수수료 계약 등록/수정/종료/삭제
// ✔ 기간(startAt~endAt) 기반
// ✔ endAt 비움 => 무기한
// ✔ 검색(q): 업체 아이디/이름
// =======================================================

"use client";

import { useEffect, useMemo, useState } from "react";

type AdminUserItem = {
  id: string;
  username: string;
  name: string;
  role: string; // PARTNER | ...
  status?: string;
};

type FeePolicyItem = {
  id: string;
  feeRate: number; // 0~1
  startAt: string;
  endAt?: string | null;
  note?: string;
  counterparty: { id: string; username: string; name: string; role: string } | null;
  createdAt?: string;
  updatedAt?: string;
};

function formatPercent(rate: number) {
  const n = Number(rate ?? 0) * 100;
  return `${n.toFixed(2)}%`;
}

function toYmd(d: Date) {
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

function toInputDate(v: string | Date | null | undefined) {
  if (!v) return "";
  const d = typeof v === "string" ? new Date(v) : v;
  if (Number.isNaN(d.getTime())) return "";
  return toYmd(d);
}

export default function AdminFeePoliciesPage() {
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");

  const [items, setItems] = useState<FeePolicyItem[]>([]);

  // 업체 리스트 (PARTNER)
  const [users, setUsers] = useState<AdminUserItem[]>([]);
  const [usersMsg, setUsersMsg] = useState("");

  // 생성 폼
  const [counterpartyId, setCounterpartyId] = useState("");
  const [feeRatePct, setFeeRatePct] = useState("3"); // "3" => 3%
  const [startAt, setStartAt] = useState(toYmd(new Date()));
  const [endAt, setEndAt] = useState("");
  const [note, setNote] = useState("");

  const queryKey = useMemo(() => q.trim(), [q]);

  async function loadUsers() {
    // 기존에 이미 있는 /api/admin/users 재사용
    setUsersMsg("");
    try {
      const res = await fetch("/api/admin/users");
      const data = await res.json();
      if (!res.ok) {
        setUsersMsg(data?.message ?? "사용자 목록 조회 실패");
        return;
      }
      const all: AdminUserItem[] = data?.items ?? [];
      const counterparties = all.filter((u) => u.role === "PARTNER");
      setUsers(counterparties);
      // 기본 선택
      if (!counterpartyId && counterparties.length > 0) {
        setCounterpartyId(counterparties[0].id);
      }
    } catch {
      setUsersMsg("네트워크 오류");
    }
  }

  async function loadPolicies() {
    setLoading(true);
    setMsg("");
    try {
      const params = new URLSearchParams();
      if (q.trim()) params.set("q", q.trim());

      const url = `/api/admin/fee-policies${params.toString() ? `?${params.toString()}` : ""}`;
      const res = await fetch(url);
      const data = await res.json();
      if (!res.ok) {
        setMsg(data?.message ?? "조회 실패");
        setItems([]);
        return;
      }
      setItems(data?.items ?? []);
    } catch {
      setMsg("네트워크 오류");
      setItems([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadUsers();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const t = setTimeout(() => loadPolicies(), 250);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [queryKey]);

  function pctToRate(pctText: string) {
    const n = Number(String(pctText).replace(/[^\d.]/g, ""));
    if (!Number.isFinite(n)) return NaN;
    return n / 100;
  }

  async function createPolicy() {
    setMsg("");

    if (!counterpartyId) {
      setMsg("업체를 선택하세요.");
      return;
    }

    const rate = pctToRate(feeRatePct);
    if (!Number.isFinite(rate) || rate < 0 || rate > 1) {
      setMsg("수수료율(%)이 올바르지 않습니다. 예: 3, 5.5");
      return;
    }

    if (!startAt) {
      setMsg("시작일을 입력하세요.");
      return;
    }

    try {
      const res = await fetch("/api/admin/fee-policies", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          counterpartyId,
          feeRate: rate,
          startAt: new Date(`${startAt}T00:00:00`).toISOString(),
          endAt: endAt ? new Date(`${endAt}T23:59:59`).toISOString() : null,
          note: note.trim(),
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setMsg(data?.message ?? "등록 실패");
        return;
      }

      setMsg("✅ 수수료 정책이 등록되었습니다.");
      setNote("");
      loadPolicies();
    } catch {
      setMsg("네트워크 오류");
    }
  }

  async function updatePolicy(id: string, patch: any) {
    setMsg("");
    try {
      const res = await fetch(`/api/admin/fee-policies/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(patch),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setMsg(data?.message ?? "수정 실패");
        return false;
      }
      return true;
    } catch {
      setMsg("네트워크 오류");
      return false;
    }
  }

  async function deletePolicy(id: string) {
    if (!confirm("정말 삭제할까요?")) return;
    setMsg("");
    try {
      const res = await fetch(`/api/admin/fee-policies/${id}`, { method: "DELETE" });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setMsg(data?.message ?? "삭제 실패");
        return;
      }
      setMsg("✅ 삭제되었습니다.");
      loadPolicies();
    } catch {
      setMsg("네트워크 오류");
    }
  }

  function chip(on: boolean): React.CSSProperties {
    return {
      padding: "8px 14px",
      borderRadius: 999,
      border: "1px solid #ccc",
      background: on ? "#111" : "#f5f5f5",
      color: on ? "#fff" : "#111",
      fontWeight: 900,
      cursor: "pointer",
    };
  }

  return (
    <main style={{ maxWidth: 1200, margin: "40px auto", padding: 16 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12 }}>
        <h1 style={{ fontSize: 24, fontWeight: 900 }}>수수료 정책 관리</h1>

        <div style={{ display: "flex", gap: 8 }}>
          <a
            href="/admin"
            style={{
              padding: "10px 14px",
              borderRadius: 12,
              border: "1px solid #ccc",
              background: "#f5f5f5",
              fontWeight: 900,
              textDecoration: "none",
              color: "#111",
            }}
          >
            대시보드로
          </a>
          <button
            onClick={() => {
              loadUsers();
              loadPolicies();
            }}
            style={{
              padding: "10px 14px",
              borderRadius: 12,
              border: "1px solid #ccc",
              background: "#f5f5f5",
              fontWeight: 900,
              cursor: "pointer",
            }}
          >
            새로고침
          </button>
        </div>
      </div>

      <p style={{ marginTop: 10, opacity: 0.75 }}>
        업체(제휴사)별 수수료율을 기간 계약으로 관리합니다. (정산 마감 시 해당 기간의 정책이 자동 적용)
      </p>

      <hr style={{ margin: "20px 0" }} />

      {/* 생성 폼 */}
      <section style={{ border: "1px solid #ddd", borderRadius: 14, padding: 14, background: "#fafafa" }}>
        <div style={{ fontWeight: 900, marginBottom: 10 }}>새 수수료 정책 등록</div>

        {usersMsg && <p style={{ marginTop: 6, color: "tomato", fontWeight: 800 }}>{usersMsg}</p>}

        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
          <label style={{ display: "grid", gap: 6 }}>
            <span style={{ fontWeight: 900, opacity: 0.8 }}>업체</span>
            <select
              value={counterpartyId}
              onChange={(e) => setCounterpartyId(e.target.value)}
              style={{ padding: 10, borderRadius: 10, border: "1px solid #ccc", minWidth: 260 }}
            >
              {users.map((u) => (
                <option key={u.id} value={u.id}>
                  [{u.role}] {u.name} ({u.username})
                </option>
              ))}
            </select>
          </label>

          <label style={{ display: "grid", gap: 6 }}>
            <span style={{ fontWeight: 900, opacity: 0.8 }}>수수료율(%)</span>
            <input
              value={feeRatePct}
              onChange={(e) => setFeeRatePct(e.target.value)}
              placeholder="예: 3 또는 5.5"
              inputMode="decimal"
              style={{ padding: 10, borderRadius: 10, border: "1px solid #ccc", width: 160, fontWeight: 900 }}
            />
          </label>

          <label style={{ display: "grid", gap: 6 }}>
            <span style={{ fontWeight: 900, opacity: 0.8 }}>시작일</span>
            <input
              type="date"
              value={startAt}
              onChange={(e) => setStartAt(e.target.value)}
              style={{ padding: 10, borderRadius: 10, border: "1px solid #ccc" }}
            />
          </label>

          <label style={{ display: "grid", gap: 6 }}>
            <span style={{ fontWeight: 900, opacity: 0.8 }}>종료일(선택)</span>
            <input
              type="date"
              value={endAt}
              onChange={(e) => setEndAt(e.target.value)}
              style={{ padding: 10, borderRadius: 10, border: "1px solid #ccc" }}
            />
          </label>

          <button
            onClick={createPolicy}
            style={{
              padding: "12px 14px",
              borderRadius: 12,
              border: "1px solid #111",
              background: "#111",
              color: "#fff",
              fontWeight: 900,
              cursor: "pointer",
              marginTop: 22,
            }}
          >
            등록
          </button>
        </div>

        <div style={{ marginTop: 12, display: "grid", gap: 6 }}>
          <div style={{ fontWeight: 900, opacity: 0.85 }}>메모(선택)</div>
          <input
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="예: 2026년 1분기 계약"
            style={{ padding: 10, borderRadius: 10, border: "1px solid #ccc" }}
          />
        </div>

        {msg && <p style={{ marginTop: 10, fontWeight: 900 }}>{msg}</p>}
      </section>

      <hr style={{ margin: "22px 0" }} />

      {/* 검색 */}
      <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="업체 검색 (아이디/이름)"
          style={{
            flex: "1 1 320px",
            padding: 10,
            borderRadius: 10,
            border: "1px solid #ccc",
          }}
        />
        <div style={{ opacity: 0.75, fontWeight: 900 }}>{loading ? "불러오는 중..." : `표시 ${items.length}건`}</div>
      </div>

      {/* 목록 */}
      <div style={{ marginTop: 12, border: "1px solid #ddd", borderRadius: 12, overflow: "hidden" }}>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "260px 120px 140px 140px 1fr 170px",
            padding: 12,
            background: "#f5f5f5",
            fontWeight: 900,
            columnGap: 10,
          }}
        >
          <div>업체</div>
          <div>수수료율</div>
          <div>시작일</div>
          <div>종료일</div>
          <div>메모</div>
          <div>관리</div>
        </div>

        {items.map((it) => (
          <PolicyRow
            key={it.id}
            item={it}
            onUpdate={async (patch) => {
              const ok = await updatePolicy(it.id, patch);
              if (ok) {
                setMsg("✅ 수정되었습니다.");
                loadPolicies();
              }
            }}
            onDelete={() => deletePolicy(it.id)}
          />
        ))}

        {!loading && items.length === 0 && (
          <div style={{ padding: 16, textAlign: "center", opacity: 0.7 }}>정책이 없습니다.</div>
        )}
      </div>
    </main>
  );
}

function PolicyRow({
  item,
  onUpdate,
  onDelete,
}: {
  item: FeePolicyItem;
  onUpdate: (patch: any) => void;
  onDelete: () => void;
}) {
  const [feePct, setFeePct] = useState(String(((item.feeRate ?? 0) * 100).toFixed(2)));
  const [startAt, setStartAt] = useState(toInputDate(item.startAt));
  const [endAt, setEndAt] = useState(toInputDate(item.endAt ?? null));
  const [note, setNote] = useState(item.note ?? "");

  function pctToRate(pctText: string) {
    const n = Number(String(pctText).replace(/[^\d.]/g, ""));
    if (!Number.isFinite(n)) return NaN;
    return n / 100;
  }

  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "260px 120px 140px 140px 1fr 170px",
        padding: 12,
        borderTop: "1px solid #eee",
        columnGap: 10,
        alignItems: "center",
      }}
    >
      <div style={{ fontWeight: 900 }}>
        {item.counterparty ? `${item.counterparty.name} (${item.counterparty.username})` : "-"}
        <div style={{ opacity: 0.6, fontSize: 12 }}>{item.counterparty ? `[${item.counterparty.role}]` : ""}</div>
      </div>

      <div>
        <input
          value={feePct}
          onChange={(e) => setFeePct(e.target.value)}
          inputMode="decimal"
          style={{
            width: "50%",
            padding: 8,
            borderRadius: 10,
            border: "1px solid #ccc",
            fontWeight: 900,
            textAlign: "right",
          }}
        />
      </div>

      <div>
        <input
          type="date"
          value={startAt}
          onChange={(e) => setStartAt(e.target.value)}
          style={{ width: "70%", padding: 8, borderRadius: 10, border: "1px solid #ccc" }}
        />
      </div>

      <div>
        <input
          type="date"
          value={endAt}
          onChange={(e) => setEndAt(e.target.value)}
          style={{ width: "70%", padding: 8, borderRadius: 10, border: "1px solid #ccc" }}
        />
      </div>

      <div>
        <input
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="메모"
          style={{ width: "60%", padding: 8, borderRadius: 10, border: "1px solid #ccc" }}
        />
      </div>

      <div style={{ display: "flex", gap: 8 }}>
        <button
          onClick={() => {
            const rate = pctToRate(feePct);
            if (!Number.isFinite(rate) || rate < 0 || rate > 1) {
              alert("수수료율(%)이 올바르지 않습니다.");
              return;
            }
            if (!startAt) {
              alert("시작일이 필요합니다.");
              return;
            }

            onUpdate({
              feeRate: rate,
              startAt: new Date(`${startAt}T00:00:00`).toISOString(),
              endAt: endAt ? new Date(`${endAt}T23:59:59`).toISOString() : null,
              note: note.trim(),
            });
          }}
          style={{
            padding: "8px 12px",
            borderRadius: 10,
            border: "1px solid #111",
            background: "#111",
            color: "#fff",
            fontWeight: 900,
            cursor: "pointer",
          }}
        >
          저장
        </button>

        <button
          onClick={onDelete}
          style={{
            padding: "8px 12px",
            borderRadius: 10,
            border: "1px solid #ccc",
            background: "#f5f5f5",
            fontWeight: 900,
            cursor: "pointer",
          }}
        >
          삭제
        </button>
      </div>
    </div>
  );
}