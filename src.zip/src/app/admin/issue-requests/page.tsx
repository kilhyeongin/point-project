"use client";

import { useEffect, useMemo, useState } from "react";

type Item = {
  id: string;
  status: "PENDING" | "APPROVED" | "REJECTED";
  amount: number;
  note?: string;
  createdAt: string;
  decidedAt?: string | null;
  ledgerId?: string | null;
  requester: {
    id: string;
    username: string;
    name: string;
    role: string;
  } | null;
  customer: {
    id: string;
    username: string;
    name: string;
    role: string;
  } | null;
};

function formatNumber(n: number) {
  return Number(n || 0).toLocaleString();
}

function statusLabel(status: string) {
  if (status === "APPROVED") return "지급완료";
  if (status === "PENDING") return "대기";
  if (status === "REJECTED") return "거절";
  return status;
}

function roleLabel(role?: string) {
  if (role === "PARTNER") return "제휴사";
  if (role === "CUSTOMER") return "고객";
  if (role === "ADMIN") return "총괄관리자";
  return role || "-";
}

export default function AdminIssueRequestsPage() {
  const [items, setItems] = useState<Item[]>([]);
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("ALL");
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");

  const queryString = useMemo(() => {
    const sp = new URLSearchParams();
    if (q.trim()) sp.set("q", q.trim());
    if (status !== "ALL") sp.set("status", status);
    return sp.toString();
  }, [q, status]);

  const approvedCount = useMemo(
    () => items.filter((it) => it.status === "APPROVED").length,
    [items]
  );

  const totalAmount = useMemo(
    () => items.reduce((sum, it) => sum + Number(it.amount || 0), 0),
    [items]
  );

  async function load() {
    setLoading(true);
    setMsg("");

    try {
      const url = queryString
        ? `/api/admin/issue-requests?${queryString}`
        : "/api/admin/issue-requests";

      const res = await fetch(url);
      const data = await res.json();

      if (!res.ok || !data.ok) {
        setMsg(data?.message ?? "지급 이력 조회 실패");
        setItems([]);
        return;
      }

      setItems(data.items ?? []);
    } catch {
      setMsg("네트워크 오류");
      setItems([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  return (
    <main className="page-shell">
      <style>{`
        .page-shell {
          max-width: 1140px;
          margin: 0 auto;
          padding: 20px;
          min-height: 100vh;
          background: #f5f7fb;
          color: #111827;
        }

        .page-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 12px;
          margin-bottom: 18px;
        }

        .page-title {
          margin: 0;
          font-size: 28px;
          font-weight: 900;
          letter-spacing: -0.02em;
        }

        .page-sub {
          margin-top: 8px;
          color: #6b7280;
          font-size: 14px;
          line-height: 1.6;
        }

        .top-actions {
          display: flex;
          gap: 8px;
          flex-wrap: wrap;
        }

        .ghost-btn,
        .solid-btn,
        .back-btn {
          min-height: 44px;
          padding: 0 14px;
          border-radius: 12px;
          font-weight: 800;
          cursor: pointer;
          text-decoration: none;
          display: inline-flex;
          align-items: center;
          justify-content: center;
        }

        .ghost-btn,
        .back-btn {
          border: 1px solid #d1d5db;
          background: #fff;
          color: #111827;
        }

        .solid-btn {
          border: 1px solid #111827;
          background: #111827;
          color: #fff;
        }

        .filter-panel,
        .summary-card,
        .list-panel {
          background: #fff;
          border: 1px solid #e5e7eb;
          border-radius: 18px;
          box-shadow: 0 8px 24px rgba(15, 23, 42, 0.04);
        }

        .filter-panel {
          padding: 16px;
          margin-bottom: 16px;
        }

        .filter-row {
          display: flex;
          gap: 10px;
          flex-wrap: wrap;
          align-items: center;
        }

        .search-input,
        .filter-select {
          min-height: 46px;
          border: 1px solid #d1d5db;
          border-radius: 12px;
          background: #fff;
          padding: 0 14px;
          font-size: 14px;
          outline: none;
        }

        .search-input {
          flex: 1 1 320px;
        }

        .filter-select {
          min-width: 140px;
        }

        .summary-grid {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 12px;
          margin-bottom: 16px;
        }

        .summary-card {
          padding: 16px;
        }

        .summary-label {
          font-size: 13px;
          color: #6b7280;
        }

        .summary-value {
          margin-top: 8px;
          font-size: 28px;
          font-weight: 900;
          letter-spacing: -0.03em;
        }

        .summary-sub {
          margin-top: 8px;
          font-size: 13px;
          color: #6b7280;
        }

        .message-box {
          margin-bottom: 14px;
          padding: 12px 14px;
          border-radius: 12px;
          border: 1px solid #d1d5db;
          background: #fff;
          font-weight: 800;
        }

        .list-panel {
          overflow: hidden;
        }

        .desktop-table {
          display: block;
          overflow-x: auto;
        }

        .table-grid {
          min-width: 980px;
        }

        .table-head,
        .table-row {
          display: grid;
          grid-template-columns: 180px 180px 120px 110px 1fr 170px;
          gap: 10px;
          padding: 14px 16px;
          align-items: center;
        }

        .table-head {
          background: #f9fafb;
          border-bottom: 1px solid #e5e7eb;
          font-size: 13px;
          font-weight: 900;
          color: #374151;
        }

        .table-row {
          border-bottom: 1px solid #f1f5f9;
          font-size: 14px;
        }

        .table-row:last-child {
          border-bottom: 0;
        }

        .cell-ellipsis {
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .amount-cell {
          text-align: right;
          font-weight: 900;
        }

        .mobile-list {
          display: none;
          gap: 12px;
          padding: 14px;
        }

        .mobile-card {
          border: 1px solid #e5e7eb;
          border-radius: 16px;
          padding: 14px;
          background: #fbfcfe;
        }

        .mobile-top {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 12px;
        }

        .mobile-title {
          font-size: 15px;
          font-weight: 900;
        }

        .mobile-sub {
          margin-top: 6px;
          font-size: 13px;
          color: #6b7280;
          line-height: 1.5;
        }

        .mobile-amount {
          font-size: 20px;
          font-weight: 900;
          white-space: nowrap;
        }

        .mobile-meta {
          margin-top: 12px;
          display: grid;
          gap: 8px;
        }

        .mobile-meta-row {
          display: flex;
          justify-content: space-between;
          gap: 12px;
          font-size: 14px;
        }

        .mobile-label {
          color: #6b7280;
        }

        .empty-box {
          padding: 18px;
          text-align: center;
          color: #6b7280;
        }

        @media (max-width: 760px) {
          .page-shell {
            padding: 16px;
          }

          .page-header {
            flex-direction: column;
            align-items: stretch;
          }

          .filter-row {
            flex-direction: column;
            align-items: stretch;
          }

          .search-input,
          .filter-select,
          .solid-btn,
          .ghost-btn,
          .back-btn {
            width: 100%;
          }

          .summary-grid {
            grid-template-columns: 1fr;
          }

          .desktop-table {
            display: none;
          }

          .mobile-list {
            display: grid;
          }
        }

        @media (max-width: 520px) {
          .mobile-top {
            flex-direction: column;
          }

          .mobile-amount {
            white-space: normal;
          }
        }
      `}</style>

      <header className="page-header">
        <div>
          <h1 className="page-title">고객 포인트 지급 이력</h1>
          <div className="page-sub">
            고객 포인트 지급은 제휴사가 잔액 범위 내에서 즉시 실행합니다.
            이 화면은 관리자 승인 화면이 아니라 조회/감사용 이력 화면입니다.
          </div>
        </div>

        <div className="top-actions">
          <button onClick={load} className="ghost-btn" type="button">
            조회
          </button>
          <a href="/admin" className="back-btn">
            대시보드로
          </a>
        </div>
      </header>

      <section className="filter-panel">
        <div className="filter-row">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="고객 이름 또는 아이디 검색"
            className="search-input"
          />

          <select
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            className="filter-select"
          >
            <option value="ALL">전체 상태</option>
            <option value="APPROVED">지급완료</option>
            <option value="PENDING">대기</option>
            <option value="REJECTED">거절</option>
          </select>

          <button onClick={load} className="solid-btn" type="button">
            조회
          </button>
        </div>
      </section>

      <section className="summary-grid">
        <div className="summary-card">
          <div className="summary-label">조회 건수</div>
          <div className="summary-value">{formatNumber(items.length)}건</div>
          <div className="summary-sub">현재 필터 기준</div>
        </div>

        <div className="summary-card">
          <div className="summary-label">지급완료 건수</div>
          <div className="summary-value">{formatNumber(approvedCount)}건</div>
          <div className="summary-sub">APPROVED 기준</div>
        </div>

        <div className="summary-card">
          <div className="summary-label">조회 합계 포인트</div>
          <div className="summary-value">{formatNumber(totalAmount)}P</div>
          <div className="summary-sub">현재 목록 합산</div>
        </div>
      </section>

      {msg && <div className="message-box">{msg}</div>}

      <section className="list-panel">
        {loading ? (
          <div className="empty-box">불러오는 중...</div>
        ) : items.length === 0 ? (
          <div className="empty-box">조회된 지급 이력이 없습니다.</div>
        ) : (
          <>
            <div className="desktop-table">
              <div className="table-grid">
                <div className="table-head">
                  <div>지급자</div>
                  <div>고객</div>
                  <div className="amount-cell">포인트</div>
                  <div>상태</div>
                  <div>메모</div>
                  <div>실행시각</div>
                </div>

                {items.map((it) => (
                  <div key={it.id} className="table-row">
                    <div className="cell-ellipsis">
                      {it.requester
                        ? `${it.requester.name} (${it.requester.username})`
                        : "-"}
                    </div>

                    <div className="cell-ellipsis">
                      {it.customer
                        ? `${it.customer.name} (${it.customer.username})`
                        : "-"}
                    </div>

                    <div className="amount-cell">
                      {formatNumber(it.amount)}P
                    </div>

                    <div className="cell-ellipsis">{statusLabel(it.status)}</div>

                    <div className="cell-ellipsis">{it.note || "-"}</div>

                    <div className="cell-ellipsis">
                      {it.createdAt ? new Date(it.createdAt).toLocaleString() : "-"}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="mobile-list">
              {items.map((it) => (
                <article key={it.id} className="mobile-card">
                  <div className="mobile-top">
                    <div>
                      <div className="mobile-title">
                        {it.customer
                          ? `${it.customer.name} (${it.customer.username})`
                          : "고객 정보 없음"}
                      </div>
                      <div className="mobile-sub">
                        지급자:{" "}
                        {it.requester
                          ? `${it.requester.name} (${it.requester.username})`
                          : "-"}
                        <br />
                        지급자 역할: {roleLabel(it.requester?.role)}
                      </div>
                    </div>

                    <div className="mobile-amount">{formatNumber(it.amount)}P</div>
                  </div>

                  <div className="mobile-meta">
                    <div className="mobile-meta-row">
                      <span className="mobile-label">상태</span>
                      <span>{statusLabel(it.status)}</span>
                    </div>

                    <div className="mobile-meta-row">
                      <span className="mobile-label">실행시각</span>
                      <span>
                        {it.createdAt
                          ? new Date(it.createdAt).toLocaleString()
                          : "-"}
                      </span>
                    </div>

                    <div className="mobile-meta-row">
                      <span className="mobile-label">메모</span>
                      <span>{it.note || "-"}</span>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </>
        )}
      </section>
    </main>
  );
}