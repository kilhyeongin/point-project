"use client";

import type { CSSProperties } from "react";
import { useEffect, useMemo, useState } from "react";

type CategoryItem = {
  id: string;
  code: string;
  name: string;
  description: string;
  isActive: boolean;
  isVisibleToPartner: boolean;
  isVisibleToCustomer: boolean;
  sortOrder: number;
};

const EMPTY_FORM = {
  id: "",
  code: "",
  name: "",
  description: "",
  isActive: true,
  isVisibleToPartner: true,
  isVisibleToCustomer: true,
  sortOrder: 0,
};

export default function AdminPartnerCategoriesPage() {
  const [items, setItems] = useState<CategoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");
  const [form, setForm] = useState(EMPTY_FORM);
  const [keyword, setKeyword] = useState("");

  async function load() {
    setLoading(true);
    setMsg("");

    try {
      const res = await fetch("/api/admin/partner-categories", {
        cache: "no-store",
      });
      const data = await res.json();

      if (!res.ok || !data?.ok) {
        setMsg(data?.error ?? "카테고리 목록을 불러오지 못했습니다.");
        setItems([]);
        return;
      }

      setItems(Array.isArray(data.items) ? data.items : []);
    } catch {
      setMsg("네트워크 오류");
      setItems([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  function resetForm() {
    setForm(EMPTY_FORM);
  }

  async function save() {
    setSaving(true);
    setMsg("");

    try {
      const targetUrl = form.id
        ? `/api/admin/partner-categories/${form.id}`
        : "/api/admin/partner-categories";

      const method = form.id ? "PUT" : "POST";

      const res = await fetch(targetUrl, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });

      const data = await res.json();

      if (!res.ok || !data?.ok) {
        setMsg(data?.error ?? "저장하지 못했습니다.");
        return;
      }

      setItems(Array.isArray(data.items) ? data.items : []);
      setMsg(data?.message ?? "저장되었습니다.");
      resetForm();
    } catch {
      setMsg("네트워크 오류");
    } finally {
      setSaving(false);
    }
  }

  const filtered = useMemo(() => {
    const q = keyword.trim().toLowerCase();
    if (!q) return items;

    return items.filter((item) =>
      [item.code, item.name, item.description].some((value) =>
        String(value).toLowerCase().includes(q)
      )
    );
  }, [items, keyword]);

  return (
    <main style={{ display: "grid", gap: 20 }}>
      <section
        style={{
          border: "1px solid #e5e7eb",
          borderRadius: 18,
          background: "#fff",
          padding: 20,
          boxShadow: "0 4px 16px rgba(15,23,42,0.04)",
        }}
      >
        <h1 style={{ margin: 0, fontSize: 28, fontWeight: 900 }}>
          카테고리 관리
        </h1>
        <p style={{ marginTop: 10, color: "#4b5563", lineHeight: 1.6 }}>
          총괄 관리자가 고객/제휴사 화면에 노출할 카테고리를 직접 등록하고 제어합니다.
        </p>
      </section>

      <section
        style={{
          border: "1px solid #e5e7eb",
          borderRadius: 18,
          background: "#fff",
          padding: 20,
          boxShadow: "0 4px 16px rgba(15,23,42,0.04)",
          display: "grid",
          gap: 14,
        }}
      >
        <div style={{ fontSize: 18, fontWeight: 900 }}>
          {form.id ? "카테고리 수정" : "카테고리 등록"}
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr 1fr 1fr",
            gap: 12,
          }}
        >
          <input
            value={form.code}
            onChange={(e) =>
              setForm((prev) => ({ ...prev, code: e.target.value.toUpperCase() }))
            }
            placeholder="코드 (예: DRESS)"
            style={inputStyle}
          />
          <input
            value={form.name}
            onChange={(e) =>
              setForm((prev) => ({ ...prev, name: e.target.value }))
            }
            placeholder="카테고리명"
            style={inputStyle}
          />
          <input
            value={form.sortOrder}
            onChange={(e) =>
              setForm((prev) => ({
                ...prev,
                sortOrder: Number(e.target.value) || 0,
              }))
            }
            placeholder="정렬순서"
            style={inputStyle}
          />
        </div>

        <textarea
          value={form.description}
          onChange={(e) =>
            setForm((prev) => ({ ...prev, description: e.target.value }))
          }
          placeholder="설명"
          style={{ ...inputStyle, minHeight: 96, paddingTop: 12 }}
        />

        <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
          <label>
            <input
              type="checkbox"
              checked={form.isActive}
              onChange={(e) =>
                setForm((prev) => ({ ...prev, isActive: e.target.checked }))
              }
            />{" "}
            사용
          </label>

          <label>
            <input
              type="checkbox"
              checked={form.isVisibleToPartner}
              onChange={(e) =>
                setForm((prev) => ({
                  ...prev,
                  isVisibleToPartner: e.target.checked,
                }))
              }
            />{" "}
            제휴사 노출
          </label>

          <label>
            <input
              type="checkbox"
              checked={form.isVisibleToCustomer}
              onChange={(e) =>
                setForm((prev) => ({
                  ...prev,
                  isVisibleToCustomer: e.target.checked,
                }))
              }
            />{" "}
            고객 노출
          </label>
        </div>

        <div style={{ display: "flex", gap: 10 }}>
          <button onClick={save} disabled={saving} style={primaryButton}>
            {saving ? "저장 중..." : "저장"}
          </button>
          <button onClick={resetForm} style={secondaryButton}>
            초기화
          </button>
        </div>
      </section>

      <section
        style={{
          border: "1px solid #e5e7eb",
          borderRadius: 18,
          background: "#fff",
          padding: 20,
          boxShadow: "0 4px 16px rgba(15,23,42,0.04)",
          display: "grid",
          gap: 14,
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            gap: 12,
            flexWrap: "wrap",
          }}
        >
          <input
            value={keyword}
            onChange={(e) => setKeyword(e.target.value)}
            placeholder="코드 / 이름 / 설명 검색"
            style={{ ...inputStyle, maxWidth: 360 }}
          />
          <button onClick={load} style={secondaryButton}>
            새로고침
          </button>
        </div>

        {msg ? (
          <div
            style={{
              padding: 12,
              borderRadius: 12,
              border: "1px solid #e5e7eb",
              background: "#f9fafb",
              fontWeight: 700,
            }}
          >
            {msg}
          </div>
        ) : null}

        <div style={{ color: "#6b7280", fontWeight: 700 }}>
          {loading ? "불러오는 중..." : `총 ${filtered.length}개`}
        </div>

        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ background: "#f9fafb" }}>
                {["코드", "카테고리명", "제휴사", "고객", "사용", "정렬", "관리"].map(
                  (head) => (
                    <th key={head} style={thtd}>
                      {head}
                    </th>
                  )
                )}
              </tr>
            </thead>
            <tbody>
              {filtered.map((item) => (
                <tr key={item.id}>
                  <td style={thtd}>{item.code}</td>
                  <td style={thtd}>
                    <strong>{item.name}</strong>
                    <div style={{ color: "#6b7280", marginTop: 4 }}>
                      {item.description || "-"}
                    </div>
                  </td>
                  <td style={thtd}>{item.isVisibleToPartner ? "노출" : "숨김"}</td>
                  <td style={thtd}>{item.isVisibleToCustomer ? "노출" : "숨김"}</td>
                  <td style={thtd}>{item.isActive ? "사용" : "중지"}</td>
                  <td style={thtd}>{item.sortOrder}</td>
                  <td style={thtd}>
                    <button
                      onClick={() => setForm(item)}
                      style={secondaryButton}
                    >
                      수정
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </main>
  );
}

const inputStyle: CSSProperties = {
  height: 44,
  borderRadius: 12,
  border: "1px solid #d1d5db",
  padding: "0 12px",
  background: "#fff",
};

const primaryButton: CSSProperties = {
  height: 44,
  padding: "0 16px",
  borderRadius: 12,
  border: "1px solid #111827",
  background: "#111827",
  color: "#fff",
  fontWeight: 800,
  cursor: "pointer",
};

const secondaryButton: CSSProperties = {
  height: 44,
  padding: "0 16px",
  borderRadius: 12,
  border: "1px solid #d1d5db",
  background: "#fff",
  color: "#111827",
  fontWeight: 800,
  cursor: "pointer",
};

const thtd: CSSProperties = {
  borderBottom: "1px solid #e5e7eb",
  padding: 12,
  textAlign: "left",
  verticalAlign: "top",
};