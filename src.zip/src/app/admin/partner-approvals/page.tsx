"use client";

import { useEffect, useMemo, useState } from "react";

type ApprovalItem = {
  id: string;
  username: string;
  name: string;
  role: string;
  status: string;
  createdAt?: string;
  partnerProfile?: {
    businessName?: string;
    contactName?: string;
    contactPhone?: string;
    address?: string;
    detailAddress?: string;
  };
};

function formatDate(value?: string) {
  if (!value) return "-";

  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return "-";

  return d.toLocaleString("ko-KR");
}

export default function AdminPartnerApprovalsPage() {
  const [items, setItems] = useState<ApprovalItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [approvingId, setApprovingId] = useState("");
  const [keyword, setKeyword] = useState("");
  const [msg, setMsg] = useState("");

  async function load() {
    setLoading(true);
    setMsg("");

    try {
      const res = await fetch("/api/admin/partner-approvals", {
        cache: "no-store",
      });
      const data = await res.json();

      if (!res.ok || !data?.ok) {
        setMsg(data?.message ?? data?.error ?? "승인대기 제휴사 목록을 불러오지 못했습니다.");
        setItems([]);
        return;
      }

      setItems(Array.isArray(data?.items) ? data.items : []);
    } catch {
      setMsg("네트워크 오류가 발생했습니다.");
      setItems([]);
    } finally {
      setLoading(false);
    }
  }

  async function approvePartner(userId: string) {
    const ok = window.confirm("이 제휴사 계정을 승인할까요?");
    if (!ok) return;

    setApprovingId(userId);
    setMsg("");

    try {
      const res = await fetch("/api/admin/users/approve", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ userId }),
      });

      const data = await res.json();

      if (!res.ok || !data?.ok) {
        window.alert(data?.error ?? "승인 처리에 실패했습니다.");
        return;
      }

      window.alert(data?.message ?? "승인되었습니다.");
      await load();
    } catch {
      window.alert("네트워크 오류가 발생했습니다.");
    } finally {
      setApprovingId("");
    }
  }

  useEffect(() => {
    load();
  }, []);

  const filteredItems = useMemo(() => {
    const q = keyword.trim().toLowerCase();
    if (!q) return items;

    return items.filter((item) => {
      const businessName = String(item.partnerProfile?.businessName ?? "").toLowerCase();
      const contactName = String(item.partnerProfile?.contactName ?? "").toLowerCase();
      const username = String(item.username ?? "").toLowerCase();
      const name = String(item.name ?? "").toLowerCase();
      const phone = String(item.partnerProfile?.contactPhone ?? "").toLowerCase();
      const address = String(item.partnerProfile?.address ?? "").toLowerCase();

      return (
        businessName.includes(q) ||
        contactName.includes(q) ||
        username.includes(q) ||
        name.includes(q) ||
        phone.includes(q) ||
        address.includes(q)
      );
    });
  }, [items, keyword]);

  return (
    <main style={pageStyle}>
      <section style={heroCardStyle}>
        <div>
          <div style={eyebrowStyle}>총괄관리자</div>
          <h1 style={titleStyle}>제휴사 승인</h1>
          <p style={descStyle}>
            가입 후 승인대기 상태로 등록된 제휴사 계정을 확인하고 승인할 수 있습니다.
          </p>
        </div>

        <div style={summaryCardStyle}>
          <div style={summaryLabelStyle}>승인대기 제휴사</div>
          <div style={summaryValueStyle}>
            {loading ? "-" : `${filteredItems.length}개`}
          </div>
        </div>
      </section>

      <section style={panelStyle}>
        <div style={toolbarStyle}>
          <input
            value={keyword}
            onChange={(e) => setKeyword(e.target.value)}
            placeholder="업체명 / 담당자명 / 아이디 / 전화번호 / 주소 검색"
            style={inputStyle}
          />

          <button type="button" onClick={load} style={refreshButtonStyle}>
            새로고침
          </button>
        </div>

        {msg ? <div style={messageStyle}>{msg}</div> : null}

        {loading ? (
          <div style={emptyBoxStyle}>불러오는 중...</div>
        ) : filteredItems.length === 0 ? (
          <div style={emptyBoxStyle}>승인대기 중인 제휴사가 없습니다.</div>
        ) : (
          <div style={cardGridStyle}>
            {filteredItems.map((item) => {
              const businessName =
                String(item.partnerProfile?.businessName ?? "").trim() ||
                item.name ||
                "-";

              const contactName =
                String(item.partnerProfile?.contactName ?? "").trim() || "-";

              const contactPhone =
                String(item.partnerProfile?.contactPhone ?? "").trim() || "-";

              const address =
                [item.partnerProfile?.address, item.partnerProfile?.detailAddress]
                  .filter(Boolean)
                  .join(" ")
                  .trim() || "-";

              return (
                <article key={item.id} style={approvalCardStyle}>
                  <div style={cardTopStyle}>
                    <div>
                      <div style={businessNameStyle}>{businessName}</div>
                      <div style={subTextStyle}>아이디: {item.username}</div>
                    </div>

                    <span style={pendingChipStyle}>승인대기</span>
                  </div>

                  <div style={infoGridStyle}>
                    <InfoRow label="담당자명" value={contactName} />
                    <InfoRow label="연락처" value={contactPhone} />
                    <InfoRow label="주소" value={address} />
                    <InfoRow label="가입일시" value={formatDate(item.createdAt)} />
                  </div>

                  <div style={buttonRowStyle}>
                    <button
                      type="button"
                      onClick={() => approvePartner(item.id)}
                      disabled={approvingId === item.id}
                      style={approveButtonStyle}
                    >
                      {approvingId === item.id ? "처리 중..." : "승인"}
                    </button>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>
    </main>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div style={infoRowStyle}>
      <div style={infoLabelStyle}>{label}</div>
      <div style={infoValueStyle}>{value}</div>
    </div>
  );
}

const pageStyle: React.CSSProperties = {
  display: "grid",
  gap: 20,
};

const heroCardStyle: React.CSSProperties = {
  border: "1px solid #e5e7eb",
  borderRadius: 20,
  background: "#fff",
  padding: 24,
  display: "flex",
  justifyContent: "space-between",
  alignItems: "flex-start",
  gap: 16,
  flexWrap: "wrap",
};

const eyebrowStyle: React.CSSProperties = {
  fontSize: 12,
  fontWeight: 800,
  color: "#6b7280",
  marginBottom: 8,
};

const titleStyle: React.CSSProperties = {
  margin: 0,
  fontSize: 28,
  fontWeight: 900,
  color: "#111827",
};

const descStyle: React.CSSProperties = {
  marginTop: 10,
  color: "#4b5563",
  lineHeight: 1.6,
};

const summaryCardStyle: React.CSSProperties = {
  minWidth: 180,
  border: "1px solid #e5e7eb",
  borderRadius: 16,
  background: "#f9fafb",
  padding: 16,
};

const summaryLabelStyle: React.CSSProperties = {
  color: "#6b7280",
  fontSize: 13,
  fontWeight: 700,
};

const summaryValueStyle: React.CSSProperties = {
  marginTop: 8,
  color: "#111827",
  fontSize: 24,
  fontWeight: 900,
};

const panelStyle: React.CSSProperties = {
  border: "1px solid #e5e7eb",
  borderRadius: 20,
  background: "#fff",
  padding: 20,
  display: "grid",
  gap: 14,
};

const toolbarStyle: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "1fr 120px",
  gap: 10,
};

const inputStyle: React.CSSProperties = {
  height: 44,
  borderRadius: 12,
  border: "1px solid #d1d5db",
  padding: "0 12px",
  background: "#fff",
};

const refreshButtonStyle: React.CSSProperties = {
  height: 44,
  borderRadius: 12,
  border: "1px solid #111827",
  background: "#111827",
  color: "#fff",
  fontWeight: 800,
  cursor: "pointer",
};

const messageStyle: React.CSSProperties = {
  padding: 12,
  borderRadius: 12,
  border: "1px solid #fecaca",
  background: "#fef2f2",
  color: "#991b1b",
  fontWeight: 700,
};

const emptyBoxStyle: React.CSSProperties = {
  border: "1px dashed #d1d5db",
  borderRadius: 16,
  padding: 24,
  textAlign: "center",
  color: "#6b7280",
  background: "#fafafa",
};

const cardGridStyle: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))",
  gap: 14,
};

const approvalCardStyle: React.CSSProperties = {
  border: "1px solid #e5e7eb",
  borderRadius: 18,
  background: "#fff",
  padding: 18,
  display: "grid",
  gap: 16,
  boxShadow: "0 4px 16px rgba(15,23,42,0.04)",
};

const cardTopStyle: React.CSSProperties = {
  display: "flex",
  justifyContent: "space-between",
  alignItems: "flex-start",
  gap: 12,
};

const businessNameStyle: React.CSSProperties = {
  fontSize: 20,
  fontWeight: 900,
  color: "#111827",
};

const subTextStyle: React.CSSProperties = {
  marginTop: 6,
  color: "#6b7280",
  fontWeight: 700,
  fontSize: 13,
};

const pendingChipStyle: React.CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  height: 32,
  padding: "0 12px",
  borderRadius: 999,
  background: "#fff7ed",
  color: "#9a3412",
  border: "1px solid #fdba74",
  fontSize: 12,
  fontWeight: 800,
  whiteSpace: "nowrap",
};

const infoGridStyle: React.CSSProperties = {
  display: "grid",
  gap: 10,
};

const infoRowStyle: React.CSSProperties = {
  border: "1px solid #f1f5f9",
  borderRadius: 12,
  padding: 12,
  background: "#f9fafb",
};

const infoLabelStyle: React.CSSProperties = {
  fontSize: 12,
  fontWeight: 800,
  color: "#6b7280",
  marginBottom: 6,
};

const infoValueStyle: React.CSSProperties = {
  color: "#111827",
  lineHeight: 1.6,
  wordBreak: "break-word",
};

const buttonRowStyle: React.CSSProperties = {
  display: "flex",
  justifyContent: "flex-end",
};

const approveButtonStyle: React.CSSProperties = {
  height: 40,
  padding: "0 16px",
  borderRadius: 12,
  border: "1px solid #111827",
  background: "#111827",
  color: "#fff",
  fontWeight: 800,
  cursor: "pointer",
};