"use client";

import { useEffect, useMemo, useState } from "react";

type Item = {
  id: string;
  status: string;
  amount: number;
  note?: string;
  createdAt: string;
  to: { username: string; name: string } | null;
  requester: { username: string; name: string } | null;
};

function formatNumber(n: number) {
  return Number(n || 0).toLocaleString();
}

function statusLabel(status?: string) {
  if (status === "PENDING") return "대기";
  if (status === "APPROVED") return "승인";
  if (status === "REJECTED") return "거절";
  return status || "-";
}

export default function UseRequestsPage() {
  const [items, setItems] = useState<Item[]>([]);
  const [msg, setMsg] = useState("");
  const [loading, setLoading] = useState(false);
  const [workingKey, setWorkingKey] = useState<string | null>(null);

  const pendingCount = useMemo(
    () => items.filter((it) => it.status === "PENDING").length,
    [items]
  );

  async function load() {
    setLoading(true);
    setMsg("");

    try {
      const res = await fetch("/api/admin/use-requests");
      const data = await res.json();

      if (res.ok) {
        setItems(data.items || []);
      } else {
        setItems([]);
        setMsg(data?.message ?? "목록 조회 실패");
      }
    } catch {
      setItems([]);
      setMsg("네트워크 오류");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function decide(id: string, action: "APPROVE" | "REJECT") {
    setMsg("");
    setWorkingKey(`${id}-${action}`);

    try {
      const res = await fetch(`/api/admin/use-requests/${id}/decide`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action }),
      });

      const data = await res.json();

      if (!res.ok) {
        setMsg(data?.message ?? "처리 실패");
        return;
      }

      setMsg(`${action === "APPROVE" ? "승인" : "거절"} 완료`);
      await load();
    } catch {
      setMsg("네트워크 오류");
    } finally {
      setWorkingKey(null);
    }
  }

  return (
    <main className="page-shell">
      <style>{`
        .page-shell {
          max-width: 1100px;
          margin: 0 auto;
          padding: 20px;
          min-height: 100vh;
          background: #f5f7fb;
          color: #111827;
        }

        .page-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 12px;
          margin-bottom: 18px;
        }

        .page-title {
          margin: 0;
          font-size: 28px;
          font-weight: 900;
          letter-spacing: -0.02em;
        }

        .page-sub {
          margin-top: 8px;
          color: #6b7280;
          font-size: 14px;
          line-height: 1.6;
        }

        .top-actions {
          display: flex;
          gap: 8px;
          flex-wrap: wrap;
        }

        .ghost-btn,
        .solid-btn,
        .danger-btn,
        .back-btn {
          min-height: 44px;
          padding: 0 14px;
          border-radius: 12px;
          font-weight: 800;
          cursor: pointer;
          text-decoration: none;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          transition: all 0.15s ease;
        }

        .ghost-btn,
        .back-btn {
          border: 1px solid #d1d5db;
          background: #fff;
          color: #111827;
        }

        .solid-btn {
          border: 1px solid #111827;
          background: #111827;
          color: #fff;
        }

        .danger-btn {
          border: 1px solid #d1d5db;
          background: #f9fafb;
          color: #111827;
        }

        .summary-grid {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 12px;
          margin-bottom: 16px;
        }

        .summary-card {
          background: #fff;
          border: 1px solid #e5e7eb;
          border-radius: 18px;
          padding: 16px;
          box-shadow: 0 8px 24px rgba(15, 23, 42, 0.04);
        }

        .summary-label {
          font-size: 13px;
          color: #6b7280;
        }

        .summary-value {
          margin-top: 8px;
          font-size: 28px;
          font-weight: 900;
          letter-spacing: -0.03em;
        }

        .summary-sub {
          margin-top: 8px;
          font-size: 13px;
          color: #6b7280;
        }

        .message-box {
          margin-bottom: 14px;
          padding: 12px 14px;
          border-radius: 12px;
          border: 1px solid #d1d5db;
          background: #fff;
          font-weight: 800;
        }

        .list-wrap {
          display: grid;
          gap: 12px;
        }

        .request-card {
          background: #fff;
          border: 1px solid #e5e7eb;
          border-radius: 18px;
          padding: 16px;
          box-shadow: 0 8px 24px rgba(15, 23, 42, 0.04);
        }

        .request-top {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 16px;
        }

        .request-name {
          font-size: 17px;
          font-weight: 900;
        }

        .request-amount {
          font-size: 24px;
          font-weight: 900;
          white-space: nowrap;
          letter-spacing: -0.02em;
        }

        .meta-grid {
          margin-top: 14px;
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 10px;
        }

        .meta-box {
          border: 1px solid #eef2f7;
          border-radius: 14px;
          padding: 12px;
          background: #f9fafb;
        }

        .meta-label {
          font-size: 12px;
          color: #6b7280;
        }

        .meta-value {
          margin-top: 6px;
          font-size: 14px;
          font-weight: 700;
          line-height: 1.5;
          word-break: break-word;
        }

        .request-actions {
          margin-top: 14px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 10px;
          flex-wrap: wrap;
        }

        .button-row {
          display: flex;
          gap: 8px;
          flex-wrap: wrap;
        }

        .status-badge {
          display: inline-flex;
          align-items: center;
          min-height: 34px;
          padding: 0 12px;
          border-radius: 999px;
          font-size: 13px;
          font-weight: 900;
          background: #f3f4f6;
          color: #374151;
          border: 1px solid #e5e7eb;
        }

        .empty-box {
          padding: 18px;
          text-align: center;
          color: #6b7280;
          border: 1px dashed #cbd5e1;
          border-radius: 16px;
          background: #fff;
        }

        @media (max-width: 760px) {
          .page-shell {
            padding: 16px;
          }

          .page-header {
            flex-direction: column;
            align-items: stretch;
          }

          .summary-grid {
            grid-template-columns: 1fr;
          }

          .request-top {
            flex-direction: column;
          }

          .request-amount {
            white-space: normal;
          }

          .meta-grid {
            grid-template-columns: 1fr;
          }

          .request-actions {
            flex-direction: column;
            align-items: stretch;
          }

          .button-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
          }

          .solid-btn,
          .ghost-btn,
          .danger-btn,
          .back-btn {
            width: 100%;
          }
        }

        @media (max-width: 520px) {
          .button-row {
            grid-template-columns: 1fr;
          }
        }
      `}</style>

      <header className="page-header">
        <div>
          <h1 className="page-title">사용요청 승인</h1>
          <div className="page-sub">
            승인 시에만 Ledger에 USE(-포인트)가 기록되며, 잔액 부족이면 승인할 수 없습니다.
          </div>
        </div>

        <div className="top-actions">
          <button onClick={load} className="ghost-btn" type="button">
            새로고침
          </button>
          <a href="/admin" className="back-btn">
            대시보드로
          </a>
        </div>
      </header>

      <section className="summary-grid">
        <div className="summary-card">
          <div className="summary-label">전체 요청</div>
          <div className="summary-value">{formatNumber(items.length)}건</div>
          <div className="summary-sub">현재 조회된 사용 요청</div>
        </div>

        <div className="summary-card">
          <div className="summary-label">승인 대기</div>
          <div className="summary-value">{formatNumber(pendingCount)}건</div>
          <div className="summary-sub">처리 필요 요청 수</div>
        </div>

        <div className="summary-card">
          <div className="summary-label">로딩 상태</div>
          <div className="summary-value">{loading ? "조회중" : "완료"}</div>
          <div className="summary-sub">목록 불러오기 상태</div>
        </div>
      </section>

      {msg && <div className="message-box">{msg}</div>}

      <section className="list-wrap">
        {loading ? (
          <div className="empty-box">불러오는 중...</div>
        ) : items.length === 0 ? (
          <div className="empty-box">승인 대기 요청이 없습니다.</div>
        ) : (
          items.map((it) => (
            <article key={it.id} className="request-card">
              <div className="request-top">
                <div>
                  <div className="request-name">
                    대상 고객: {it.to?.name ?? "-"} ({it.to?.username ?? "-"})
                  </div>
                </div>

                <div className="request-amount">{formatNumber(it.amount)}P</div>
              </div>

              <div className="meta-grid">
                <div className="meta-box">
                  <div className="meta-label">요청자(제휴사)</div>
                  <div className="meta-value">
                    {it.requester
                      ? `${it.requester.name} (${it.requester.username})`
                      : "-"}
                  </div>
                </div>

                <div className="meta-box">
                  <div className="meta-label">상태</div>
                  <div className="meta-value">{statusLabel(it.status)}</div>
                </div>

                <div className="meta-box">
                  <div className="meta-label">요청일</div>
                  <div className="meta-value">
                    {it.createdAt ? new Date(it.createdAt).toLocaleString() : "-"}
                  </div>
                </div>

                <div className="meta-box">
                  <div className="meta-label">메모</div>
                  <div className="meta-value">{it.note || "-"}</div>
                </div>
              </div>

              <div className="request-actions">
                <span className="status-badge">{statusLabel(it.status)}</span>

                <div className="button-row">
                  <button
                    onClick={() => decide(it.id, "APPROVE")}
                    className="solid-btn"
                    type="button"
                    disabled={workingKey === `${it.id}-APPROVE`}
                  >
                    {workingKey === `${it.id}-APPROVE` ? "처리 중..." : "승인"}
                  </button>

                  <button
                    onClick={() => decide(it.id, "REJECT")}
                    className="danger-btn"
                    type="button"
                    disabled={workingKey === `${it.id}-REJECT`}
                  >
                    {workingKey === `${it.id}-REJECT` ? "처리 중..." : "거절"}
                  </button>
                </div>
              </div>
            </article>
          ))
        )}
      </section>
    </main>
  );
}