"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

type SessionInfo = {
  uid: string;
  username: string;
  name: string;
  role: "ADMIN";
};

type Props = {
  session: SessionInfo;
  children: React.ReactNode;
};

const MENU_ITEMS = [
  { href: "/admin", label: "대시보드" },
  { href: "/admin/accounts", label: "계정 잔액" },
  { href: "/admin/partner-approvals", label: "제휴사 승인" },
  { href: "/admin/ledger", label: "원장 조회" },
  { href: "/admin/settlements", label: "정산 관리" },
  { href: "/admin/partner-categories", label: "카테고리 관리" },
];

export default function AdminShellClient({ session, children }: Props) {
  const pathname = usePathname();

  async function handleLogout() {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
    } finally {
      window.location.href = "/login";
    }
  }

  function isActive(href: string) {
    if (href === "/admin") {
      return pathname === "/admin";
    }
    return pathname.startsWith(href);
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#f8fafc",
      }}
    >
      <header
        style={{
          position: "sticky",
          top: 0,
          zIndex: 30,
          borderBottom: "1px solid #e5e7eb",
          background: "rgba(255,255,255,0.92)",
          backdropFilter: "blur(10px)",
        }}
      >
        <div
          style={{
            maxWidth: 1280,
            margin: "0 auto",
            padding: "14px 16px",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            gap: 16,
            flexWrap: "wrap",
          }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 14,
              flexWrap: "wrap",
            }}
          >
            <Link
              href="/admin"
              style={{
                textDecoration: "none",
                color: "#111827",
                fontSize: 20,
                fontWeight: 900,
              }}
            >
              관리자 센터
            </Link>

            <div
              style={{
                fontSize: 13,
                color: "#6b7280",
                padding: "6px 10px",
                border: "1px solid #e5e7eb",
                borderRadius: 999,
                background: "#fff",
              }}
            >
              {session.name} · {session.username}
            </div>
          </div>

          <div
            style={{
              display: "flex",
              gap: 8,
              alignItems: "center",
              flexWrap: "wrap",
            }}
          >
            {MENU_ITEMS.map((item) => {
              const active = isActive(item.href);

              return (
                <Link
                  key={item.href}
                  href={item.href}
                  style={{
                    textDecoration: "none",
                    padding: "10px 14px",
                    borderRadius: 12,
                    border: active ? "1px solid #111827" : "1px solid #d1d5db",
                    background: active ? "#111827" : "#fff",
                    color: active ? "#fff" : "#111827",
                    fontWeight: 800,
                  }}
                >
                  {item.label}
                </Link>
              );
            })}

            <button
              type="button"
              onClick={handleLogout}
              style={{
                padding: "10px 14px",
                borderRadius: 12,
                border: "1px solid #d1d5db",
                background: "#fff",
                color: "#111827",
                fontWeight: 800,
                cursor: "pointer",
              }}
            >
              로그아웃
            </button>
          </div>
        </div>
      </header>

      <div
        style={{
          maxWidth: 1280,
          margin: "0 auto",
          padding: "24px 16px 40px",
        }}
      >
        {children}
      </div>
    </div>
  );
}