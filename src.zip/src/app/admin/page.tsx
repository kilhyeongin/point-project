// src/app/admin/page.tsx
// =======================================================
// ADMIN DASHBOARD
// -------------------------------------------------------
// - ADMIN 전용
// - 반응형(모바일/태블릿/PC)
// - 운영 KPI
// - 승인 대기 / 빠른 실행
// - 최근 원장 활동 / TOP 사용처
// - 사용자 관리 (PC 테이블 / 모바일 카드)
// =======================================================

import { redirect } from "next/navigation";
import mongoose from "mongoose";
import { connectDB } from "@/lib/db";
import { getSessionFromCookies } from "@/lib/auth";
import { User } from "@/models/User";
import { Ledger } from "@/models/Ledger";
import { TopupRequest } from "@/models/TopupRequest";
import { IssueRequest } from "@/models/IssueRequest";
import { UseRequest } from "@/models/UseRequest";

type Role = "CUSTOMER" | "PARTNER" | "ADMIN";
type Status = "ACTIVE" | "PENDING" | "BLOCKED";

const ROLE_LABEL: Record<Role, string> = {
  CUSTOMER: "고객",
  PARTNER: "제휴사",
  ADMIN: "총괄관리자",
};

const STATUS_LABEL: Record<Status, string> = {
  ACTIVE: "활성",
  PENDING: "대기",
  BLOCKED: "차단",
};

type SearchParams = Promise<{ role?: string; q?: string }>;

function formatNumber(n: number) {
  return Number(n || 0).toLocaleString();
}

function startOfDay(d: Date) {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate());
}

function endOfDay(d: Date) {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate(), 23, 59, 59, 999);
}

export default async function AdminDashboard({
  searchParams,
}: {
  searchParams?: SearchParams;
}) {
  const session = await getSessionFromCookies();
  if (!session) redirect("/login");
  if (session.role !== "ADMIN") redirect("/");

  const sp = searchParams ? await searchParams : undefined;
  const roleParam = String(sp?.role ?? "ALL").toUpperCase();
  const q = String(sp?.q ?? "").trim();

  const activeRole: "ALL" | Role =
    roleParam === "CUSTOMER" ||
    roleParam === "PARTNER" ||
    roleParam === "ADMIN"
      ? (roleParam as Role)
      : "ALL";

  await connectDB();

  const now = new Date();
  const todayStart = startOfDay(now);
  const todayEnd = endOfDay(now);
  const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const thisMonthEnd = new Date(
    now.getFullYear(),
    now.getMonth() + 1,
    0,
    23,
    59,
    59,
    999
  );

  const [
    pendingTopupCount,
    pendingIssueCount,
    pendingUseCount,
    totalUsers,
    customerCount,
    partnerCount,
  ] = await Promise.all([
    TopupRequest.countDocuments({ status: "PENDING" }),
    IssueRequest.countDocuments({ status: "PENDING" }),
    UseRequest.countDocuments({ status: "PENDING" }),
    User.countDocuments({}),
    User.countDocuments({ role: "CUSTOMER" }),
    User.countDocuments({ role: "PARTNER" }),
  ]);

  const [todayLedgerRows, monthLedgerRows] = await Promise.all([
    Ledger.aggregate([
      {
        $match: {
          createdAt: { $gte: todayStart, $lte: todayEnd },
        },
      },
      {
        $group: {
          _id: "$type",
          count: { $sum: 1 },
          amount: { $sum: { $abs: "$amount" } },
        },
      },
    ]),
    Ledger.aggregate([
      {
        $match: {
          createdAt: { $gte: thisMonthStart, $lte: thisMonthEnd },
        },
      },
      {
        $group: {
          _id: "$type",
          count: { $sum: 1 },
          amount: { $sum: { $abs: "$amount" } },
        },
      },
    ]),
  ]);

  const todayMap = new Map<string, { count: number; amount: number }>();
  for (const row of todayLedgerRows) {
    todayMap.set(String(row._id), {
      count: Number(row.count ?? 0),
      amount: Number(row.amount ?? 0),
    });
  }

  const monthMap = new Map<string, { count: number; amount: number }>();
  for (const row of monthLedgerRows) {
    monthMap.set(String(row._id), {
      count: Number(row.count ?? 0),
      amount: Number(row.amount ?? 0),
    });
  }

  const todayIssueAmount = todayMap.get("ISSUE")?.amount ?? 0;
  const todayUseAmount = todayMap.get("USE")?.amount ?? 0;
  const monthUseCount = monthMap.get("USE")?.count ?? 0;
  const monthUsedPoints = monthMap.get("USE")?.amount ?? 0;

  const defaultFeeRate = 0.1;
  const monthExpectedFee = Math.round(monthUsedPoints * defaultFeeRate);
  const monthExpectedPayout = monthUsedPoints - monthExpectedFee;

  const topCounterpartiesRaw = await Ledger.aggregate([
    {
      $match: {
        type: "USE",
        counterpartyId: { $ne: null },
        createdAt: { $gte: thisMonthStart, $lte: thisMonthEnd },
      },
    },
    {
      $group: {
        _id: "$counterpartyId",
        useCount: { $sum: 1 },
        usedPoints: { $sum: { $abs: "$amount" } },
      },
    },
    { $sort: { usedPoints: -1 } },
    { $limit: 5 },
  ]);

  const topCounterpartyIds = topCounterpartiesRaw.map((r) => r._id).filter(Boolean);

  const topCounterpartyUsers =
    topCounterpartyIds.length > 0
      ? await User.find(
          { _id: { $in: topCounterpartyIds } },
          { name: 1, username: 1, role: 1 }
        ).lean()
      : [];

  const topUserMap = new Map<string, any>();
  for (const u of topCounterpartyUsers) {
    topUserMap.set(String(u._id), u);
  }

  const topCounterparties = topCounterpartiesRaw.map((r) => {
    const u = topUserMap.get(String(r._id));
    return {
      id: String(r._id),
      name: u?.name ?? "-",
      username: u?.username ?? "-",
      role: (u?.role as Role) ?? "PARTNER",
      useCount: Number(r.useCount ?? 0),
      usedPoints: Number(r.usedPoints ?? 0),
    };
  });

  const recentLedger = await Ledger.find({}).sort({ createdAt: -1 }).limit(8).lean();

  const relationIds = new Set<string>();
  for (const row of recentLedger as any[]) {
    if (row.accountId) relationIds.add(String(row.accountId));
    if (row.actorId) relationIds.add(String(row.actorId));
    if (row.userId) relationIds.add(String(row.userId));
    if (row.counterpartyId) relationIds.add(String(row.counterpartyId));
  }

  const relationUsers =
    relationIds.size > 0
      ? await User.find(
          {
            _id: {
              $in: Array.from(relationIds).map(
                (id) => new mongoose.Types.ObjectId(id)
              ),
            },
          },
          { name: 1, username: 1, role: 1 }
        ).lean()
      : [];

  const relationUserMap = new Map<string, any>();
  for (const u of relationUsers) {
    relationUserMap.set(String(u._id), u);
  }

  const recentActivities = (recentLedger as any[]).map((row) => ({
    id: String(row._id),
    type: String(row.type ?? "-"),
    amount: Number(row.amount ?? 0),
    createdAt: row.createdAt,
    account: row.accountId ? relationUserMap.get(String(row.accountId)) : null,
    actor: row.actorId ? relationUserMap.get(String(row.actorId)) : null,
    counterparty: row.counterpartyId
      ? relationUserMap.get(String(row.counterpartyId))
      : null,
    note: row.note ?? "",
  }));

  const filter: any = {};

  if (activeRole !== "ALL") {
    filter.role = activeRole;
  }

  if (q) {
    filter.$or = [
      { username: { $regex: q, $options: "i" } },
      { name: { $regex: q, $options: "i" } },
    ];
  }

  const rows = await User.find(
    filter,
    { username: 1, name: 1, role: 1, status: 1, createdAt: 1 }
  )
    .sort({ createdAt: -1 })
    .limit(80)
    .lean();

  const userIds = rows.map(
    (u: any) => new mongoose.Types.ObjectId(String(u._id))
  );

  const sums =
    userIds.length === 0
      ? []
      : await Ledger.aggregate([
          { $match: { accountId: { $in: userIds } } },
          { $group: { _id: "$accountId", balance: { $sum: "$amount" } } },
        ]);

  const balanceMap = new Map<string, number>();
  for (const s of sums) {
    balanceMap.set(String(s._id), Number(s.balance ?? 0));
  }

  const users = rows.map((u: any) => ({
    id: String(u._id),
    username: u.username,
    name: u.name,
    role: u.role as Role,
    status: u.status as Status,
    createdAt: u.createdAt,
    balance: balanceMap.get(String(u._id)) ?? 0,
  }));

  async function updateUserRole(formData: FormData) {
    "use server";

    const { getSessionFromCookies } = await import("@/lib/auth");
    const { connectDB } = await import("@/lib/db");
    const { User } = await import("@/models/User");

    const s = await getSessionFromCookies();
    if (!s) {
      redirect("/login");
      return;
    }

    if (s.role !== "ADMIN") {
      throw new Error("FORBIDDEN");
    }

    const userId = String(formData.get("userId") ?? "");
    const role = String(formData.get("role") ?? "");

    if (!["CUSTOMER", "PARTNER"].includes(role)) {
      throw new Error("INVALID_ROLE");
    }

    await connectDB();
    await User.updateOne({ _id: userId }, { $set: { role } });
  }

  const tabs: { key: "ALL" | Role; label: string; href: string }[] = [
    {
      key: "ALL",
      label: "전체",
      href: q ? `/admin?q=${encodeURIComponent(q)}` : "/admin",
    },
    {
      key: "CUSTOMER",
      label: "고객",
      href: `/admin?role=CUSTOMER${q ? `&q=${encodeURIComponent(q)}` : ""}`,
    },
    {
      key: "PARTNER",
      label: "제휴사",
      href: `/admin?role=PARTNER${q ? `&q=${encodeURIComponent(q)}` : ""}`,
    },
    {
      key: "ADMIN",
      label: "총괄관리자",
      href: `/admin?role=ADMIN${q ? `&q=${encodeURIComponent(q)}` : ""}`,
    },
  ];

  return (
    <main className="admin-page">
      <style>{`
        .admin-page {
          color: #111827;
        }

        .hero-card {
          border: 1px solid #e5e7eb;
          border-radius: 18px;
          padding: 20px;
          background: #fff;
          box-shadow: 0 4px 16px rgba(15, 23, 42, 0.04);
          display: flex;
          justify-content: space-between;
          gap: 16px;
          flex-wrap: wrap;
          align-items: center;
          margin-bottom: 20px;
        }

        .hero-eyebrow {
          font-size: 14px;
          color: #6b7280;
          margin-bottom: 6px;
        }

        .hero-title {
          margin: 0;
          font-size: 28px;
          font-weight: 900;
          letter-spacing: -0.02em;
        }

        .hero-subtitle {
          margin-top: 8px;
          color: #4b5563;
          font-size: 14px;
        }

        .hero-badge {
          min-width: 240px;
          border: 1px solid #e5e7eb;
          border-radius: 16px;
          padding: 14px 16px;
          background: #fafafa;
        }

        .hero-badge-label {
          font-size: 13px;
          color: #6b7280;
          margin-bottom: 6px;
        }

        .hero-badge-value {
          font-size: 30px;
          font-weight: 900;
        }

        .hero-badge-sub {
          margin-top: 6px;
          font-size: 13px;
          color: #6b7280;
        }

        .search-button,
        .reset-button,
        .action-chip,
        .role-save-button {
          border: 1px solid #d1d5db;
          background: #ffffff;
          color: #111827;
          border-radius: 12px;
          font-weight: 800;
          cursor: pointer;
          text-decoration: none;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          transition: all 0.15s ease;
        }

        .search-button:hover,
        .reset-button:hover,
        .action-chip:hover,
        .role-save-button:hover {
          background: #f9fafb;
        }

        .kpi-grid {
          display: grid;
          grid-template-columns: repeat(4, minmax(0, 1fr));
          gap: 14px;
          margin-bottom: 16px;
        }

        .kpi-card {
          background: #ffffff;
          border: 1px solid #e5e7eb;
          border-radius: 20px;
          padding: 18px;
          box-shadow: 0 8px 24px rgba(15, 23, 42, 0.04);
        }

        .kpi-card.primary {
          background: linear-gradient(135deg, #111827, #1f2937);
          color: white;
          border-color: #111827;
        }

        .kpi-label {
          font-size: 13px;
          color: #6b7280;
        }

        .kpi-card.primary .kpi-label,
        .kpi-card.primary .kpi-sub {
          color: rgba(255, 255, 255, 0.78);
        }

        .kpi-value {
          margin-top: 10px;
          font-size: 32px;
          font-weight: 900;
          letter-spacing: -0.03em;
        }

        .kpi-sub {
          margin-top: 8px;
          font-size: 13px;
          color: #6b7280;
        }

        .dashboard-grid {
          display: grid;
          grid-template-columns: 1.2fr 0.8fr;
          gap: 16px;
          margin-bottom: 16px;
        }

        .panel {
          background: #ffffff;
          border: 1px solid #e5e7eb;
          border-radius: 20px;
          padding: 18px;
          box-shadow: 0 8px 24px rgba(15, 23, 42, 0.04);
        }

        .panel-title-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 10px;
          margin-bottom: 14px;
        }

        .panel-title {
          margin: 0;
          font-size: 18px;
          font-weight: 900;
          letter-spacing: -0.02em;
        }

        .panel-desc {
          font-size: 13px;
          color: #6b7280;
        }

        .approval-grid {
          display: grid;
          grid-template-columns: 1fr;
          gap: 10px;
        }

        .approval-card {
          border: 1px solid #e5e7eb;
          border-radius: 16px;
          padding: 14px;
          background: #f9fafb;
          text-decoration: none;
          color: inherit;
        }

        .approval-top {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
        }

        .approval-name {
          font-size: 14px;
          font-weight: 800;
        }

        .approval-count {
          font-size: 22px;
          font-weight: 900;
          letter-spacing: -0.02em;
        }

        .approval-sub {
          margin-top: 6px;
          color: #6b7280;
          font-size: 13px;
        }

        .action-grid {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 10px;
          margin-top: 14px;
        }

        .action-chip {
          min-height: 46px;
          padding: 0 14px;
        }

        .activity-list,
        .top-list {
          display: grid;
          gap: 10px;
        }

        .activity-item,
        .top-item {
          border: 1px solid #e5e7eb;
          border-radius: 16px;
          padding: 14px;
          background: #fbfcfe;
        }

        .activity-main,
        .top-main {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 12px;
        }

        .activity-type,
        .top-rank {
          font-size: 13px;
          font-weight: 900;
          color: #4b5563;
          margin-bottom: 6px;
        }

        .activity-name,
        .top-name {
          font-size: 15px;
          font-weight: 800;
        }

        .activity-meta,
        .top-meta {
          margin-top: 6px;
          font-size: 13px;
          color: #6b7280;
          line-height: 1.5;
        }

        .activity-amount,
        .top-amount {
          white-space: nowrap;
          font-size: 18px;
          font-weight: 900;
          letter-spacing: -0.02em;
        }

        .summary-grid {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 10px;
          margin-top: 14px;
        }

        .summary-box {
          border: 1px solid #e5e7eb;
          border-radius: 16px;
          padding: 14px;
          background: #f9fafb;
        }

        .summary-label {
          font-size: 13px;
          color: #6b7280;
        }

        .summary-value {
          margin-top: 8px;
          font-size: 22px;
          font-weight: 900;
        }

        .user-section {
          margin-top: 16px;
        }

        .user-toolbar {
          display: flex;
          gap: 10px;
          flex-wrap: wrap;
          align-items: center;
          margin-bottom: 12px;
        }

        .search-input {
          flex: 1 1 280px;
          min-height: 46px;
          border: 1px solid #d1d5db;
          border-radius: 12px;
          background: #fff;
          padding: 0 14px;
          font-size: 14px;
          outline: none;
        }

        .search-button,
        .reset-button {
          min-height: 46px;
          padding: 0 14px;
        }

        .tab-row {
          display: flex;
          gap: 8px;
          flex-wrap: wrap;
          margin-bottom: 14px;
        }

        .tab-button {
          padding: 9px 14px;
          border-radius: 999px;
          border: 1px solid #d1d5db;
          text-decoration: none;
          color: #111827;
          background: #ffffff;
          font-weight: 800;
          font-size: 14px;
        }

        .tab-button.active {
          background: #111827;
          color: #ffffff;
          border-color: #111827;
        }

        .user-count-text {
          margin: 0 0 14px;
          color: #6b7280;
          font-size: 14px;
        }

        .desktop-table {
          display: block;
          overflow-x: auto;
          border: 1px solid #e5e7eb;
          border-radius: 18px;
          background: #fff;
        }

        .table-grid {
          min-width: 980px;
        }

        .table-head,
        .table-row {
          display: grid;
          grid-template-columns: 180px 140px 100px 100px 220px 120px 180px;
          gap: 10px;
          align-items: center;
          padding: 14px 16px;
        }

        .table-head {
          background: #f9fafb;
          border-bottom: 1px solid #e5e7eb;
          font-size: 13px;
          font-weight: 900;
          color: #374151;
        }

        .table-row {
          border-bottom: 1px solid #f1f5f9;
          font-size: 14px;
        }

        .table-row:last-child {
          border-bottom: 0;
        }

        .cell-ellipsis {
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .role-form {
          display: flex;
          gap: 8px;
          align-items: center;
        }

        .role-select {
          min-height: 38px;
          border: 1px solid #d1d5db;
          border-radius: 10px;
          background: #fff;
          padding: 0 10px;
          font-weight: 700;
        }

        .role-save-button {
          min-height: 38px;
          padding: 0 12px;
        }

        .role-fixed {
          color: #9ca3af;
          font-weight: 800;
        }

        .mobile-user-list {
          display: none;
          gap: 10px;
        }

        .mobile-user-card {
          border: 1px solid #e5e7eb;
          border-radius: 16px;
          padding: 14px;
          background: #fff;
        }

        .mobile-user-top {
          display: flex;
          justify-content: space-between;
          gap: 12px;
          align-items: flex-start;
        }

        .mobile-user-name {
          font-size: 16px;
          font-weight: 900;
        }

        .mobile-user-username {
          margin-top: 4px;
          font-size: 13px;
          color: #6b7280;
        }

        .mobile-user-balance {
          font-size: 18px;
          font-weight: 900;
          white-space: nowrap;
        }

        .mobile-user-meta {
          margin-top: 12px;
          display: grid;
          gap: 8px;
          font-size: 14px;
        }

        .mobile-user-meta-row {
          display: flex;
          justify-content: space-between;
          gap: 12px;
        }

        .mobile-user-label {
          color: #6b7280;
        }

        .mobile-user-role-form {
          margin-top: 12px;
          display: flex;
          gap: 8px;
          flex-wrap: wrap;
        }

        .empty-box {
          padding: 18px;
          text-align: center;
          color: #6b7280;
          border: 1px dashed #d1d5db;
          border-radius: 16px;
          background: #fff;
        }

        @media (max-width: 1100px) {
          .kpi-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
          }

          .dashboard-grid {
            grid-template-columns: 1fr;
          }

          .summary-grid {
            grid-template-columns: repeat(3, minmax(0, 1fr));
          }
        }

        @media (max-width: 760px) {
          .hero-title {
            font-size: 24px;
          }

          .kpi-grid {
            grid-template-columns: 1fr;
          }

          .action-grid {
            grid-template-columns: 1fr 1fr;
          }

          .summary-grid {
            grid-template-columns: 1fr;
          }

          .desktop-table {
            display: none;
          }

          .mobile-user-list {
            display: grid;
          }
        }

        @media (max-width: 520px) {
          .action-grid {
            grid-template-columns: 1fr;
          }

          .approval-top,
          .activity-main,
          .top-main,
          .mobile-user-top {
            flex-direction: column;
            align-items: flex-start;
          }

          .activity-amount,
          .top-amount,
          .mobile-user-balance {
            white-space: normal;
          }
        }
      `}</style>

      <section className="hero-card">
        <div>
          <div className="hero-eyebrow">운영 요약</div>
          <h1 className="hero-title">관리자 대시보드</h1>
          <div className="hero-subtitle">
            승인 대기, 운영 KPI, 원장 현황, 정산 흐름을 한 번에 확인합니다.
          </div>
        </div>

        <div className="hero-badge">
          <div className="hero-badge-label">전체 사용자</div>
          <div className="hero-badge-value">{formatNumber(totalUsers)}명</div>
          <div className="hero-badge-sub">
            고객 {formatNumber(customerCount)} / 제휴사 {formatNumber(partnerCount)}
          </div>
        </div>
      </section>

      <section className="kpi-grid">
        <div className="kpi-card primary">
          <div className="kpi-label">승인 대기 전체</div>
          <div className="kpi-value">
            {formatNumber(
              pendingTopupCount + pendingIssueCount + pendingUseCount
            )}
            건
          </div>
          <div className="kpi-sub">
            충전 {formatNumber(pendingTopupCount)} / 지급{" "}
            {formatNumber(pendingIssueCount)} / 사용 {formatNumber(pendingUseCount)}
          </div>
        </div>

        <div className="kpi-card">
          <div className="kpi-label">오늘 지급 포인트</div>
          <div className="kpi-value">{formatNumber(todayIssueAmount)}P</div>
          <div className="kpi-sub">Ledger ISSUE 기준</div>
        </div>

        <div className="kpi-card">
          <div className="kpi-label">오늘 사용 포인트</div>
          <div className="kpi-value">{formatNumber(todayUseAmount)}P</div>
          <div className="kpi-sub">Ledger USE 기준</div>
        </div>

        <div className="kpi-card">
          <div className="kpi-label">이번달 예상 지급액</div>
          <div className="kpi-value">{formatNumber(monthExpectedPayout)}P</div>
          <div className="kpi-sub">기본 수수료율 10% 가정</div>
        </div>
      </section>

      <section className="dashboard-grid">
        <div className="panel">
          <div className="panel-title-row">
            <h2 className="panel-title">최근 원장 활동</h2>
            <span className="panel-desc">가장 최근 8건</span>
          </div>

          <div className="activity-list">
            {recentActivities.length > 0 ? (
              recentActivities.map((r) => (
                <div key={r.id} className="activity-item">
                  <div className="activity-main">
                    <div>
                      <div className="activity-type">{r.type}</div>
                      <div className="activity-name">
                        {r.account
                          ? `${r.account.name} (${r.account.username})`
                          : "계정 정보 없음"}
                      </div>
                      <div className="activity-meta">
                        {r.counterparty
                          ? `상대: ${r.counterparty.name} (${r.counterparty.username})`
                          : r.actor
                          ? `실행자: ${r.actor.name} (${r.actor.username})`
                          : "상대 정보 없음"}
                        <br />
                        {r.createdAt
                          ? new Date(r.createdAt).toLocaleString()
                          : "-"}
                      </div>
                    </div>

                    <div className="activity-amount">
                      {formatNumber(Math.abs(r.amount))}P
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="empty-box">최근 활동이 없습니다.</div>
            )}
          </div>
        </div>

        <div className="panel">
          <div className="panel-title-row">
            <h2 className="panel-title">승인 대기 / 빠른 실행</h2>
            <span className="panel-desc">자주 쓰는 운영 액션</span>
          </div>

          <div className="approval-grid">
            <a href="/admin/topup-requests" className="approval-card">
              <div className="approval-top">
                <div className="approval-name">충전요청 승인 대기</div>
                <div className="approval-count">
                  {formatNumber(pendingTopupCount)}건
                </div>
              </div>
              <div className="approval-sub">충전 승인 처리 화면으로 이동</div>
            </a>

            <a href="/admin/issue-requests" className="approval-card">
              <div className="approval-top">
                <div className="approval-name">지급요청 승인 대기</div>
                <div className="approval-count">
                  {formatNumber(pendingIssueCount)}건
                </div>
              </div>
              <div className="approval-sub">고객 포인트 지급 승인 처리</div>
            </a>

            <a href="/admin/use-requests" className="approval-card">
              <div className="approval-top">
                <div className="approval-name">사용요청 승인 대기</div>
                <div className="approval-count">
                  {formatNumber(pendingUseCount)}건
                </div>
              </div>
              <div className="approval-sub">사용 승인 / 거절 처리</div>
            </a>
          </div>

          <div className="action-grid">
            <a href="/admin/topup" className="action-chip">
              관리자 수동 충전
            </a>
            <a href="/admin/adjust" className="action-chip">
              포인트 조정
            </a>
            <a href="/admin/ledger" className="action-chip">
              원장 조회
            </a>
            <a href="/admin/settlements" className="action-chip">
              월정산 관리
            </a>
            <a href="/admin/fee-policies" className="action-chip">
              수수료 정책
            </a>
            <a href="/admin/accounts" className="action-chip">
              계정 조회
            </a>
          </div>

          <div className="summary-grid">
            <div className="summary-box">
              <div className="summary-label">전체 사용자</div>
              <div className="summary-value">{formatNumber(totalUsers)}명</div>
            </div>

            <div className="summary-box">
              <div className="summary-label">고객 / 제휴사</div>
              <div className="summary-value">
                {formatNumber(customerCount)} / {formatNumber(partnerCount)}
              </div>
            </div>

            <div className="summary-box">
              <div className="summary-label">제휴사</div>
              <div className="summary-value">{formatNumber(partnerCount)}명</div>
            </div>
          </div>
        </div>
      </section>

      <section className="dashboard-grid">
        <div className="panel">
          <div className="panel-title-row">
            <h2 className="panel-title">이번달 운영 요약</h2>
            <span className="panel-desc">월 누적 기준</span>
          </div>

          <div className="summary-grid" style={{ marginTop: 0 }}>
            <div className="summary-box">
              <div className="summary-label">이번달 사용건수</div>
              <div className="summary-value">{formatNumber(monthUseCount)}건</div>
            </div>

            <div className="summary-box">
              <div className="summary-label">이번달 사용포인트</div>
              <div className="summary-value">
                {formatNumber(monthUsedPoints)}P
              </div>
            </div>

            <div className="summary-box">
              <div className="summary-label">예상 수수료</div>
              <div className="summary-value">
                {formatNumber(monthExpectedFee)}P
              </div>
            </div>
          </div>
        </div>

        <div className="panel">
          <div className="panel-title-row">
            <h2 className="panel-title">이번달 TOP 사용처</h2>
            <span className="panel-desc">사용포인트 기준</span>
          </div>

          <div className="top-list">
            {topCounterparties.length > 0 ? (
              topCounterparties.map((row, idx) => (
                <div key={row.id} className="top-item">
                  <div className="top-main">
                    <div>
                      <div className="top-rank">{idx + 1}위</div>
                      <div className="top-name">{row.name}</div>
                      <div className="top-meta">
                        {row.username} / {ROLE_LABEL[row.role]} /{" "}
                        {formatNumber(row.useCount)}건
                      </div>
                    </div>
                    <div className="top-amount">
                      {formatNumber(row.usedPoints)}P
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="empty-box">이번달 사용 데이터가 없습니다.</div>
            )}
          </div>
        </div>
      </section>

      <section className="panel user-section">
        <div className="panel-title-row">
          <h2 className="panel-title">사용자 관리</h2>
          <span className="panel-desc">검색 / 역할 필터 / 역할 변경</span>
        </div>

        <form action="/admin" method="GET" className="user-toolbar">
          {activeRole !== "ALL" && (
            <input type="hidden" name="role" value={activeRole} />
          )}

          <input
            name="q"
            defaultValue={q}
            placeholder="아이디 또는 이름 검색"
            className="search-input"
          />

          <button type="submit" className="search-button">
            검색
          </button>

          <a
            href={activeRole === "ALL" ? "/admin" : `/admin?role=${activeRole}`}
            className="reset-button"
          >
            초기화
          </a>
        </form>

        <div className="tab-row">
          {tabs.map((t) => (
            <a
              key={t.key}
              href={t.href}
              className={`tab-button ${activeRole === t.key ? "active" : ""}`}
            >
              {t.label}
            </a>
          ))}
        </div>

        <p className="user-count-text">
          현재: <b>{activeRole === "ALL" ? "전체" : ROLE_LABEL[activeRole]}</b> / 표시{" "}
          {users.length}명
        </p>

        <div className="desktop-table">
          <div className="table-grid">
            <div className="table-head">
              <div>아이디</div>
              <div>이름</div>
              <div>역할</div>
              <div>상태</div>
              <div>역할 변경</div>
              <div>잔액</div>
              <div>가입일</div>
            </div>

            {users.length > 0 ? (
              users.map((u) => (
                <div key={u.id} className="table-row">
                  <div className="cell-ellipsis">{u.username}</div>
                  <div className="cell-ellipsis">{u.name}</div>
                  <div className="cell-ellipsis">{ROLE_LABEL[u.role]}</div>
                  <div className="cell-ellipsis">{STATUS_LABEL[u.status]}</div>

                  <div>
                    {u.role === "ADMIN" ? (
                      <span className="role-fixed">변경 불가</span>
                    ) : (
                      <form action={updateUserRole} className="role-form">
                        <input type="hidden" name="userId" value={u.id} />
                        <select
                          name="role"
                          defaultValue={u.role}
                          className="role-select"
                        >
                          <option value="CUSTOMER">고객</option>
                          <option value="PARTNER">제휴사</option>
                        </select>
                        <button type="submit" className="role-save-button">
                          적용
                        </button>
                      </form>
                    )}
                  </div>

                  <div className="cell-ellipsis" style={{ fontWeight: 900 }}>
                    {formatNumber(u.balance)}P
                  </div>

                  <div className="cell-ellipsis">
                    {u.createdAt ? new Date(u.createdAt).toLocaleString() : "-"}
                  </div>
                </div>
              ))
            ) : (
              <div className="empty-box" style={{ margin: 16 }}>
                사용자가 없습니다.
              </div>
            )}
          </div>
        </div>

        <div className="mobile-user-list">
          {users.length > 0 ? (
            users.map((u) => (
              <div key={u.id} className="mobile-user-card">
                <div className="mobile-user-top">
                  <div>
                    <div className="mobile-user-name">{u.name}</div>
                    <div className="mobile-user-username">{u.username}</div>
                  </div>
                  <div className="mobile-user-balance">
                    {formatNumber(u.balance)}P
                  </div>
                </div>

                <div className="mobile-user-meta">
                  <div className="mobile-user-meta-row">
                    <span className="mobile-user-label">역할</span>
                    <span>{ROLE_LABEL[u.role]}</span>
                  </div>
                  <div className="mobile-user-meta-row">
                    <span className="mobile-user-label">상태</span>
                    <span>{STATUS_LABEL[u.status]}</span>
                  </div>
                  <div className="mobile-user-meta-row">
                    <span className="mobile-user-label">가입일</span>
                    <span>
                      {u.createdAt
                        ? new Date(u.createdAt).toLocaleDateString()
                        : "-"}
                    </span>
                  </div>
                </div>

                {u.role === "ADMIN" ? (
                  <div className="mobile-user-role-form">
                    <span className="role-fixed">총괄관리자는 역할 변경 불가</span>
                  </div>
                ) : (
                  <form action={updateUserRole} className="mobile-user-role-form">
                    <input type="hidden" name="userId" value={u.id} />
                    <select
                      name="role"
                      defaultValue={u.role}
                      className="role-select"
                    >
                      <option value="CUSTOMER">고객</option>
                      <option value="PARTNER">제휴사</option>
                    </select>
                    <button type="submit" className="role-save-button">
                      적용
                    </button>
                  </form>
                )}
              </div>
            ))
          ) : (
            <div className="empty-box">사용자가 없습니다.</div>
          )}
        </div>
      </section>
    </main>
  );
}