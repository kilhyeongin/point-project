// src/app/admin/layout.tsx
// =======================================================
// ADMIN 공통 레이아웃
// -------------------------------------------------------
// - 로그인 필수
// - ADMIN만 접근 가능
// - 공통 상단 메뉴 / 컨테이너 제공
// =======================================================

import { redirect } from "next/navigation";
import { getSessionFromCookies } from "@/lib/auth";
import AdminShellClient from "./AdminShellClient";

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const session = await getSessionFromCookies();

  if (!session) {
    redirect("/login");
  }

  if (session.role === "PARTNER") {
    redirect("/partner");
  }

  if (session.role === "CUSTOMER") {
    redirect("/customer");
  }

  return (
    <AdminShellClient
      session={{
        uid: session.uid,
        username: session.username,
        name: session.name,
        role: session.role,
      }}
    >
      {children}
    </AdminShellClient>
  );
}