"use client";

import { useEffect, useMemo, useState } from "react";

type PreviewItem = {
  counterpartyId: string | null;
  counterparty: {
    id: string;
    username: string;
    name: string;
    role: string;
    status: string;
  } | null;
  useCount: number;
  usedPoints: number;
  lastUsedAt: string | null;
};

type PeriodItem = {
  periodKey: string;
  from: string;
  to: string;
  status: "OPEN" | "CLOSED" | "PAID";
  closedAt?: string | null;
  totalCounterparties: number;
  totalUseCount: number;
  totalUsedPoints: number;
};

type LineItem = {
  id: string;
  periodKey: string;
  status: "OPEN" | "PAID";
  useCount: number;
  usedPoints: number;
  netPayable: number;
  paidAt?: string | null;
  payoutRef?: string;
  note?: string;
  counterparty: {
    id: string;
    username: string;
    name: string;
    role: string;
    status: string;
  } | null;
};

function formatNumber(n: number) {
  return Number(n || 0).toLocaleString();
}

function todayYYYYMMDD() {
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

function firstDayOfThisMonthYYYYMMDD() {
  const d = new Date();
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  return `${yyyy}-${mm}-01`;
}

function rangeLastMonth() {
  const d = new Date();
  const start = new Date(d.getFullYear(), d.getMonth() - 1, 1);
  const end = new Date(d.getFullYear(), d.getMonth(), 0);

  const yyyy1 = start.getFullYear();
  const mm1 = String(start.getMonth() + 1).padStart(2, "0");
  const dd1 = String(start.getDate()).padStart(2, "0");

  const yyyy2 = end.getFullYear();
  const mm2 = String(end.getMonth() + 1).padStart(2, "0");
  const dd2 = String(end.getDate()).padStart(2, "0");

  return { from: `${yyyy1}-${mm1}-${dd1}`, to: `${yyyy2}-${mm2}-${dd2}` };
}

function periodKeyFromFrom(from: string) {
  if (/^\d{4}-\d{2}-\d{2}$/.test(from)) return from.slice(0, 7);
  return "";
}

function roleLabel(role?: string) {
  if (role === "PARTNER") return "제휴사";
  if (role === "CUSTOMER") return "고객";
  if (role === "ADMIN") return "총괄관리자";
  return role || "-";
}

function userStatusLabel(status?: string) {
  if (status === "ACTIVE") return "정상";
  if (status === "PENDING") return "대기";
  if (status === "BLOCKED") return "차단";
  return status || "-";
}

function settlementStatusLabel(status?: string) {
  if (status === "PAID") return "지급완료";
  if (status === "CLOSED") return "마감";
  if (status === "OPEN") return "정산대기";
  return status || "-";
}

export default function AdminSettlementsPage() {
  const [q, setQ] = useState("");
  const [from, setFrom] = useState(firstDayOfThisMonthYYYYMMDD());
  const [to, setTo] = useState(todayYYYYMMDD());

  const [preview, setPreview] = useState<PreviewItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");

  const queryKey = useMemo(() => `${q.trim()}|${from}|${to}`, [q, from, to]);

  function setThisMonth() {
    setFrom(firstDayOfThisMonthYYYYMMDD());
    setTo(todayYYYYMMDD());
  }

  function setLastMonth() {
    const r = rangeLastMonth();
    setFrom(r.from);
    setTo(r.to);
  }

  async function loadPreview() {
    setLoading(true);
    setMsg("");

    try {
      const params = new URLSearchParams();
      if (q.trim()) params.set("q", q.trim());
      if (from) params.set("from", from);
      if (to) params.set("to", to);

      const res = await fetch(`/api/admin/settlements?${params.toString()}`);
      const text = await res.text();
      const data = text ? JSON.parse(text) : null;

      if (!res.ok) {
        setMsg(data?.message ?? "정산 미리보기 조회 실패");
        setPreview([]);
        return;
      }

      setPreview(data?.items ?? []);
    } catch {
      setMsg("네트워크 오류");
      setPreview([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    const t = setTimeout(() => loadPreview(), 250);
    return () => clearTimeout(t);
  }, [queryKey]);

  const excelUrl = useMemo(() => {
    const params = new URLSearchParams();
    if (q.trim()) params.set("q", q.trim());
    if (from) params.set("from", from);
    if (to) params.set("to", to);
    return `/api/admin/settlements/excel?${params.toString()}`;
  }, [q, from, to]);

  const [closeMsg, setCloseMsg] = useState<string>("");

  async function closePeriod() {
    setCloseMsg("");
    const periodKey = periodKeyFromFrom(from);

    if (!periodKey) {
      setCloseMsg("from 날짜 형식을 확인해주세요. (YYYY-MM-DD)");
      return;
    }

    try {
      const res = await fetch("/api/admin/settlements/close", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ periodKey, from, to }),
      });

      const text = await res.text();
      const data = text ? JSON.parse(text) : null;

      if (!res.ok) {
        setCloseMsg(data?.message ?? "마감 실패");
        return;
      }

      setCloseMsg(
        `✅ 마감 완료: ${periodKey} / 업체 ${formatNumber(
          data.totalCounterparties
        )} / 건수 ${formatNumber(data.totalUseCount)} / 사용포인트 ${formatNumber(
          data.totalUsedPoints
        )}P`
      );

      await loadPeriods();
      setSelectedPeriodKey(periodKey);
      await loadLines(periodKey);
    } catch {
      setCloseMsg("네트워크 오류");
    }
  }

  const [periods, setPeriods] = useState<PeriodItem[]>([]);
  const [periodLoading, setPeriodLoading] = useState(false);
  const [periodErr, setPeriodErr] = useState("");

  const [selectedPeriodKey, setSelectedPeriodKey] = useState<string>("");
  const [lines, setLines] = useState<LineItem[]>([]);
  const [linesLoading, setLinesLoading] = useState(false);
  const [linesErr, setLinesErr] = useState("");

  async function loadPeriods() {
    setPeriodLoading(true);
    setPeriodErr("");
    try {
      const res = await fetch("/api/admin/settlements/periods");
      const text = await res.text();
      const data = text ? JSON.parse(text) : null;

      if (!res.ok) {
        setPeriodErr(data?.message ?? "기간 조회 실패");
        setPeriods([]);
        return;
      }

      setPeriods(data?.items ?? []);
    } catch {
      setPeriodErr("네트워크 오류");
      setPeriods([]);
    } finally {
      setPeriodLoading(false);
    }
  }

  async function loadLines(periodKey: string) {
    setLinesLoading(true);
    setLinesErr("");
    try {
      const res = await fetch(
        `/api/admin/settlements/lines?periodKey=${encodeURIComponent(periodKey)}`
      );
      const text = await res.text();
      const data = text ? JSON.parse(text) : null;

      if (!res.ok) {
        setLinesErr(data?.message ?? "라인 조회 실패");
        setLines([]);
        return;
      }

      setLines(data?.items ?? []);
    } catch {
      setLinesErr("네트워크 오류");
      setLines([]);
    } finally {
      setLinesLoading(false);
    }
  }

  useEffect(() => {
    loadPeriods();
  }, []);

  useEffect(() => {
    if (!selectedPeriodKey) return;
    loadLines(selectedPeriodKey);
  }, [selectedPeriodKey]);

  async function markPaid(line: LineItem) {
    if (!selectedPeriodKey || !line.counterparty?.id) return;

    const payoutRef = prompt("지급 참조(거래번호/송금ID) 입력 (선택)") ?? "";
    const note = prompt("메모(선택)") ?? "";

    try {
      const res = await fetch("/api/admin/settlements/payout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          periodKey: selectedPeriodKey,
          counterpartyId: line.counterparty.id,
          payoutRef,
          note,
        }),
      });

      const text = await res.text();
      const data = text ? JSON.parse(text) : null;

      if (!res.ok) {
        alert(data?.message ?? "지급 처리 실패");
        return;
      }

      await loadPeriods();
      await loadLines(selectedPeriodKey);
      alert(`✅ 지급 처리 완료 (기간 상태: ${settlementStatusLabel(data.periodStatus)})`);
    } catch {
      alert("네트워크 오류");
    }
  }

  async function cancelPaid(line: LineItem) {
    if (!selectedPeriodKey || !line.counterparty?.id) return;

    const ok = window.confirm("지급완료를 취소하시겠습니까?");
    if (!ok) return;

    try {
      const res = await fetch("/api/admin/settlements/payout-cancel", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          periodKey: selectedPeriodKey,
          counterpartyId: line.counterparty.id,
        }),
      });

      const text = await res.text();
      const data = text ? JSON.parse(text) : null;

      if (!res.ok) {
        alert(data?.message ?? "지급 취소 실패");
        return;
      }

      await loadPeriods();
      await loadLines(selectedPeriodKey);
      alert("✅ 지급 취소 완료");
    } catch {
      alert("네트워크 오류");
    }
  }

  const previewTotals = useMemo(() => {
    const totalCounterparties = preview.length;
    const totalUseCount = preview.reduce(
      (sum, item) => sum + Number(item.useCount || 0),
      0
    );
    const totalUsedPoints = preview.reduce(
      (sum, item) => sum + Number(item.usedPoints || 0),
      0
    );
    const totalNetPayable = totalUsedPoints;

    return {
      totalCounterparties,
      totalUseCount,
      totalUsedPoints,
      totalNetPayable,
    };
  }, [preview]);

  const selectedPeriod = useMemo(
    () => periods.find((p) => p.periodKey === selectedPeriodKey) || null,
    [periods, selectedPeriodKey]
  );

  return (
    <main className="page-shell">
      <style>{`
        .page-shell {
          max-width: 1240px;
          margin: 0 auto;
          padding: 20px;
          min-height: 100vh;
          background: #f5f7fb;
          color: #111827;
        }

        .page-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 12px;
          margin-bottom: 18px;
        }

        .page-title {
          margin: 0;
          font-size: 28px;
          font-weight: 900;
          letter-spacing: -0.02em;
        }

        .page-sub {
          margin-top: 8px;
          color: #6b7280;
          font-size: 14px;
          line-height: 1.6;
        }

        .top-actions {
          display: flex;
          gap: 8px;
          flex-wrap: wrap;
        }

        .ghost-btn,
        .solid-btn,
        .back-btn,
        .danger-btn,
        .excel-btn,
        .tiny-btn,
        .chip-btn {
          min-height: 44px;
          padding: 0 14px;
          border-radius: 12px;
          font-weight: 800;
          cursor: pointer;
          text-decoration: none;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          transition: all 0.15s ease;
        }

        .ghost-btn,
        .back-btn,
        .danger-btn,
        .chip-btn {
          border: 1px solid #d1d5db;
          background: #fff;
          color: #111827;
        }

        .solid-btn,
        .excel-btn {
          border: 1px solid #111827;
          background: #111827;
          color: #fff;
        }

        .tiny-btn {
          min-height: 38px;
          padding: 0 12px;
          border: 1px solid #111827;
          background: #111827;
          color: #fff;
        }

        .tiny-btn.light {
          background: #fff;
          color: #111827;
        }

        .tiny-btn.cancel {
          border-color: #b91c1c;
          color: #b91c1c;
          background: #fff;
        }

        .filter-panel,
        .summary-card,
        .section-card,
        .list-panel,
        .period-card,
        .line-card {
          background: #fff;
          border: 1px solid #e5e7eb;
          border-radius: 18px;
          box-shadow: 0 8px 24px rgba(15, 23, 42, 0.04);
        }

        .filter-panel,
        .section-card {
          padding: 16px;
        }

        .filter-panel {
          margin-bottom: 16px;
        }

        .filter-grid {
          display: grid;
          grid-template-columns: auto auto minmax(220px, 1fr) 180px auto auto;
          gap: 10px;
          align-items: end;
        }

        .field {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }

        .field-label {
          font-size: 13px;
          color: #6b7280;
          font-weight: 800;
        }

        .field-row {
          display: flex;
          gap: 8px;
          flex-wrap: wrap;
        }

        .input,
        .select {
          min-height: 46px;
          border: 1px solid #d1d5db;
          border-radius: 12px;
          background: #fff;
          padding: 0 14px;
          font-size: 14px;
          outline: none;
        }

        .input {
          width: 100%;
        }

        .select {
          min-width: 180px;
        }

        .date-input {
          width: 150px;
        }

        .info-strip {
          margin-top: 14px;
          padding: 12px 14px;
          border-radius: 14px;
          border: 1px solid #e5e7eb;
          background: #f9fafb;
          display: flex;
          gap: 12px;
          flex-wrap: wrap;
          align-items: center;
          font-size: 14px;
        }

        .summary-grid {
          display: grid;
          grid-template-columns: repeat(4, minmax(0, 1fr));
          gap: 12px;
          margin-bottom: 16px;
        }

        .summary-card {
          padding: 16px;
        }

        .summary-card.primary {
          background: linear-gradient(135deg, #111827, #1f2937);
          border-color: #111827;
          color: #fff;
        }

        .summary-label {
          font-size: 13px;
          color: #6b7280;
        }

        .summary-card.primary .summary-label,
        .summary-card.primary .summary-sub {
          color: rgba(255,255,255,0.8);
        }

        .summary-value {
          margin-top: 8px;
          font-size: 28px;
          font-weight: 900;
          letter-spacing: -0.03em;
        }

        .summary-sub {
          margin-top: 8px;
          font-size: 13px;
          color: #6b7280;
          line-height: 1.5;
        }

        .message-box {
          margin-bottom: 14px;
          padding: 12px 14px;
          border-radius: 12px;
          border: 1px solid #d1d5db;
          background: #fff;
          font-weight: 800;
        }

        .section-title-row {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 12px;
          margin-bottom: 14px;
        }

        .section-title {
          margin: 0;
          font-size: 20px;
          font-weight: 900;
        }

        .section-desc {
          margin-top: 6px;
          color: #6b7280;
          font-size: 14px;
          line-height: 1.6;
        }

        .preview-panel,
        .line-panel {
          overflow: hidden;
          margin-top: 12px;
        }

        .desktop-table {
          display: block;
          overflow-x: auto;
        }

        .preview-grid {
          min-width: 980px;
        }

        .line-grid {
          min-width: 980px;
        }

        .table-head,
        .table-row {
          display: grid;
          gap: 10px;
          padding: 14px 16px;
          align-items: center;
        }

        .table-head {
          background: #f9fafb;
          border-bottom: 1px solid #e5e7eb;
          font-size: 13px;
          font-weight: 900;
          color: #374151;
        }

        .preview-grid .table-head,
        .preview-grid .table-row {
          grid-template-columns: 260px 110px 140px 110px 140px 1fr;
        }

        .line-grid .table-head,
        .line-grid .table-row {
          grid-template-columns: 260px 100px 140px 140px 120px 240px;
        }

        .table-row {
          border-bottom: 1px solid #f1f5f9;
          font-size: 14px;
        }

        .table-row:last-child {
          border-bottom: 0;
        }

        .right {
          text-align: right;
          font-weight: 900;
        }

        .cell-title {
          font-weight: 900;
        }

        .cell-sub {
          margin-top: 4px;
          font-size: 13px;
          color: #6b7280;
        }

        .status-badge {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          min-height: 32px;
          padding: 0 10px;
          border-radius: 999px;
          font-size: 12px;
          font-weight: 900;
          border: 1px solid #e5e7eb;
          background: #f3f4f6;
          color: #374151;
        }

        .status-badge.dark {
          background: #111827;
          color: #fff;
          border-color: #111827;
        }

        .period-grid {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 12px;
          margin-top: 12px;
        }

        .period-card {
          padding: 14px;
          cursor: pointer;
        }

        .period-card.active {
          border-color: #111827;
          box-shadow: 0 0 0 2px rgba(17,24,39,0.06);
        }

        .period-top {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 10px;
        }

        .period-key {
          font-size: 16px;
          font-weight: 900;
        }

        .period-meta {
          margin-top: 10px;
          display: grid;
          gap: 6px;
          font-size: 14px;
          color: #374151;
        }

        .mobile-list {
          display: none;
          gap: 12px;
          padding: 14px;
        }

        .line-card,
        .preview-card {
          padding: 14px;
          background: #fbfcfe;
        }

        .mobile-top {
          display: flex;
          justify-content: space-between;
          gap: 12px;
          align-items: flex-start;
        }

        .mobile-title {
          font-size: 15px;
          font-weight: 900;
        }

        .mobile-sub {
          margin-top: 6px;
          font-size: 13px;
          color: #6b7280;
          line-height: 1.5;
        }

        .mobile-amount {
          font-size: 20px;
          font-weight: 900;
          white-space: nowrap;
        }

        .mobile-meta {
          margin-top: 12px;
          display: grid;
          gap: 8px;
        }

        .mobile-meta-row {
          display: flex;
          justify-content: space-between;
          gap: 12px;
          font-size: 14px;
        }

        .mobile-label {
          color: #6b7280;
          flex: 0 0 90px;
        }

        .mobile-value {
          flex: 1;
          text-align: right;
          word-break: break-word;
        }

        .mobile-actions {
          margin-top: 12px;
          display: flex;
          gap: 8px;
          flex-wrap: wrap;
        }

        .empty-box {
          padding: 18px;
          text-align: center;
          color: #6b7280;
        }

        @media (max-width: 1100px) {
          .filter-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
          }

          .summary-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
          }

          .period-grid {
            grid-template-columns: repeat(2, minmax(0, 1fr));
          }
        }

        @media (max-width: 760px) {
          .page-shell {
            padding: 16px;
          }

          .page-header,
          .section-title-row {
            flex-direction: column;
            align-items: stretch;
          }

          .top-actions,
          .field-row,
          .mobile-actions {
            flex-direction: column;
          }

          .filter-grid,
          .summary-grid,
          .period-grid {
            grid-template-columns: 1fr;
          }

          .input,
          .select,
          .ghost-btn,
          .solid-btn,
          .back-btn,
          .danger-btn,
          .excel-btn,
          .chip-btn,
          .tiny-btn,
          .date-input {
            width: 100%;
          }

          .desktop-table {
            display: none;
          }

          .mobile-list {
            display: grid;
          }

          .info-strip {
            flex-direction: column;
            align-items: flex-start;
          }
        }

        @media (max-width: 520px) {
          .mobile-top,
          .mobile-meta-row {
            flex-direction: column;
            align-items: flex-start;
          }

          .mobile-value {
            text-align: left;
          }

          .mobile-amount {
            white-space: normal;
          }
        }
      `}</style>

      <header className="page-header">
        <div>
          <h1 className="page-title">월 정산 관리</h1>
          <div className="page-sub">
            1) 정산 미리보기 조회 → 2) 정산 마감 → 3) 업체별 지급완료 처리
          </div>
        </div>

        <div className="top-actions">
          <a href={excelUrl} className="excel-btn">
            미리보기 엑셀
          </a>

          <a
            href={
              selectedPeriodKey
                ? `/api/admin/settlements/excel-closed?periodKey=${selectedPeriodKey}`
                : "#"
            }
            className="excel-btn"
            style={{
              pointerEvents: selectedPeriodKey ? "auto" : "none",
              opacity: selectedPeriodKey ? 1 : 0.5,
            }}
          >
            정산 엑셀
          </a>

          <a href="/admin" className="back-btn">
            대시보드로
          </a>
        </div>
      </header>

      <section className="filter-panel">
        <div className="filter-grid">
          <div className="field">
            <span className="field-label">기간 빠른 선택</span>
            <div className="field-row">
              <button onClick={setThisMonth} className="chip-btn" type="button">
                이번달
              </button>
              <button onClick={setLastMonth} className="chip-btn" type="button">
                지난달
              </button>
            </div>
          </div>

          <div className="field">
            <span className="field-label">기간 입력</span>
            <div className="field-row">
              <input
                value={from}
                onChange={(e) => setFrom(e.target.value)}
                placeholder="YYYY-MM-DD"
                className="input date-input"
              />
              <input
                value={to}
                onChange={(e) => setTo(e.target.value)}
                placeholder="YYYY-MM-DD"
                className="input date-input"
              />
            </div>
          </div>

          <label className="field">
            <span className="field-label">업체 검색</span>
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="상대방 검색 (아이디/이름)"
              className="input"
            />
          </label>

          <button onClick={loadPreview} className="ghost-btn" type="button">
            새로고침
          </button>

          <button onClick={closePeriod} className="solid-btn" type="button">
            정산 마감
          </button>
        </div>
      </section>

      {msg && <div className="message-box">{msg}</div>}
      {closeMsg && <div className="message-box">{closeMsg}</div>}

      <section className="summary-grid">
        <div className="summary-card primary">
          <div className="summary-label">업체 수</div>
          <div className="summary-value">
            {formatNumber(previewTotals.totalCounterparties)}
          </div>
          <div className="summary-sub">현재 미리보기 정산 대상 수</div>
        </div>

        <div className="summary-card">
          <div className="summary-label">사용 건수</div>
          <div className="summary-value">
            {formatNumber(previewTotals.totalUseCount)}건
          </div>
          <div className="summary-sub">기간 내 사용 건수</div>
        </div>

        <div className="summary-card">
          <div className="summary-label">사용 포인트</div>
          <div className="summary-value">
            {formatNumber(previewTotals.totalUsedPoints)}P
          </div>
          <div className="summary-sub">기간 내 사용 포인트 합계</div>
        </div>

        <div className="summary-card">
          <div className="summary-label">예상 지급액</div>
          <div className="summary-value">
            {formatNumber(previewTotals.totalNetPayable)}P
          </div>
          <div className="summary-sub">지급 예정 합계</div>
        </div>
      </section>

      <section className="section-card">
        <div className="section-title-row">
          <div>
            <h2 className="section-title">정산 미리보기</h2>
            <div className="section-desc">
              {loading ? "불러오는 중..." : `미리보기 ${preview.length}건`}
            </div>
          </div>
        </div>

        <section className="preview-panel list-panel">
          {loading ? (
            <div className="empty-box">불러오는 중...</div>
          ) : preview.length === 0 ? (
            <div className="empty-box">집계 내역이 없습니다.</div>
          ) : (
            <>
              <div className="desktop-table">
                <div className="preview-grid">
                  <div className="table-head">
                    <div>상대방(업체)</div>
                    <div>역할</div>
                    <div className="right">사용포인트</div>
                    <div className="right">건수</div>
                    <div className="right">예상 지급액</div>
                    <div>마지막 사용일시</div>
                  </div>

                  {preview.map((it, idx) => {
                    const previewNetPayable = Number(it.usedPoints || 0);

                    return (
                      <div key={`${it.counterpartyId ?? "null"}-${idx}`} className="table-row">
                        <div>
                          <div className="cell-title">
                            {it.counterparty
                              ? `${it.counterparty.name} (${it.counterparty.username})`
                              : "-"}
                          </div>
                          <div className="cell-sub">
                            {userStatusLabel(it.counterparty?.status)}
                          </div>
                        </div>

                        <div>{it.counterparty ? roleLabel(it.counterparty.role) : "-"}</div>

                        <div className="right">{formatNumber(it.usedPoints)}P</div>
                        <div className="right">{formatNumber(it.useCount)}건</div>
                        <div className="right">{formatNumber(previewNetPayable)}P</div>

                        <div>
                          {it.lastUsedAt ? new Date(it.lastUsedAt).toLocaleString() : "-"}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="mobile-list">
                {preview.map((it, idx) => {
                  const previewNetPayable = Number(it.usedPoints || 0);

                  return (
                    <article key={`${it.counterpartyId ?? "null"}-${idx}`} className="preview-card">
                      <div className="mobile-top">
                        <div>
                          <div className="mobile-title">
                            {it.counterparty
                              ? `${it.counterparty.name} (${it.counterparty.username})`
                              : "-"}
                          </div>
                          <div className="mobile-sub">
                            역할: {it.counterparty ? roleLabel(it.counterparty.role) : "-"}
                            <br />
                            상태: {userStatusLabel(it.counterparty?.status)}
                          </div>
                        </div>

                        <div className="mobile-amount">{formatNumber(previewNetPayable)}P</div>
                      </div>

                      <div className="mobile-meta">
                        <div className="mobile-meta-row">
                          <span className="mobile-label">사용포인트</span>
                          <span className="mobile-value">{formatNumber(it.usedPoints)}P</span>
                        </div>

                        <div className="mobile-meta-row">
                          <span className="mobile-label">건수</span>
                          <span className="mobile-value">{formatNumber(it.useCount)}건</span>
                        </div>

                        <div className="mobile-meta-row">
                          <span className="mobile-label">마지막 사용일시</span>
                          <span className="mobile-value">
                            {it.lastUsedAt ? new Date(it.lastUsedAt).toLocaleString() : "-"}
                          </span>
                        </div>
                      </div>
                    </article>
                  );
                })}
              </div>
            </>
          )}
        </section>
      </section>

      <div style={{ height: 16 }} />

      <section className="section-card">
        <div className="section-title-row">
          <div>
            <h2 className="section-title">마감된 정산 조회 / 지급 처리</h2>
            <div className="section-desc">
              마감된 기간을 선택하면 업체별 지급액을 확인하고 지급완료 처리할 수 있습니다.
            </div>
          </div>

          <div className="top-actions">
            <button onClick={loadPeriods} className="ghost-btn" type="button">
              기간 새로고침
            </button>

            <select
              value={selectedPeriodKey}
              onChange={(e) => setSelectedPeriodKey(e.target.value)}
              className="select"
            >
              <option value="">기간 선택</option>
              {periods.map((p) => (
                <option key={p.periodKey} value={p.periodKey}>
                  {p.periodKey} ({settlementStatusLabel(p.status)})
                </option>
              ))}
            </select>
          </div>
        </div>

        {periodErr && <div className="message-box">{periodErr}</div>}

        <div className="section-desc">
          {periodLoading ? "불러오는 중..." : `기간 ${periods.length}개`}
        </div>

        {periods.length > 0 && (
          <div className="period-grid">
            {periods.map((p) => (
              <button
                key={p.periodKey}
                type="button"
                onClick={() => setSelectedPeriodKey(p.periodKey)}
                className={`period-card ${selectedPeriodKey === p.periodKey ? "active" : ""}`}
                style={{ textAlign: "left" }}
              >
                <div className="period-top">
                  <div className="period-key">{p.periodKey}</div>
                  <span className={`status-badge ${p.status === "PAID" ? "dark" : ""}`}>
                    {settlementStatusLabel(p.status)}
                  </span>
                </div>

                <div className="period-meta">
                  <div>업체 {formatNumber(p.totalCounterparties)}개</div>
                  <div>건수 {formatNumber(p.totalUseCount)}건</div>
                  <div>사용포인트 {formatNumber(p.totalUsedPoints)}P</div>
                </div>
              </button>
            ))}
          </div>
        )}

        {selectedPeriod && (
          <div className="info-strip" style={{ marginTop: 14 }}>
            <div>
              기간: <b>{selectedPeriod.periodKey}</b>
            </div>
            <div>업체 {formatNumber(selectedPeriod.totalCounterparties)}개</div>
            <div>건수 {formatNumber(selectedPeriod.totalUseCount)}건</div>
            <div>사용포인트 {formatNumber(selectedPeriod.totalUsedPoints)}P</div>
            <div>상태: {settlementStatusLabel(selectedPeriod.status)}</div>
          </div>
        )}

        {linesErr && <div className="message-box" style={{ marginTop: 12 }}>{linesErr}</div>}

        <div className="section-desc" style={{ marginTop: 12 }}>
          {linesLoading
            ? "불러오는 중..."
            : selectedPeriodKey
            ? `라인 ${lines.length}개`
            : "기간을 선택하세요"}
        </div>

        {selectedPeriodKey && (
          <section className="line-panel list-panel">
            {linesLoading ? (
              <div className="empty-box">불러오는 중...</div>
            ) : lines.length === 0 ? (
              <div className="empty-box">라인이 없습니다.</div>
            ) : (
              <>
                <div className="desktop-table">
                  <div className="line-grid">
                    <div className="table-head">
                      <div>업체</div>
                      <div>상태</div>
                      <div className="right">사용포인트</div>
                      <div className="right">지급액</div>
                      <div className="right">건수</div>
                      <div className="right">처리</div>
                    </div>

                    {lines.map((l) => (
                      <div key={l.id} className="table-row">
                        <div>
                          <div className="cell-title">
                            {l.counterparty
                              ? `${l.counterparty.name} (${l.counterparty.username})`
                              : "-"}
                          </div>
                          <div className="cell-sub">
                            {l.counterparty ? roleLabel(l.counterparty.role) : "-"}
                          </div>
                        </div>

                        <div>
                          <span className={`status-badge ${l.status === "PAID" ? "dark" : ""}`}>
                            {settlementStatusLabel(l.status)}
                          </span>
                        </div>

                        <div className="right">{formatNumber(l.usedPoints)}P</div>
                        <div className="right">{formatNumber(l.netPayable)}P</div>
                        <div className="right">{formatNumber(l.useCount)}건</div>

                        <div
                          className="right"
                          style={{
                            display: "flex",
                            justifyContent: "flex-end",
                            gap: 8,
                            flexWrap: "wrap",
                          }}
                        >
                          <a
                            href={
                              l.counterparty?.id
                                ? `/api/admin/settlements/pdf?periodKey=${selectedPeriodKey}&counterpartyId=${l.counterparty.id}`
                                : "#"
                            }
                            target="_blank"
                            className="tiny-btn light"
                            style={{
                              pointerEvents: l.counterparty?.id ? "auto" : "none",
                              opacity: l.counterparty?.id ? 1 : 0.5,
                            }}
                          >
                            정산서
                          </a>

                          <button
                            disabled={l.status === "PAID"}
                            onClick={() => markPaid(l)}
                            className="tiny-btn"
                            type="button"
                            style={{
                              opacity: l.status === "PAID" ? 0.5 : 1,
                              cursor: l.status === "PAID" ? "not-allowed" : "pointer",
                            }}
                          >
                            지급완료
                          </button>

                          {l.status === "PAID" && (
                            <button
                              onClick={() => cancelPaid(l)}
                              className="tiny-btn cancel"
                              type="button"
                            >
                              지급취소
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mobile-list">
                  {lines.map((l) => (
                    <article key={l.id} className="line-card">
                      <div className="mobile-top">
                        <div>
                          <div className="mobile-title">
                            {l.counterparty
                              ? `${l.counterparty.name} (${l.counterparty.username})`
                              : "-"}
                          </div>
                          <div className="mobile-sub">
                            역할: {l.counterparty ? roleLabel(l.counterparty.role) : "-"}
                            <br />
                            상태: {settlementStatusLabel(l.status)}
                          </div>
                        </div>

                        <div className="mobile-amount">{formatNumber(l.netPayable)}P</div>
                      </div>

                      <div className="mobile-meta">
                        <div className="mobile-meta-row">
                          <span className="mobile-label">사용포인트</span>
                          <span className="mobile-value">{formatNumber(l.usedPoints)}P</span>
                        </div>

                        <div className="mobile-meta-row">
                          <span className="mobile-label">지급액</span>
                          <span className="mobile-value">{formatNumber(l.netPayable)}P</span>
                        </div>

                        <div className="mobile-meta-row">
                          <span className="mobile-label">건수</span>
                          <span className="mobile-value">{formatNumber(l.useCount)}건</span>
                        </div>

                        <div className="mobile-meta-row">
                          <span className="mobile-label">지급참조</span>
                          <span className="mobile-value">{l.payoutRef || "-"}</span>
                        </div>

                        <div className="mobile-meta-row">
                          <span className="mobile-label">메모</span>
                          <span className="mobile-value">{l.note || "-"}</span>
                        </div>
                      </div>

                      <div className="mobile-actions">
                        <a
                          href={
                            l.counterparty?.id
                              ? `/api/admin/settlements/pdf?periodKey=${selectedPeriodKey}&counterpartyId=${l.counterparty.id}`
                              : "#"
                          }
                          target="_blank"
                          className="ghost-btn"
                          style={{
                            pointerEvents: l.counterparty?.id ? "auto" : "none",
                            opacity: l.counterparty?.id ? 1 : 0.5,
                          }}
                        >
                          정산서
                        </a>

                        <button
                          disabled={l.status === "PAID"}
                          onClick={() => markPaid(l)}
                          className="solid-btn"
                          type="button"
                          style={{
                            opacity: l.status === "PAID" ? 0.5 : 1,
                            cursor: l.status === "PAID" ? "not-allowed" : "pointer",
                          }}
                        >
                          지급완료
                        </button>

                        {l.status === "PAID" && (
                          <button
                            onClick={() => cancelPaid(l)}
                            className="danger-btn"
                            type="button"
                          >
                            지급취소
                          </button>
                        )}
                      </div>
                    </article>
                  ))}
                </div>
              </>
            )}
          </section>
        )}
      </section>
    </main>
  );
}