// src/app/admin/accounts/page.tsx
// =======================================================
// ADMIN 계정 잔액 페이지
// -------------------------------------------------------
// ✔ PARTNER / CUSTOMER / ADMIN 잔액 조회
// ✔ Ledger 기반 잔액
// =======================================================

"use client";

import { useEffect, useMemo, useState } from "react";

type AccountItem = {
  id: string;
  username: string;
  name: string;
  role: string;
  status: string;
  balance: number;
};

function formatNumber(n: number) {
  return Number(n || 0).toLocaleString();
}

function roleLabel(r: string) {
  if (r === "PARTNER") return "제휴사";
  if (r === "CUSTOMER") return "고객";
  if (r === "ADMIN") return "관리자";
  return r;
}

function statusLabel(s: string) {
  if (s === "ACTIVE") return "활성";
  if (s === "PENDING") return "대기";
  if (s === "BLOCKED") return "차단";
  return s;
}

export default function AdminAccountsPage() {
  const [items, setItems] = useState<AccountItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");
  const [keyword, setKeyword] = useState("");
  const [roleFilter, setRoleFilter] = useState<"ALL" | "PARTNER" | "CUSTOMER" | "ADMIN">("ALL");

  async function load() {
    setLoading(true);
    setMsg("");

    try {
      const res = await fetch("/api/admin/accounts", { cache: "no-store" });
      const data = await res.json();

      if (!res.ok || !data?.ok) {
        setMsg(data?.message ?? "조회 실패");
        setItems([]);
        setLoading(false);
        return;
      }

      setItems(Array.isArray(data?.items) ? data.items : []);
    } catch {
      setMsg("네트워크 오류");
      setItems([]);
    }

    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  const filteredItems = useMemo(() => {
    return items.filter((it) => {
      if (roleFilter !== "ALL" && it.role !== roleFilter) return false;

      const q = keyword.trim().toLowerCase();
      if (!q) return true;

      return (
        String(it.username ?? "").toLowerCase().includes(q) ||
        String(it.name ?? "").toLowerCase().includes(q)
      );
    });
  }, [items, keyword, roleFilter]);

  return (
    <main style={{ maxWidth: 1200, margin: "40px auto", padding: 16 }}>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
          gap: 12,
          flexWrap: "wrap",
        }}
      >
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 900, margin: 0 }}>계정 잔액</h1>
          <p style={{ marginTop: 10, opacity: 0.7 }}>
            모든 계정의 포인트 잔액을 확인합니다. (Ledger 합산)
          </p>
        </div>

        <a
          href="/admin"
          style={{
            padding: "10px 14px",
            borderRadius: 12,
            border: "1px solid #ccc",
            background: "#f5f5f5",
            textDecoration: "none",
            color: "#111",
            fontWeight: 900,
          }}
        >
          대시보드
        </a>
      </div>

      <div
        style={{
          marginTop: 16,
          display: "grid",
          gridTemplateColumns: "1fr 180px 120px",
          gap: 10,
        }}
      >
        <input
          value={keyword}
          onChange={(e) => setKeyword(e.target.value)}
          placeholder="아이디 / 이름 검색"
          style={{
            height: 42,
            borderRadius: 10,
            border: "1px solid #d1d5db",
            padding: "0 12px",
          }}
        />

        <select
          value={roleFilter}
          onChange={(e) =>
            setRoleFilter(e.target.value as "ALL" | "PARTNER" | "CUSTOMER" | "ADMIN")
          }
          style={{
            height: 42,
            borderRadius: 10,
            border: "1px solid #d1d5db",
            padding: "0 12px",
            background: "#fff",
          }}
        >
          <option value="ALL">전체 역할</option>
          <option value="PARTNER">제휴사</option>
          <option value="CUSTOMER">고객</option>
          <option value="ADMIN">관리자</option>
        </select>

        <button
          type="button"
          onClick={load}
          style={{
            height: 42,
            borderRadius: 10,
            border: "1px solid #111827",
            background: "#111827",
            color: "#fff",
            fontWeight: 800,
            cursor: "pointer",
          }}
        >
          새로고침
        </button>
      </div>

      {msg ? (
        <div
          style={{
            marginTop: 12,
            borderRadius: 10,
            background: "#fef2f2",
            color: "#991b1b",
            border: "1px solid #fecaca",
            padding: 12,
          }}
        >
          {msg}
        </div>
      ) : null}

      <p style={{ marginTop: 12 }}>
        {loading ? "불러오는 중..." : `총 ${filteredItems.length}개 계정`}
      </p>

      <div
        style={{
          marginTop: 10,
          border: "1px solid #ddd",
          borderRadius: 12,
          overflow: "hidden",
        }}
      >
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "220px 180px 140px 120px 180px",
            padding: 12,
            fontWeight: 900,
            background: "#f5f5f5",
          }}
        >
          <div>아이디</div>
          <div>이름</div>
          <div>역할</div>
          <div>상태</div>
          <div>잔액</div>
        </div>

        {filteredItems.map((it) => (
          <div
            key={it.id}
            style={{
              display: "grid",
              gridTemplateColumns: "220px 180px 140px 120px 180px",
              padding: 12,
              borderTop: "1px solid #eee",
            }}
          >
            <div>{it.username}</div>
            <div>{it.name}</div>
            <div>{roleLabel(it.role)}</div>
            <div>{statusLabel(it.status)}</div>
            <div style={{ fontWeight: 900 }}>{formatNumber(it.balance)}P</div>
          </div>
        ))}

        {!loading && filteredItems.length === 0 ? (
          <div style={{ padding: 20, color: "#6b7280" }}>조회 결과가 없습니다.</div>
        ) : null}
      </div>
    </main>
  );
}