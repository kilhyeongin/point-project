"use client";

import { useEffect, useMemo, useState } from "react";

type Item = {
  id: string;
  amount: number;
  status: string;
  note?: string;
  createdAt: string;
  decidedAt?: string | null;
  account: { id: string; username: string; name: string; role: string } | null;
  requestedBy?: { username: string; name: string; role: string } | null;
  approvedBy?: { username: string; name: string; role: string } | null;
};

function formatNumber(n: number) {
  return Number(n || 0).toLocaleString();
}

function roleLabel(role?: string) {
  if (role === "PARTNER") return "제휴사";
  if (role === "CUSTOMER") return "고객";
  if (role === "ADMIN") return "총괄관리자";
  return role || "-";
}

function statusLabel(status?: string) {
  if (status === "PENDING") return "대기";
  if (status === "APPROVED") return "승인완료";
  if (status === "REJECTED") return "거절";
  return status || "-";
}

export default function Page() {
  const [items, setItems] = useState<Item[]>([]);
  const [msg, setMsg] = useState("");
  const [loading, setLoading] = useState(false);
  const [workingId, setWorkingId] = useState<string | null>(null);

  const pendingCount = useMemo(
    () => items.filter((it) => it.status === "PENDING").length,
    [items]
  );

  async function load() {
    setLoading(true);
    setMsg("");

    try {
      const res = await fetch("/api/admin/topup-requests");
      const data = await res.json();

      if (!res.ok) {
        setItems([]);
        setMsg(data?.message ?? "목록 조회 실패");
        return;
      }

      setItems(data.items || []);
    } catch {
      setItems([]);
      setMsg("네트워크 오류");
    } finally {
      setLoading(false);
    }
  }

  async function approve(id: string) {
    setMsg("");
    setWorkingId(id);

    try {
      const res = await fetch(`/api/admin/topup-requests/${id}/approve`, {
        method: "PATCH",
      });

      const data = await res.json();

      if (!res.ok || !data.ok) {
        setMsg(data?.message ?? "승인 실패");
        return;
      }

      setMsg("✅ 충전 요청을 승인했습니다.");
      await load();
    } catch {
      setMsg("네트워크 오류");
    } finally {
      setWorkingId(null);
    }
  }

  useEffect(() => {
    load();
  }, []);

  return (
    <main className="page-shell">
      <style>{`
        .page-shell {
          max-width: 1100px;
          margin: 0 auto;
          padding: 20px;
          min-height: 100vh;
          background: #f5f7fb;
          color: #111827;
        }

        .page-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 12px;
          margin-bottom: 18px;
        }

        .page-title {
          margin: 0;
          font-size: 28px;
          font-weight: 900;
          letter-spacing: -0.02em;
        }

        .page-sub {
          margin-top: 8px;
          color: #6b7280;
          font-size: 14px;
          line-height: 1.6;
        }

        .top-actions {
          display: flex;
          gap: 8px;
          flex-wrap: wrap;
        }

        .ghost-btn,
        .solid-btn,
        .back-btn {
          min-height: 44px;
          padding: 0 14px;
          border-radius: 12px;
          font-weight: 800;
          cursor: pointer;
          text-decoration: none;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          transition: all 0.15s ease;
        }

        .ghost-btn,
        .back-btn {
          border: 1px solid #d1d5db;
          background: #fff;
          color: #111827;
        }

        .solid-btn {
          border: 1px solid #111827;
          background: #111827;
          color: #fff;
        }

        .summary-grid {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 12px;
          margin-bottom: 16px;
        }

        .summary-card {
          background: #fff;
          border: 1px solid #e5e7eb;
          border-radius: 18px;
          padding: 16px;
          box-shadow: 0 8px 24px rgba(15, 23, 42, 0.04);
        }

        .summary-label {
          font-size: 13px;
          color: #6b7280;
        }

        .summary-value {
          margin-top: 8px;
          font-size: 28px;
          font-weight: 900;
          letter-spacing: -0.03em;
        }

        .summary-sub {
          margin-top: 8px;
          font-size: 13px;
          color: #6b7280;
        }

        .message-box {
          margin-bottom: 14px;
          padding: 12px 14px;
          border-radius: 12px;
          border: 1px solid #d1d5db;
          background: #fff;
          font-weight: 800;
        }

        .list-wrap {
          display: grid;
          gap: 12px;
        }

        .request-card {
          background: #fff;
          border: 1px solid #e5e7eb;
          border-radius: 18px;
          padding: 16px;
          box-shadow: 0 8px 24px rgba(15, 23, 42, 0.04);
        }

        .request-top {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 16px;
        }

        .request-name {
          font-size: 17px;
          font-weight: 900;
        }

        .request-role {
          margin-top: 4px;
          font-size: 13px;
          color: #6b7280;
        }

        .request-amount {
          font-size: 24px;
          font-weight: 900;
          white-space: nowrap;
          letter-spacing: -0.02em;
        }

        .meta-grid {
          margin-top: 14px;
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 10px;
        }

        .meta-box {
          border: 1px solid #eef2f7;
          border-radius: 14px;
          padding: 12px;
          background: #f9fafb;
        }

        .meta-label {
          font-size: 12px;
          color: #6b7280;
        }

        .meta-value {
          margin-top: 6px;
          font-size: 14px;
          font-weight: 700;
          line-height: 1.5;
          word-break: break-word;
        }

        .request-actions {
          margin-top: 14px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 10px;
          flex-wrap: wrap;
        }

        .status-badge {
          display: inline-flex;
          align-items: center;
          min-height: 34px;
          padding: 0 12px;
          border-radius: 999px;
          font-size: 13px;
          font-weight: 900;
          background: #f3f4f6;
          color: #374151;
          border: 1px solid #e5e7eb;
        }

        .empty-box {
          padding: 18px;
          text-align: center;
          color: #6b7280;
          border: 1px dashed #cbd5e1;
          border-radius: 16px;
          background: #fff;
        }

        @media (max-width: 760px) {
          .page-shell {
            padding: 16px;
          }

          .page-header {
            flex-direction: column;
            align-items: stretch;
          }

          .summary-grid {
            grid-template-columns: 1fr;
          }

          .request-top {
            flex-direction: column;
          }

          .request-amount {
            white-space: normal;
          }

          .meta-grid {
            grid-template-columns: 1fr;
          }

          .request-actions {
            flex-direction: column;
            align-items: stretch;
          }

          .solid-btn,
          .ghost-btn,
          .back-btn {
            width: 100%;
          }
        }
      `}</style>

      <header className="page-header">
        <div>
          <h1 className="page-title">포인트 충전 승인</h1>
          <div className="page-sub">
            제휴사의 충전 요청을 승인하면 해당 계정 잔액에 즉시 반영됩니다.
          </div>
        </div>

        <div className="top-actions">
          <button onClick={load} className="ghost-btn" type="button">
            새로고침
          </button>
          <a href="/admin" className="back-btn">
            대시보드로
          </a>
        </div>
      </header>

      <section className="summary-grid">
        <div className="summary-card">
          <div className="summary-label">전체 요청</div>
          <div className="summary-value">{formatNumber(items.length)}건</div>
          <div className="summary-sub">현재 조회된 충전 요청</div>
        </div>

        <div className="summary-card">
          <div className="summary-label">승인 대기</div>
          <div className="summary-value">{formatNumber(pendingCount)}건</div>
          <div className="summary-sub">처리가 필요한 요청 수</div>
        </div>

        <div className="summary-card">
          <div className="summary-label">로딩 상태</div>
          <div className="summary-value">{loading ? "조회중" : "완료"}</div>
          <div className="summary-sub">목록 동기화 상태</div>
        </div>
      </section>

      {msg && <div className="message-box">{msg}</div>}

      <section className="list-wrap">
        {loading ? (
          <div className="empty-box">불러오는 중...</div>
        ) : items.length === 0 ? (
          <div className="empty-box">충전 요청이 없습니다.</div>
        ) : (
          items.map((it) => (
            <article key={it.id} className="request-card">
              <div className="request-top">
                <div>
                  <div className="request-name">
                    {it.account?.name ?? "-"} ({it.account?.username ?? "-"})
                  </div>
                  <div className="request-role">
                    대상 역할: {roleLabel(it.account?.role)}
                  </div>
                </div>

                <div className="request-amount">{formatNumber(it.amount)}P</div>
              </div>

              <div className="meta-grid">
                <div className="meta-box">
                  <div className="meta-label">상태</div>
                  <div className="meta-value">{statusLabel(it.status)}</div>
                </div>

                <div className="meta-box">
                  <div className="meta-label">요청일</div>
                  <div className="meta-value">
                    {it.createdAt ? new Date(it.createdAt).toLocaleString() : "-"}
                  </div>
                </div>

                <div className="meta-box">
                  <div className="meta-label">요청자</div>
                  <div className="meta-value">
                    {it.requestedBy
                      ? `${it.requestedBy.name} (${it.requestedBy.username})`
                      : "-"}
                  </div>
                </div>

                <div className="meta-box">
                  <div className="meta-label">승인자 / 처리일</div>
                  <div className="meta-value">
                    {it.approvedBy
                      ? `${it.approvedBy.name} (${it.approvedBy.username})`
                      : "-"}
                    <br />
                    {it.decidedAt ? new Date(it.decidedAt).toLocaleString() : "-"}
                  </div>
                </div>

                <div className="meta-box" style={{ gridColumn: "1 / -1" }}>
                  <div className="meta-label">메모</div>
                  <div className="meta-value">{it.note || "-"}</div>
                </div>
              </div>

              <div className="request-actions">
                <span className="status-badge">{statusLabel(it.status)}</span>

                {it.status === "PENDING" ? (
                  <button
                    onClick={() => approve(it.id)}
                    className="solid-btn"
                    type="button"
                    disabled={workingId === it.id}
                  >
                    {workingId === it.id ? "처리 중..." : "승인"}
                  </button>
                ) : (
                  <button className="ghost-btn" type="button" disabled>
                    처리 완료
                  </button>
                )}
              </div>
            </article>
          ))
        )}
      </section>
    </main>
  );
}