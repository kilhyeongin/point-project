// src/app/customer/FavoritePartnerButton.tsx
"use client";

import { useEffect, useState } from "react";

type Props = {
  partnerId: string;
  initialFavorite: boolean;
  onChange?: (next: boolean) => void;
  onChanged?: (next: boolean) => void;
};

type ToggleResponse = {
  ok: boolean;
  isFavorite?: boolean;
  message?: string;
  error?: string;
};

export default function FavoritePartnerButton({
  partnerId,
  initialFavorite,
  onChange,
  onChanged,
}: Props) {
  const [favorite, setFavorite] = useState(Boolean(initialFavorite));
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setFavorite(Boolean(initialFavorite));
  }, [initialFavorite]);

  async function toggleFavorite() {
    if (loading) return;

    setLoading(true);

    try {
      const res = await fetch(`/api/customer/favorites/${partnerId}`, {
        method: favorite ? "DELETE" : "POST",
      });

      const data: ToggleResponse = await res.json();

      if (!res.ok || !data?.ok) {
        return;
      }

      const next = Boolean(data.isFavorite);
      setFavorite(next);

      onChange?.(next);
      onChanged?.(next);
    } catch {
      // noop
    } finally {
      setLoading(false);
    }
  }

  return (
    <button
      type="button"
      onClick={toggleFavorite}
      disabled={loading}
      aria-pressed={favorite}
      style={{
        border: favorite ? "1px solid #f59e0b" : "1px solid #d1d5db",
        background: favorite ? "#fffbeb" : "#fff",
        color: favorite ? "#b45309" : "#374151",
        borderRadius: 999,
        padding: "10px 14px",
        fontWeight: 800,
        cursor: loading ? "not-allowed" : "pointer",
        whiteSpace: "nowrap",
        transition: "all 0.15s ease",
      }}
      title={favorite ? "관심업체 저장됨" : "관심업체 저장"}
    >
      {loading
        ? "처리 중..."
        : favorite
        ? "관심업체 저장됨"
        : "관심업체 저장"}
    </button>
  );
}