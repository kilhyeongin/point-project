"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import CustomerShellClient from "./CustomerShellClient";
import FavoritePartnerButton from "./FavoritePartnerButton";

type SessionInfo = {
  uid: string;
  username: string;
  name: string;
  role: string;
};

type PartnerItem = {
  id: string;
  name: string;
  category: string;
  categories?: string[];
  categoryLabels?: string[];
  intro: string;
  benefitText: string;
  address: string;
  phone: string;
  coverImageUrl: string;
  isFavorite?: boolean;
  score?: number;
  matchedInterests?: string[];
  matchedInterestLabels?: string[];
};

type BalanceResponse = {
  ok: boolean;
  balance?: number;
  message?: string;
  error?: string;
};

type PartnersResponse = {
  ok: boolean;
  items?: PartnerItem[];
  message?: string;
  error?: string;
};

type RecommendationResponse = {
  ok: boolean;
  onboardingCompleted?: boolean;
  interests?: string[];
  interestLabels?: string[];
  items?: PartnerItem[];
  message?: string;
  error?: string;
};

type Props = {
  session: SessionInfo;
};

function formatPoint(value: number) {
  return Number(value || 0).toLocaleString();
}

function EmptyState({ text }: { text: string }) {
  return (
    <div
      style={{
        border: "1px dashed #d1d5db",
        borderRadius: 16,
        padding: 28,
        background: "#fafafa",
        color: "#6b7280",
        textAlign: "center",
        fontWeight: 700,
        lineHeight: 1.8,
      }}
    >
      {text}
    </div>
  );
}

function Tag({
  text,
  strong = false,
}: {
  text: string;
  strong?: boolean;
}) {
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        height: 30,
        padding: "0 12px",
        borderRadius: 999,
        background: strong ? "#111827" : "#f3f4f6",
        color: strong ? "#fff" : "#374151",
        fontSize: 13,
        fontWeight: 800,
        border: strong ? "1px solid #111827" : "1px solid #e5e7eb",
      }}
    >
      {text}
    </span>
  );
}

function SectionCard({
  title,
  description,
  right,
  children,
}: {
  title: string;
  description?: string;
  right?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <section
      style={{
        border: "1px solid #e5e7eb",
        borderRadius: 20,
        padding: 20,
        background: "#fff",
        boxShadow: "0 4px 16px rgba(15,23,42,0.04)",
        display: "grid",
        gap: 18,
      }}
    >
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          gap: 12,
          alignItems: "center",
          flexWrap: "wrap",
        }}
      >
        <div>
          <div
            style={{
              fontSize: 24,
              fontWeight: 900,
              color: "#111827",
            }}
          >
            {title}
          </div>

          {description ? (
            <div style={{ marginTop: 6, color: "#6b7280", lineHeight: 1.6 }}>
              {description}
            </div>
          ) : null}
        </div>

        {right}
      </div>

      {children}
    </section>
  );
}

function PartnerCard({
  item,
  onFavoriteChanged,
  recommendationMode = false,
}: {
  item: PartnerItem;
  onFavoriteChanged?: (partnerId: string, next: boolean) => void;
  recommendationMode?: boolean;
}) {
  const imageUrl = item.coverImageUrl?.trim();

  return (
    <article
      style={{
        border: "1px solid #e5e7eb",
        borderRadius: 18,
        overflow: "hidden",
        background: "#fff",
        boxShadow: "0 4px 16px rgba(15,23,42,0.04)",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <div
        style={{
          width: "100%",
          aspectRatio: "16 / 10",
          background: "#f3f4f6",
          borderBottom: "1px solid #eef2f7",
          overflow: "hidden",
        }}
      >
        {imageUrl ? (
          <img
            src={imageUrl}
            alt={item.name}
            style={{
              width: "100%",
              height: "100%",
              objectFit: "cover",
              display: "block",
            }}
          />
        ) : (
          <div
            style={{
              width: "100%",
              height: "100%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "#9ca3af",
              fontWeight: 700,
              padding: 16,
              textAlign: "center",
            }}
          >
            대표 이미지가 등록되지 않았습니다.
          </div>
        )}
      </div>

      <div
        style={{
          padding: 18,
          display: "flex",
          flexDirection: "column",
          gap: 14,
          height: "100%",
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            gap: 12,
            alignItems: "flex-start",
            flexWrap: "wrap",
          }}
        >
          <div style={{ minWidth: 0, flex: 1 }}>
            <div
              style={{
                display: "flex",
                gap: 8,
                flexWrap: "wrap",
                marginBottom: 8,
              }}
            >
              {item.categoryLabels && item.categoryLabels.length > 0 ? (
                item.categoryLabels.map((label) => <Tag key={`${item.id}-${label}`} text={label} />)
              ) : (
                <Tag text={item.category || "기타"} />
              )}

              {recommendationMode && item.matchedInterestLabels?.length
                ? item.matchedInterestLabels.map((label) => (
                    <Tag key={`${item.id}-matched-${label}`} text={`${label} 관심사 일치`} strong />
                  ))
                : null}
            </div>

            <div
              style={{
                fontSize: 24,
                fontWeight: 900,
                color: "#111827",
                lineHeight: 1.2,
                wordBreak: "keep-all",
              }}
            >
              {item.name}
            </div>
          </div>

          <FavoritePartnerButton
            partnerId={item.id}
            initialFavorite={Boolean(item.isFavorite)}
            onChanged={(next) => onFavoriteChanged?.(item.id, next)}
          />
        </div>

        <div
          style={{
            color: "#374151",
            lineHeight: 1.8,
            minHeight: 72,
            whiteSpace: "pre-wrap",
            wordBreak: "keep-all",
          }}
        >
          {item.intro || "등록된 소개글이 없습니다."}
        </div>

        <div
          style={{
            padding: 14,
            borderRadius: 14,
            background: "#f9fafb",
            border: "1px solid #e5e7eb",
          }}
        >
          <div
            style={{
              fontSize: 13,
              color: "#6b7280",
              fontWeight: 800,
              marginBottom: 6,
            }}
          >
            제공 혜택
          </div>

          <div
            style={{
              color: "#111827",
              lineHeight: 1.7,
              fontWeight: 700,
              whiteSpace: "pre-wrap",
              wordBreak: "keep-all",
              minHeight: 44,
            }}
          >
            {item.benefitText || "등록된 혜택이 없습니다."}
          </div>
        </div>

        <div
          style={{
            display: "grid",
            gap: 8,
            color: "#4b5563",
            fontSize: 14,
          }}
        >
          <div>
            <span style={{ color: "#6b7280", fontWeight: 800 }}>주소</span>
            <span style={{ marginLeft: 8 }}>{item.address || "등록되지 않음"}</span>
          </div>

          <div>
            <span style={{ color: "#6b7280", fontWeight: 800 }}>연락처</span>
            <span style={{ marginLeft: 8 }}>{item.phone || "등록되지 않음"}</span>
          </div>
        </div>

        <div
          style={{
            display: "flex",
            gap: 10,
            flexWrap: "wrap",
            marginTop: "auto",
          }}
        >
          <Link
            href={`/customer/partner/${item.id}`}
            style={{
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
              flex: "1 1 160px",
              minHeight: 44,
              textDecoration: "none",
              padding: "0 16px",
              borderRadius: 12,
              border: "1px solid #111827",
              background: "#111827",
              color: "#fff",
              fontWeight: 800,
            }}
          >
            상세 보기
          </Link>
        </div>
      </div>
    </article>
  );
}

export default function CustomerDashboardClient({ session }: Props) {
  const [balance, setBalance] = useState(0);
  const [balanceLoading, setBalanceLoading] = useState(true);
  const [balanceError, setBalanceError] = useState("");

  const [items, setItems] = useState<PartnerItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState("");

  const [recommendItems, setRecommendItems] = useState<PartnerItem[]>([]);
  const [recommendLoading, setRecommendLoading] = useState(true);
  const [recommendError, setRecommendError] = useState("");
  const [interestLabels, setInterestLabels] = useState<string[]>([]);

  const [tab, setTab] = useState<"ALL" | "FAVORITES">("ALL");
  const [search, setSearch] = useState("");
  const [submittedSearch, setSubmittedSearch] = useState("");

  async function loadBalance() {
    setBalanceLoading(true);
    setBalanceError("");

    try {
      const res = await fetch("/api/me/balance", { cache: "no-store" });
      const data: BalanceResponse = await res.json();

      if (!res.ok || !data?.ok) {
        setBalance(0);
        setBalanceError(
          data?.error ?? data?.message ?? "보유 포인트를 불러오지 못했습니다."
        );
        return;
      }

      setBalance(Number(data.balance ?? 0));
    } catch {
      setBalance(0);
      setBalanceError("보유 포인트를 불러오지 못했습니다.");
    } finally {
      setBalanceLoading(false);
    }
  }

  async function loadRecommendations() {
    setRecommendLoading(true);
    setRecommendError("");

    try {
      const res = await fetch("/api/customer/recommendations?limit=6", {
        cache: "no-store",
      });

      const data: RecommendationResponse = await res.json();

      if (!res.ok || !data?.ok) {
        setRecommendItems([]);
        setInterestLabels([]);
        setRecommendError(
          data?.error ?? data?.message ?? "추천 업체를 불러오지 못했습니다."
        );
        return;
      }

      setRecommendItems(data.items ?? []);
      setInterestLabels(data.interestLabels ?? []);
    } catch {
      setRecommendItems([]);
      setInterestLabels([]);
      setRecommendError("추천 업체를 불러오지 못했습니다.");
    } finally {
      setRecommendLoading(false);
    }
  }

  async function loadPartners(nextTab: "ALL" | "FAVORITES", q: string) {
    setLoading(true);
    setMsg("");

    try {
      const url = new URL(
        nextTab === "FAVORITES"
          ? "/api/customer/favorites/list"
          : "/api/customer/partners",
        window.location.origin
      );

      if (q.trim()) {
        url.searchParams.set("q", q.trim());
      }

      const res = await fetch(url.toString(), {
        method: "GET",
        cache: "no-store",
      });

      const data: PartnersResponse = await res.json();

      if (!res.ok || !data?.ok) {
        setItems([]);
        setMsg(data?.error ?? data?.message ?? "업체 목록을 불러오지 못했습니다.");
        return;
      }

      const nextItems = (data.items ?? []).map((item) => ({
        ...item,
        isFavorite: nextTab === "FAVORITES" ? true : Boolean(item.isFavorite),
      }));

      setItems(nextItems);
    } catch {
      setItems([]);
      setMsg("업체 목록을 불러오지 못했습니다.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadBalance();
    loadRecommendations();
  }, []);

  useEffect(() => {
    loadPartners(tab, submittedSearch);
  }, [tab, submittedSearch]);

  function onSubmitSearch(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSubmittedSearch(search.trim());
  }

  function resetSearch() {
    setSearch("");
    setSubmittedSearch("");
  }

  function handleFavoriteChanged(partnerId: string, next: boolean) {
    setItems((prev) => {
      if (tab === "FAVORITES" && !next) {
        return prev.filter((item) => item.id !== partnerId);
      }

      return prev.map((item) =>
        item.id === partnerId ? { ...item, isFavorite: next } : item
      );
    });

    setRecommendItems((prev) =>
      prev.map((item) =>
        item.id === partnerId ? { ...item, isFavorite: next } : item
      )
    );
  }

  const favoriteCount = useMemo(() => {
    return items.filter((item) => item.isFavorite).length;
  }, [items]);

  const titleText = tab === "FAVORITES" ? "관심업체" : "전체 제휴사";

  const emptyText =
    tab === "FAVORITES"
      ? submittedSearch
        ? "검색 조건에 맞는 관심업체가 없습니다."
        : "저장한 관심업체가 없습니다."
      : submittedSearch
      ? "검색 조건에 맞는 업체가 없습니다."
      : "노출 중인 제휴사가 없습니다.";

  return (
    <CustomerShellClient
      session={session}
      title="고객 페이지"
      description="관심사를 바탕으로 추천 업체를 확인하고 관심업체를 저장해보세요."
    >
      <main style={{ display: "grid", gap: 20 }}>
        <section
          style={{
            border: "1px solid #e5e7eb",
            borderRadius: 20,
            padding: 22,
            background: "#fff",
            boxShadow: "0 4px 16px rgba(15,23,42,0.04)",
            display: "grid",
            gap: 18,
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              gap: 16,
              alignItems: "flex-start",
              flexWrap: "wrap",
            }}
          >
            <div>
              <div
                style={{
                  fontSize: 14,
                  color: "#6b7280",
                  fontWeight: 700,
                  marginBottom: 8,
                }}
              >
                안녕하세요, {session.name || session.username}님
              </div>

              <h1
                style={{
                  margin: 0,
                  fontSize: 30,
                  fontWeight: 900,
                  color: "#111827",
                  letterSpacing: "-0.02em",
                }}
              >
                제휴사 둘러보기
              </h1>

              <div
                style={{
                  marginTop: 10,
                  color: "#4b5563",
                  lineHeight: 1.7,
                }}
              >
                관심사에 맞는 추천 업체를 먼저 확인하고, 원하는 업체를 관심업체로 저장할 수 있습니다.
              </div>
            </div>

            <div
              style={{
                minWidth: 260,
                borderRadius: 18,
                border: "1px solid #e5e7eb",
                background: "#f9fafb",
                padding: 18,
              }}
            >
              <div
                style={{
                  fontSize: 13,
                  color: "#6b7280",
                  fontWeight: 700,
                  marginBottom: 8,
                }}
              >
                내 보유 포인트
              </div>

              <div
                style={{
                  fontSize: 32,
                  fontWeight: 900,
                  color: "#111827",
                  letterSpacing: "-0.02em",
                }}
              >
                {balanceLoading ? "불러오는 중..." : `${formatPoint(balance)}P`}
              </div>

              {balanceError ? (
                <div
                  style={{
                    marginTop: 8,
                    color: "#b91c1c",
                    fontSize: 13,
                    lineHeight: 1.5,
                  }}
                >
                  {balanceError}
                </div>
              ) : (
                <div
                  style={{
                    marginTop: 8,
                    color: "#6b7280",
                    fontSize: 13,
                    lineHeight: 1.5,
                  }}
                >
                  현재 사용 가능한 포인트 기준입니다.
                </div>
              )}
            </div>
          </div>

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              gap: 12,
              alignItems: "center",
              flexWrap: "wrap",
            }}
          >
            <div
              style={{
                display: "flex",
                gap: 8,
                flexWrap: "wrap",
              }}
            >
              {interestLabels.length > 0 ? (
                interestLabels.map((label) => <Tag key={label} text={label} />)
              ) : (
                <Tag text="관심사 미설정" />
              )}
            </div>

            <Link
              href="/customer/onboarding"
              style={{
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center",
                height: 42,
                padding: "0 14px",
                borderRadius: 999,
                border: "1px solid #d1d5db",
                background: "#fff",
                color: "#111827",
                textDecoration: "none",
                fontWeight: 800,
              }}
            >
              관심사 다시 선택
            </Link>
          </div>
        </section>

        <SectionCard
          title="추천 제휴사"
          description="선택한 관심사와 일치하는 업체를 먼저 보여드립니다."
          right={
            !recommendLoading ? (
              <div
                style={{
                  color: "#6b7280",
                  fontWeight: 700,
                }}
              >
                총 {recommendItems.length.toLocaleString()}개
              </div>
            ) : null
          }
        >
          {recommendError ? (
            <div
              style={{
                padding: 14,
                borderRadius: 12,
                background: "#fef2f2",
                border: "1px solid #fecaca",
                color: "#991b1b",
              }}
            >
              {recommendError}
            </div>
          ) : null}

          {recommendLoading ? (
            <EmptyState text="추천 업체를 불러오는 중입니다." />
          ) : recommendItems.length === 0 ? (
            <EmptyState text="선택한 관심사와 일치하는 추천 업체가 없습니다." />
          ) : (
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))",
                gap: 16,
              }}
            >
              {recommendItems.map((item) => (
                <PartnerCard
                  key={item.id}
                  item={item}
                  recommendationMode
                  onFavoriteChanged={handleFavoriteChanged}
                />
              ))}
            </div>
          )}
        </SectionCard>

        <section
          style={{
            border: "1px solid #e5e7eb",
            borderRadius: 20,
            padding: 22,
            background: "#fff",
            boxShadow: "0 4px 16px rgba(15,23,42,0.04)",
            display: "grid",
            gap: 18,
          }}
        >
          <form
            onSubmit={onSubmitSearch}
            style={{
              display: "flex",
              gap: 10,
              flexWrap: "wrap",
            }}
          >
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="업체명, 소개, 혜택, 주소로 검색"
              style={{
                flex: "1 1 320px",
                height: 48,
                borderRadius: 12,
                border: "1px solid #d1d5db",
                padding: "0 14px",
                background: "#fff",
              }}
            />

            <button
              type="submit"
              style={{
                height: 48,
                borderRadius: 12,
                border: "1px solid #111827",
                background: "#111827",
                color: "#fff",
                padding: "0 16px",
                fontWeight: 800,
                cursor: "pointer",
              }}
            >
              검색
            </button>

            <button
              type="button"
              onClick={resetSearch}
              style={{
                height: 48,
                borderRadius: 12,
                border: "1px solid #d1d5db",
                background: "#fff",
                color: "#111827",
                padding: "0 16px",
                fontWeight: 800,
                cursor: "pointer",
              }}
            >
              초기화
            </button>
          </form>

          <div
            style={{
              display: "flex",
              gap: 10,
              flexWrap: "wrap",
            }}
          >
            <button
              type="button"
              onClick={() => setTab("ALL")}
              style={{
                height: 42,
                borderRadius: 999,
                border: tab === "ALL" ? "1px solid #111827" : "1px solid #d1d5db",
                background: tab === "ALL" ? "#111827" : "#fff",
                color: tab === "ALL" ? "#fff" : "#374151",
                padding: "0 16px",
                fontWeight: 800,
                cursor: "pointer",
              }}
            >
              전체보기
            </button>

            <button
              type="button"
              onClick={() => setTab("FAVORITES")}
              style={{
                height: 42,
                borderRadius: 999,
                border:
                  tab === "FAVORITES" ? "1px solid #111827" : "1px solid #d1d5db",
                background: tab === "FAVORITES" ? "#111827" : "#fff",
                color: tab === "FAVORITES" ? "#fff" : "#374151",
                padding: "0 16px",
                fontWeight: 800,
                cursor: "pointer",
              }}
            >
              관심업체
              {tab === "FAVORITES" ? "" : favoriteCount ? ` (${favoriteCount})` : ""}
            </button>
          </div>
        </section>

        <SectionCard
          title={titleText}
          description={
            submittedSearch
              ? `검색어: "${submittedSearch}"`
              : "제휴사 상세 정보를 확인해보세요."
          }
          right={
            !loading ? (
              <div
                style={{
                  color: "#6b7280",
                  fontWeight: 700,
                }}
              >
                총 {items.length.toLocaleString()}개
              </div>
            ) : null
          }
        >
          {msg ? (
            <div
              style={{
                padding: 14,
                borderRadius: 12,
                background: "#fef2f2",
                border: "1px solid #fecaca",
                color: "#991b1b",
              }}
            >
              {msg}
            </div>
          ) : null}

          {loading ? (
            <EmptyState text="업체 목록을 불러오는 중입니다." />
          ) : items.length === 0 ? (
            <EmptyState text={emptyText} />
          ) : (
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))",
                gap: 16,
              }}
            >
              {items.map((item) => (
                <PartnerCard
                  key={item.id}
                  item={item}
                  onFavoriteChanged={handleFavoriteChanged}
                />
              ))}
            </div>
          )}
        </SectionCard>
      </main>
    </CustomerShellClient>
  );
}