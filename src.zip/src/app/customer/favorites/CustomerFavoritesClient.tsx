"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import CustomerShellClient from "../CustomerShellClient";
import FavoritePartnerButton from "../FavoritePartnerButton";

type SessionInfo = {
  uid: string;
  username: string;
  name: string;
  role: string;
};

type FavoritePartnerItem = {
  id: string;
  username: string;
  name: string;
  category: string;
  categories?: string[];
  categoryLabels?: string[];
  intro: string;
  benefitText: string;
  kakaoChannelUrl?: string;
  applyUrl?: string;
  address: string;
  phone: string;
  coverImageUrl: string;
  isFavorite?: boolean;
};

type FavoritesResponse = {
  ok: boolean;
  items?: FavoritePartnerItem[];
  message?: string;
  error?: string;
};

type Props = {
  session: SessionInfo;
};

function EmptyState({ text }: { text: string }) {
  return (
    <div
      style={{
        border: "1px dashed #d1d5db",
        borderRadius: 16,
        padding: 28,
        background: "#fafafa",
        color: "#6b7280",
        textAlign: "center",
        fontWeight: 700,
        lineHeight: 1.8,
      }}
    >
      {text}
    </div>
  );
}

function Tag({ text }: { text: string }) {
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        height: 30,
        padding: "0 12px",
        borderRadius: 999,
        background: "#f3f4f6",
        color: "#374151",
        fontSize: 13,
        fontWeight: 800,
        border: "1px solid #e5e7eb",
      }}
    >
      {text}
    </span>
  );
}

function SectionCard({
  title,
  description,
  right,
  children,
}: {
  title: string;
  description?: string;
  right?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <section
      style={{
        border: "1px solid #e5e7eb",
        borderRadius: 20,
        padding: 20,
        background: "#fff",
        boxShadow: "0 4px 16px rgba(15,23,42,0.04)",
        display: "grid",
        gap: 18,
      }}
    >
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          gap: 12,
          alignItems: "center",
          flexWrap: "wrap",
        }}
      >
        <div>
          <div
            style={{
              fontSize: 24,
              fontWeight: 900,
              color: "#111827",
            }}
          >
            {title}
          </div>

          {description ? (
            <div style={{ marginTop: 6, color: "#6b7280", lineHeight: 1.6 }}>
              {description}
            </div>
          ) : null}
        </div>

        {right}
      </div>

      {children}
    </section>
  );
}

function PartnerCard({
  item,
  onFavoriteChanged,
}: {
  item: FavoritePartnerItem;
  onFavoriteChanged?: (partnerId: string, next: boolean) => void;
}) {
  const imageUrl = item.coverImageUrl?.trim();

  return (
    <article
      style={{
        border: "1px solid #e5e7eb",
        borderRadius: 18,
        overflow: "hidden",
        background: "#fff",
        boxShadow: "0 4px 16px rgba(15,23,42,0.04)",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <div
        style={{
          width: "100%",
          aspectRatio: "16 / 10",
          background: "#f3f4f6",
          borderBottom: "1px solid #eef2f7",
          overflow: "hidden",
        }}
      >
        {imageUrl ? (
          <img
            src={imageUrl}
            alt={item.name}
            style={{
              width: "100%",
              height: "100%",
              objectFit: "cover",
              display: "block",
            }}
          />
        ) : (
          <div
            style={{
              width: "100%",
              height: "100%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "#9ca3af",
              fontWeight: 700,
              padding: 16,
              textAlign: "center",
            }}
          >
            대표 이미지가 등록되지 않았습니다.
          </div>
        )}
      </div>

      <div
        style={{
          padding: 18,
          display: "flex",
          flexDirection: "column",
          gap: 14,
          height: "100%",
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            gap: 12,
            alignItems: "flex-start",
            flexWrap: "wrap",
          }}
        >
          <div style={{ minWidth: 0, flex: 1 }}>
            <div
              style={{
                display: "flex",
                gap: 8,
                flexWrap: "wrap",
                marginBottom: 8,
              }}
            >
              {item.categoryLabels && item.categoryLabels.length > 0 ? (
                item.categoryLabels.map((label) => (
                  <Tag key={`${item.id}-${label}`} text={label} />
                ))
              ) : (
                <Tag text={item.category || "기타"} />
              )}
            </div>

            <div
              style={{
                fontSize: 24,
                fontWeight: 900,
                color: "#111827",
                lineHeight: 1.2,
                wordBreak: "keep-all",
              }}
            >
              {item.name}
            </div>
          </div>

          <FavoritePartnerButton
            partnerId={item.id}
            initialFavorite={Boolean(item.isFavorite)}
            onChanged={(next) => onFavoriteChanged?.(item.id, next)}
          />
        </div>

        <div
          style={{
            color: "#374151",
            lineHeight: 1.8,
            minHeight: 72,
            whiteSpace: "pre-wrap",
            wordBreak: "keep-all",
          }}
        >
          {item.intro || "등록된 소개글이 없습니다."}
        </div>

        <div
          style={{
            padding: 14,
            borderRadius: 14,
            background: "#f9fafb",
            border: "1px solid #e5e7eb",
          }}
        >
          <div
            style={{
              fontSize: 13,
              color: "#6b7280",
              fontWeight: 800,
              marginBottom: 6,
            }}
          >
            제공 혜택
          </div>

          <div
            style={{
              color: "#111827",
              lineHeight: 1.7,
              fontWeight: 700,
              whiteSpace: "pre-wrap",
              wordBreak: "keep-all",
              minHeight: 44,
            }}
          >
            {item.benefitText || "등록된 혜택이 없습니다."}
          </div>
        </div>

        <div
          style={{
            display: "grid",
            gap: 8,
            color: "#4b5563",
            fontSize: 14,
          }}
        >
          <div>
            <span style={{ color: "#6b7280", fontWeight: 800 }}>주소</span>
            <span style={{ marginLeft: 8 }}>{item.address || "등록되지 않음"}</span>
          </div>

          <div>
            <span style={{ color: "#6b7280", fontWeight: 800 }}>연락처</span>
            <span style={{ marginLeft: 8 }}>{item.phone || "등록되지 않음"}</span>
          </div>
        </div>

        <div
          style={{
            display: "flex",
            gap: 10,
            flexWrap: "wrap",
            marginTop: "auto",
          }}
        >
          <Link
            href={`/customer/partner/${item.id}`}
            style={{
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
              flex: "1 1 160px",
              minHeight: 44,
              textDecoration: "none",
              padding: "0 16px",
              borderRadius: 12,
              border: "1px solid #111827",
              background: "#111827",
              color: "#fff",
              fontWeight: 800,
            }}
          >
            상세 보기
          </Link>
        </div>
      </div>
    </article>
  );
}

export default function CustomerFavoritesClient({ session }: Props) {
  const [items, setItems] = useState<FavoritePartnerItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState("");

  async function loadFavorites() {
    setLoading(true);
    setMsg("");

    try {
      const res = await fetch("/api/customer/favorites/list", {
        cache: "no-store",
      });

      const data: FavoritesResponse = await res.json();

      if (!res.ok || !data?.ok) {
        setItems([]);
        setMsg(data?.error ?? data?.message ?? "관심업체를 불러오지 못했습니다.");
        return;
      }

      setItems(
        (data.items ?? []).map((item) => ({
          ...item,
          isFavorite: true,
        }))
      );
    } catch {
      setItems([]);
      setMsg("관심업체를 불러오지 못했습니다.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadFavorites();
  }, []);

  function handleFavoriteChanged(partnerId: string, next: boolean) {
    if (!next) {
      setItems((prev) => prev.filter((item) => item.id !== partnerId));
      return;
    }

    setItems((prev) =>
      prev.map((item) =>
        item.id === partnerId ? { ...item, isFavorite: next } : item
      )
    );
  }

  return (
    <CustomerShellClient
      session={session}
      title="관심업체"
      description="저장해둔 제휴사를 한곳에서 모아보고 다시 확인할 수 있습니다."
    >
      <main style={{ display: "grid", gap: 20 }}>
        <section
          style={{
            border: "1px solid #e5e7eb",
            borderRadius: 20,
            padding: 22,
            background: "#fff",
            boxShadow: "0 4px 16px rgba(15,23,42,0.04)",
            display: "grid",
            gap: 14,
          }}
        >
          <div>
            <div
              style={{
                fontSize: 14,
                color: "#6b7280",
                fontWeight: 700,
                marginBottom: 8,
              }}
            >
              FAVORITES
            </div>

            <h1
              style={{
                margin: 0,
                fontSize: 30,
                fontWeight: 900,
                color: "#111827",
                letterSpacing: "-0.02em",
              }}
            >
              관심업체 모아보기
            </h1>

            <div
              style={{
                marginTop: 10,
                color: "#4b5563",
                lineHeight: 1.7,
              }}
            >
              저장한 업체를 다시 확인하고 비교해보세요.
            </div>
          </div>

          <div
            style={{
              display: "flex",
              gap: 10,
              flexWrap: "wrap",
            }}
          >
            <Link
              href="/customer"
              style={{
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center",
                height: 42,
                padding: "0 14px",
                borderRadius: 999,
                border: "1px solid #d1d5db",
                background: "#fff",
                color: "#111827",
                textDecoration: "none",
                fontWeight: 800,
              }}
            >
              전체 제휴사 보기
            </Link>
          </div>
        </section>

        <SectionCard
          title="저장한 관심업체"
          description="찜한 업체만 따로 모아 확인할 수 있습니다."
          right={
            !loading ? (
              <div
                style={{
                  color: "#6b7280",
                  fontWeight: 700,
                }}
              >
                총 {items.length.toLocaleString()}개
              </div>
            ) : null
          }
        >
          {msg ? (
            <div
              style={{
                padding: 14,
                borderRadius: 12,
                background: "#fef2f2",
                border: "1px solid #fecaca",
                color: "#991b1b",
              }}
            >
              {msg}
            </div>
          ) : null}

          {loading ? (
            <EmptyState text="관심업체를 불러오는 중입니다." />
          ) : items.length === 0 ? (
            <EmptyState text="저장한 관심업체가 없습니다." />
          ) : (
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))",
                gap: 16,
              }}
            >
              {items.map((item) => (
                <PartnerCard
                  key={item.id}
                  item={item}
                  onFavoriteChanged={handleFavoriteChanged}
                />
              ))}
            </div>
          )}
        </SectionCard>
      </main>
    </CustomerShellClient>
  );
}