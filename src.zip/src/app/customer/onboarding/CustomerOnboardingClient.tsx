"use client";

import { useMemo, useState } from "react";

type SessionInfo = {
  uid: string;
  username: string;
  name: string;
  role: string;
};

type InterestOption = {
  value: string;
  label: string;
};

type Props = {
  session: SessionInfo;
  initialInterests: string[];
  interestOptions: InterestOption[];
};

export default function CustomerOnboardingClient({
  session,
  initialInterests,
  interestOptions,
}: Props) {
  const [selected, setSelected] = useState<string[]>(initialInterests);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");
  const [error, setError] = useState("");

  const displayName = useMemo(() => {
    return session.name?.trim() || session.username || "고객";
  }, [session.name, session.username]);

  function toggleInterest(value: string) {
    setSelected((prev) => {
      if (prev.includes(value)) {
        return prev.filter((item) => item !== value);
      }
      return [...prev, value];
    });
  }

  async function submit() {
    if (selected.length === 0) {
      setError("관심사를 1개 이상 선택해 주세요.");
      setMsg("");
      return;
    }

    setLoading(true);
    setMsg("");
    setError("");

    try {
      const res = await fetch("/api/customer/onboarding", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          interests: selected,
        }),
      });

      const data = await res.json();

      if (!res.ok || !data?.ok) {
        setError(data?.error ?? "관심사 저장에 실패했습니다.");
        return;
      }

      setMsg("관심사가 저장되었습니다.");
      window.location.href = "/customer";
    } catch {
      setError("관심사 저장 중 오류가 발생했습니다.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#f8fafc",
        padding: "32px 16px",
      }}
    >
      <div
        style={{
          maxWidth: 980,
          margin: "0 auto",
          display: "grid",
          gap: 20,
        }}
      >
        <section
          style={{
            border: "1px solid #e5e7eb",
            borderRadius: 24,
            background: "#fff",
            boxShadow: "0 8px 24px rgba(15,23,42,0.05)",
            padding: 28,
            display: "grid",
            gap: 16,
          }}
        >
          <div>
            <div
              style={{
                fontSize: 13,
                fontWeight: 800,
                color: "#6b7280",
                marginBottom: 10,
              }}
            >
              CUSTOMER ONBOARDING
            </div>

            <h1
              style={{
                margin: 0,
                fontSize: 32,
                fontWeight: 900,
                color: "#111827",
                letterSpacing: "-0.02em",
              }}
            >
              관심 있는 웨딩 준비 항목을 선택해 주세요
            </h1>

            <div
              style={{
                marginTop: 10,
                color: "#4b5563",
                lineHeight: 1.7,
                wordBreak: "keep-all",
              }}
            >
              {displayName}님이 선택한 관심사를 바탕으로
              <br />
              고객 페이지에서 추천 제휴사를 먼저 보여드립니다.
            </div>
          </div>

          <div
            style={{
              padding: 18,
              borderRadius: 18,
              border: "1px solid #e5e7eb",
              background: "#f9fafb",
              display: "grid",
              gap: 8,
            }}
          >
            <div
              style={{
                fontSize: 14,
                fontWeight: 800,
                color: "#374151",
              }}
            >
              선택한 관심사
            </div>

            <div
              style={{
                color: selected.length > 0 ? "#111827" : "#6b7280",
                fontWeight: 700,
                lineHeight: 1.7,
              }}
            >
              {selected.length > 0
                ? selected
                    .map(
                      (value) =>
                        interestOptions.find((item) => item.value === value)?.label ?? value
                    )
                    .join(", ")
                : "아직 선택한 관심사가 없습니다."}
            </div>
          </div>
        </section>

        <section
          style={{
            border: "1px solid #e5e7eb",
            borderRadius: 24,
            background: "#fff",
            boxShadow: "0 8px 24px rgba(15,23,42,0.05)",
            padding: 28,
            display: "grid",
            gap: 18,
          }}
        >
          <div
            style={{
              fontSize: 22,
              fontWeight: 900,
              color: "#111827",
            }}
          >
            관심사 선택
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
              gap: 14,
            }}
          >
            {interestOptions.map((item) => {
              const active = selected.includes(item.value);

              return (
                <button
                  key={item.value}
                  type="button"
                  onClick={() => toggleInterest(item.value)}
                  style={{
                    minHeight: 88,
                    borderRadius: 18,
                    border: active ? "2px solid #111827" : "1px solid #d1d5db",
                    background: active ? "#111827" : "#fff",
                    color: active ? "#fff" : "#111827",
                    fontWeight: 900,
                    fontSize: 18,
                    cursor: "pointer",
                    transition: "all 0.15s ease",
                    boxShadow: active
                      ? "0 10px 22px rgba(17,24,39,0.16)"
                      : "0 4px 12px rgba(15,23,42,0.04)",
                  }}
                >
                  {item.label}
                </button>
              );
            })}
          </div>

          {error ? (
            <div
              style={{
                padding: 14,
                borderRadius: 12,
                background: "#fef2f2",
                border: "1px solid #fecaca",
                color: "#991b1b",
                fontWeight: 700,
              }}
            >
              {error}
            </div>
          ) : null}

          {msg ? (
            <div
              style={{
                padding: 14,
                borderRadius: 12,
                background: "#ecfdf5",
                border: "1px solid #a7f3d0",
                color: "#065f46",
                fontWeight: 700,
              }}
            >
              {msg}
            </div>
          ) : null}

          <div
            style={{
              display: "flex",
              justifyContent: "flex-end",
              gap: 10,
              flexWrap: "wrap",
            }}
          >
            <button
              type="button"
              onClick={submit}
              disabled={loading}
              style={{
                height: 50,
                padding: "0 22px",
                borderRadius: 14,
                border: "1px solid #111827",
                background: "#111827",
                color: "#fff",
                fontWeight: 900,
                cursor: loading ? "default" : "pointer",
                opacity: loading ? 0.6 : 1,
              }}
            >
              {loading ? "저장 중..." : "선택 완료"}
            </button>
          </div>
        </section>
      </div>
    </div>
  );
}