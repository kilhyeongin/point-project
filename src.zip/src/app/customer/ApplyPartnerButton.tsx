"use client";

import { useState } from "react";

type Props = {
  partnerId: string;
  initialApplied: boolean;
  externalApplyUrl?: string;
};

export default function ApplyPartnerButton({
  partnerId,
  initialApplied,
  externalApplyUrl,
}: Props) {
  const [applied, setApplied] = useState(Boolean(initialApplied));
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  async function submitApply() {
    if (loading || applied) return;

    setLoading(true);
    setMessage("");

    try {
      const res = await fetch(`/api/customer/applications/${partnerId}`, {
        method: "POST",
      });

      const data = await res.json();

      if (!res.ok || !data?.ok) {
        setMessage(data?.message ?? data?.error ?? "신청 처리에 실패했습니다.");
        return;
      }

      setApplied(true);
      setMessage("신청이 완료되었습니다. 이제 해당 제휴사에 내 상세정보가 공개됩니다.");
    } catch {
      setMessage("네트워크 오류로 신청에 실패했습니다.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ display: "grid", gap: 10 }}>
      <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
        <button
          type="button"
          onClick={submitApply}
          disabled={loading || applied}
          style={{
            minHeight: 46,
            padding: "0 16px",
            borderRadius: 12,
            border: "1px solid #111827",
            background: applied ? "#d1fae5" : "#111827",
            color: applied ? "#065f46" : "#fff",
            fontWeight: 800,
            cursor: loading || applied ? "not-allowed" : "pointer",
          }}
        >
          {loading ? "신청 중..." : applied ? "신청 완료" : "제휴사에 신청하기"}
        </button>

        {externalApplyUrl ? (
          <a
            href={externalApplyUrl}
            target="_blank"
            rel="noreferrer"
            style={{
              display: "inline-flex",
              alignItems: "center",
              minHeight: 46,
              padding: "0 16px",
              borderRadius: 12,
              border: "1px solid #d1d5db",
              textDecoration: "none",
              color: "#111827",
              fontWeight: 800,
              background: "#fff",
            }}
          >
            외부 신청 링크
          </a>
        ) : null}
      </div>

      <div style={{ color: "#6b7280", lineHeight: 1.6, fontSize: 14 }}>
        신청 전에는 제휴사에 최소 정보만 보이고, 신청 후에만 연락처/주소 등 상세 정보가 공개됩니다.
      </div>

      {message ? (
        <div style={{ color: applied ? "#065f46" : "#b91c1c", lineHeight: 1.6 }}>
          {message}
        </div>
      ) : null}
    </div>
  );
}
