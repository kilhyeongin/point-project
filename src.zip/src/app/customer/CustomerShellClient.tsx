// src/app/customer/CustomerShellClient.tsx
"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ReactNode } from "react";

type SessionInfo = {
  uid: string;
  username: string;
  name: string;
  role: string;
};

type Props = {
  session: SessionInfo;
  title: string;
  description?: string;
  children: ReactNode;
};

function NavLink({
  href,
  label,
  active,
}: {
  href: string;
  label: string;
  active: boolean;
}) {
  return (
    <Link
      href={href}
      style={{
        textDecoration: "none",
        height: 42,
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "0 14px",
        borderRadius: 999,
        border: active ? "1px solid #111827" : "1px solid #d1d5db",
        background: active ? "#111827" : "#fff",
        color: active ? "#fff" : "#111827",
        fontWeight: 800,
        transition: "all 0.15s ease",
      }}
    >
      {label}
    </Link>
  );
}

export default function CustomerShellClient({
  session,
  title,
  description,
  children,
}: Props) {
  const pathname = usePathname();
  const displayName = session.name?.trim() || session.username || "고객";

  const isHome = pathname === "/customer";
  const isFavorites = pathname === "/customer/favorites";

  return (
    <div
      style={{
        maxWidth: 1280,
        margin: "0 auto",
        padding: "24px 16px 40px",
        display: "grid",
        gap: 20,
      }}
    >
      <header
        style={{
          border: "1px solid #e5e7eb",
          borderRadius: 20,
          background: "#ffffff",
          boxShadow: "0 4px 16px rgba(15,23,42,0.04)",
          padding: 20,
          display: "grid",
          gap: 16,
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            gap: 16,
            alignItems: "flex-start",
            flexWrap: "wrap",
          }}
        >
          <div>
            <div
              style={{
                fontSize: 13,
                fontWeight: 800,
                color: "#6b7280",
                marginBottom: 8,
              }}
            >
              CUSTOMER
            </div>

            <h1
              style={{
                margin: 0,
                fontSize: 28,
                fontWeight: 900,
                color: "#111827",
                letterSpacing: "-0.02em",
              }}
            >
              {title}
            </h1>

            {description ? (
              <div
                style={{
                  marginTop: 10,
                  color: "#4b5563",
                  lineHeight: 1.7,
                }}
              >
                {description}
              </div>
            ) : null}
          </div>

          <div
            style={{
              minWidth: 220,
              border: "1px solid #e5e7eb",
              borderRadius: 16,
              background: "#f9fafb",
              padding: 16,
            }}
          >
            <div
              style={{
                fontSize: 13,
                color: "#6b7280",
                fontWeight: 700,
                marginBottom: 8,
              }}
            >
              로그인 정보
            </div>

            <div
              style={{
                fontSize: 18,
                fontWeight: 900,
                color: "#111827",
              }}
            >
              {displayName}
            </div>

            <div
              style={{
                marginTop: 6,
                color: "#6b7280",
                fontSize: 14,
                lineHeight: 1.6,
              }}
            >
              아이디: {session.username}
            </div>
          </div>
        </div>

        <nav
          style={{
            display: "flex",
            flexWrap: "wrap",
            gap: 10,
          }}
        >
          <NavLink href="/customer" label="제휴사 둘러보기" active={isHome} />
          <NavLink
            href="/customer/favorites"
            label="관심업체"
            active={isFavorites}
          />
        </nav>
      </header>

      <div>{children}</div>
    </div>
  );
}