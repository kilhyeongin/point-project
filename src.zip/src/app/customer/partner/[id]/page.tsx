import { notFound, redirect } from "next/navigation";
import { connectDB } from "@/lib/db";
import { getSessionFromCookies } from "@/lib/auth";
import { User } from "@/models/User";
import { FavoritePartner } from "@/models/FavoritePartner";
import {
  getCategoryLabels,
  normalizeCategoryCodes,
} from "@/lib/partnerCategories";
import ApplyPartnerButton from "@/app/customer/ApplyPartnerButton";

type PageProps = {
  params: Promise<{ id: string }>;
};

export default async function CustomerPartnerDetailPage({ params }: PageProps) {
  const session = await getSessionFromCookies();

  if (!session) redirect("/login");
  if (session.role !== "CUSTOMER") redirect("/");

  const { id } = await params;

  await connectDB();

  const [doc, relation] = await Promise.all([
    User.findOne(
      {
        _id: id,
        role: "PARTNER",
        status: "ACTIVE",
        "partnerProfile.isPublished": true,
      },
      {
        username: 1,
        name: 1,
        partnerProfile: 1,
      }
    ).lean(),
    FavoritePartner.findOne(
      {
        customerId: session.uid,
        partnerId: id,
      },
      {
        status: 1,
        createdAt: 1,
        appliedAt: 1,
      }
    ).lean(),
  ]);

  if (!doc) notFound();

  const profile = (doc as any).partnerProfile ?? {};
  const categoryCodes = await normalizeCategoryCodes(
    profile.categories,
    profile.category
  );
  const categoryLabels = await getCategoryLabels(categoryCodes);

  const relationStatus = String((relation as any)?.status ?? "NONE");
  const applied = relationStatus === "APPLIED";
  const liked = relationStatus === "LIKED";

  return (
    <main style={{ display: "grid", gap: 20 }}>
      <section
        style={{
          border: "1px solid #e5e7eb",
          borderRadius: 20,
          background: "#fff",
          padding: 24,
        }}
      >
        <div style={{ display: "grid", gap: 10 }}>
          <h1 style={{ margin: 0, fontSize: 28, fontWeight: 900 }}>
            {String((doc as any).name ?? "")}
          </h1>

          <div style={{ color: "#6b7280", fontWeight: 700 }}>
            {categoryLabels.length > 0 ? categoryLabels.join(" · ") : "기타"}
          </div>

          {profile.intro ? (
            <div style={{ color: "#374151", lineHeight: 1.7 }}>
              {String(profile.intro)}
            </div>
          ) : null}
        </div>
      </section>

      <section
        style={{
          border: "1px solid #e5e7eb",
          borderRadius: 20,
          background: "#fff",
          padding: 24,
          display: "grid",
          gap: 16,
        }}
      >
        <h2 style={{ margin: 0, fontSize: 20, fontWeight: 900 }}>신청 및 정보 공개</h2>

        <div
          style={{
            borderRadius: 16,
            padding: 16,
            border: "1px solid #e5e7eb",
            background: applied ? "#ecfdf5" : liked ? "#fffbeb" : "#f9fafb",
            lineHeight: 1.7,
          }}
        >
          <div style={{ fontWeight: 900, marginBottom: 6 }}>
            {applied ? "신청 완료" : liked ? "관심업체 저장 상태" : "아직 신청 전"}
          </div>
          <div style={{ color: "#4b5563" }}>
            {applied
              ? "이 제휴사에는 내 상세정보가 공개됩니다. 제휴사는 이제 이름, 연락처, 주소를 확인할 수 있습니다."
              : "신청 전에는 제휴사에 최소 정보만 공개됩니다. 찜만 해도 잠재고객으로 들어가지만 연락처와 주소는 공개되지 않습니다."}
          </div>
        </div>

        <ApplyPartnerButton
          partnerId={String((doc as any)._id)}
          initialApplied={applied}
          externalApplyUrl={String(profile.applyUrl ?? "").trim()}
        />
      </section>

      <section
        style={{
          border: "1px solid #e5e7eb",
          borderRadius: 20,
          background: "#fff",
          padding: 24,
          display: "grid",
          gap: 12,
        }}
      >
        <h2 style={{ margin: 0, fontSize: 20, fontWeight: 900 }}>업체 정보</h2>

        <div><strong>카테고리:</strong> {categoryLabels.length > 0 ? categoryLabels.join(", ") : "기타"}</div>
        <div><strong>혜택 안내:</strong> {String(profile.benefitText ?? "-")}</div>
        <div><strong>주소:</strong> {String(profile.address ?? "-")}</div>
        <div><strong>전화번호:</strong> {String(profile.phone ?? "-")}</div>

        {profile.kakaoChannelUrl ? (
          <div>
            <strong>카카오채널:</strong>{" "}
            <a href={String(profile.kakaoChannelUrl)} target="_blank" rel="noreferrer">
              바로가기
            </a>
          </div>
        ) : null}
      </section>
    </main>
  );
}
