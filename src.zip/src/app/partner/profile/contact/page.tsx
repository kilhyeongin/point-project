"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

type PartnerCategory =
  | "DRESS"
  | "MAKEUP"
  | "STUDIO"
  | "HANBOK"
  | "JEWELRY"
  | "TRAVEL"
  | "VIDEO"
  | "BOUQUET"
  | "SNAP"
  | "INVITATION"
  | "MC"
  | "BAND"
  | "GIFT"
  | "ETC";

type PartnerProfileResponse = {
  ok: boolean;
  item?: {
    category?: string;
    categories?: PartnerCategory[];
    intro?: string;
    benefitText?: string;
    kakaoChannelUrl?: string;
    applyUrl?: string;
    address?: string;
    phone?: string;
    coverImageUrl?: string;
    isPublished?: boolean;
  };
  error?: string;
  message?: string;
};

type FormState = {
  category: string;
  categories: PartnerCategory[];
  intro: string;
  benefitText: string;
  kakaoChannelUrl: string;
  applyUrl: string;
  address: string;
  phone: string;
  coverImageUrl: string;
  isPublished: boolean;
};

type FieldErrors = {
  applyUrl: string;
  kakaoChannelUrl: string;
};

const EMPTY_FORM: FormState = {
  category: "",
  categories: [],
  intro: "",
  benefitText: "",
  kakaoChannelUrl: "",
  applyUrl: "",
  address: "",
  phone: "",
  coverImageUrl: "",
  isPublished: false,
};

const EMPTY_FIELD_ERRORS: FieldErrors = {
  applyUrl: "",
  kakaoChannelUrl: "",
};

function normalizeInput(value: string) {
  return value.trim();
}

function isValidHttpUrl(value: string) {
  if (!value.trim()) return true;

  try {
    const parsed = new URL(value.trim());
    return parsed.protocol === "http:" || parsed.protocol === "https:";
  } catch {
    return false;
  }
}

function validateForm(form: FormState): FieldErrors {
  const next: FieldErrors = {
    applyUrl: "",
    kakaoChannelUrl: "",
  };

  if (form.applyUrl.trim() && !isValidHttpUrl(form.applyUrl)) {
    next.applyUrl =
      "신청 링크는 http:// 또는 https:// 로 시작하는 올바른 주소만 입력할 수 있습니다.";
  }

  if (form.kakaoChannelUrl.trim() && !isValidHttpUrl(form.kakaoChannelUrl)) {
    next.kakaoChannelUrl =
      "카카오채널 링크는 http:// 또는 https:// 로 시작하는 올바른 주소만 입력할 수 있습니다.";
  }

  return next;
}

function hasAnyFieldError(errors: FieldErrors) {
  return Boolean(errors.applyUrl || errors.kakaoChannelUrl);
}

export default function PartnerProfileContactPage() {
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>(EMPTY_FIELD_ERRORS);

  async function load() {
    setLoading(true);
    setMsg("");
    setFieldErrors(EMPTY_FIELD_ERRORS);

    try {
      const res = await fetch("/api/partner/profile", { cache: "no-store" });
      const data: PartnerProfileResponse = await res.json();

      if (!res.ok || !data?.ok || !data.item) {
        setMsg(data?.error ?? data?.message ?? "연락처 정보를 불러오지 못했습니다.");
        setForm(EMPTY_FORM);
        setLoading(false);
        return;
      }

      setForm({
        category: data.item.category ?? "",
        categories: Array.isArray(data.item.categories) ? data.item.categories : [],
        intro: data.item.intro ?? "",
        benefitText: data.item.benefitText ?? "",
        kakaoChannelUrl: data.item.kakaoChannelUrl ?? "",
        applyUrl: data.item.applyUrl ?? "",
        address: data.item.address ?? "",
        phone: data.item.phone ?? "",
        coverImageUrl: data.item.coverImageUrl ?? "",
        isPublished: Boolean(data.item.isPublished),
      });
    } catch {
      setMsg("네트워크 오류");
      setForm(EMPTY_FORM);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  function updateField<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((prev) => ({
      ...prev,
      [key]: value,
    }));

    if (key === "applyUrl" || key === "kakaoChannelUrl") {
      setFieldErrors((prev) => ({
        ...prev,
        [key]: "",
      }));
    }
  }

  async function save() {
    setSaving(true);
    setMsg("");

    const normalizedForm: FormState = {
      ...form,
      category: normalizeInput(form.category),
      categories: form.categories,
      intro: normalizeInput(form.intro),
      benefitText: normalizeInput(form.benefitText),
      kakaoChannelUrl: normalizeInput(form.kakaoChannelUrl),
      applyUrl: normalizeInput(form.applyUrl),
      address: normalizeInput(form.address),
      phone: normalizeInput(form.phone),
      coverImageUrl: normalizeInput(form.coverImageUrl),
      isPublished: Boolean(form.isPublished),
    };

    const nextErrors = validateForm(normalizedForm);
    setFieldErrors(nextErrors);

    if (hasAnyFieldError(nextErrors)) {
      setMsg("입력값을 다시 확인해주세요.");
      setSaving(false);
      return;
    }

    try {
      const res = await fetch("/api/partner/profile", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          category: normalizedForm.category,
          categories: normalizedForm.categories,
          intro: normalizedForm.intro,
          benefitText: normalizedForm.benefitText,
          kakaoChannelUrl: normalizedForm.kakaoChannelUrl,
          applyUrl: normalizedForm.applyUrl,
          address: normalizedForm.address,
          phone: normalizedForm.phone,
          coverImageUrl: normalizedForm.coverImageUrl,
          isPublished: normalizedForm.isPublished,
        }),
      });

      const data: PartnerProfileResponse = await res.json();

      if (!res.ok || !data?.ok || !data.item) {
        setMsg(data?.error ?? data?.message ?? "저장에 실패했습니다.");
        setSaving(false);
        return;
      }

      setForm({
        category: data.item.category ?? "",
        categories: Array.isArray(data.item.categories) ? data.item.categories : [],
        intro: data.item.intro ?? "",
        benefitText: data.item.benefitText ?? "",
        kakaoChannelUrl: data.item.kakaoChannelUrl ?? "",
        applyUrl: data.item.applyUrl ?? "",
        address: data.item.address ?? "",
        phone: data.item.phone ?? "",
        coverImageUrl: data.item.coverImageUrl ?? "",
        isPublished: Boolean(data.item.isPublished),
      });

      setFieldErrors(EMPTY_FIELD_ERRORS);
      setMsg(data.message ?? "저장되었습니다.");
    } catch {
      setMsg("네트워크 오류");
    } finally {
      setSaving(false);
    }
  }

  const messageIsSuccess =
    msg.includes("저장") && !msg.includes("실패") && !msg.includes("불러오지");

  return (
    <main className="partner-contact-page">
      <section className="partner-contact-page__hero">
        <div>
          <div className="partner-contact-page__eyebrow">내 정보 관리</div>
          <h1 className="partner-contact-page__title">링크 / 연락처 수정</h1>
          <div className="partner-contact-page__desc">
            신청 링크, 카카오채널, 주소, 연락처와 공개 여부를 수정합니다.
          </div>
        </div>

        <div className="partner-contact-page__hero-actions">
          <Link href="/partner/profile" className="partner-contact-page__back">
            돌아가기
          </Link>

          <button
            type="button"
            onClick={save}
            disabled={saving || loading}
            className="partner-contact-page__save"
          >
            {saving ? "저장 중..." : "저장"}
          </button>
        </div>
      </section>

      {msg ? (
        <div
          className={`partner-contact-page__message ${
            messageIsSuccess ? "is-success" : "is-error"
          }`}
        >
          {msg}
        </div>
      ) : null}

      <section className="partner-contact-page__card">
        {loading ? (
          <div className="partner-contact-page__loading">불러오는 중...</div>
        ) : (
          <div className="partner-contact-page__grid">
            <div className="partner-contact-page__col">
              <div>
                <label className="partner-contact-page__label">신청 링크</label>
                <input
                  value={form.applyUrl}
                  onChange={(e) => updateField("applyUrl", e.target.value)}
                  placeholder="https://example.com/apply"
                  className={`partner-contact-page__input ${
                    fieldErrors.applyUrl ? "is-error" : ""
                  }`}
                />
                <div
                  className={`partner-contact-page__help ${
                    fieldErrors.applyUrl ? "is-error" : ""
                  }`}
                >
                  {fieldErrors.applyUrl ||
                    "신청 페이지 주소를 입력하세요. http:// 또는 https:// 형식만 저장됩니다."}
                </div>
              </div>

              <div>
                <label className="partner-contact-page__label">
                  카카오채널 링크
                </label>
                <input
                  value={form.kakaoChannelUrl}
                  onChange={(e) => updateField("kakaoChannelUrl", e.target.value)}
                  placeholder="https://pf.kakao.com/..."
                  className={`partner-contact-page__input ${
                    fieldErrors.kakaoChannelUrl ? "is-error" : ""
                  }`}
                />
                <div
                  className={`partner-contact-page__help ${
                    fieldErrors.kakaoChannelUrl ? "is-error" : ""
                  }`}
                >
                  {fieldErrors.kakaoChannelUrl ||
                    "카카오채널 연결 주소를 입력하세요. http:// 또는 https:// 형식만 저장됩니다."}
                </div>
              </div>

              <div>
                <label className="partner-contact-page__label">주소</label>
                <input
                  value={form.address}
                  onChange={(e) => updateField("address", e.target.value)}
                  placeholder="업체 주소"
                  className="partner-contact-page__input"
                />
              </div>

              <div>
                <label className="partner-contact-page__label">연락처</label>
                <input
                  value={form.phone}
                  onChange={(e) => updateField("phone", e.target.value)}
                  placeholder="010-1234-5678"
                  className="partner-contact-page__input"
                />
              </div>
            </div>

            <div className="partner-contact-page__col">
              <label className="partner-contact-page__toggle">
                <input
                  type="checkbox"
                  checked={form.isPublished}
                  onChange={(e) => updateField("isPublished", e.target.checked)}
                />
                <span>고객 페이지에 공개</span>
              </label>

              <div className="partner-contact-page__summary">
                <div className="partner-contact-page__summary-title">현재 상태 요약</div>

                <div className="partner-contact-page__summary-list">
                  <div>
                    <strong>노출 상태</strong>
                    <div>{form.isPublished ? "공개 중" : "비공개"}</div>
                  </div>

                  <div>
                    <strong>신청 링크</strong>
                    <div>{form.applyUrl || "등록되지 않음"}</div>
                  </div>

                  <div>
                    <strong>카카오채널</strong>
                    <div>{form.kakaoChannelUrl || "등록되지 않음"}</div>
                  </div>

                  <div>
                    <strong>주소</strong>
                    <div>{form.address || "등록되지 않음"}</div>
                  </div>

                  <div>
                    <strong>연락처</strong>
                    <div>{form.phone || "등록되지 않음"}</div>
                  </div>
                </div>
              </div>

              <div className="partner-contact-page__notice">
                고객이 업체를 확인한 뒤 바로 문의하거나 신청할 수 있도록 실제 사용하는 링크와 연락처를 정확히 입력해 주세요.
              </div>
            </div>
          </div>
        )}
      </section>

      <style jsx>{`
        .partner-contact-page {
          display: grid;
          gap: 20px;
          min-width: 0;
        }

        .partner-contact-page__hero,
        .partner-contact-page__card {
          border: 1px solid #e5e7eb;
          border-radius: 18px;
          background: #fff;
          box-shadow: 0 4px 16px rgba(15, 23, 42, 0.04);
        }

        .partner-contact-page__hero {
          padding: 20px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 16px;
          flex-wrap: wrap;
        }

        .partner-contact-page__eyebrow {
          font-size: 14px;
          color: #6b7280;
          margin-bottom: 6px;
        }

        .partner-contact-page__title {
          font-size: 28px;
          font-weight: 900;
          margin: 0;
          color: #111827;
          line-height: 1.2;
          word-break: keep-all;
        }

        .partner-contact-page__desc {
          margin-top: 8px;
          color: #4b5563;
          line-height: 1.6;
          word-break: keep-all;
        }

        .partner-contact-page__hero-actions {
          display: flex;
          gap: 10px;
          flex-wrap: wrap;
        }

        .partner-contact-page__back,
        .partner-contact-page__save {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          min-height: 44px;
          padding: 0 16px;
          border-radius: 12px;
          font-weight: 800;
          text-decoration: none;
          box-sizing: border-box;
        }

        .partner-contact-page__back {
          border: 1px solid #d1d5db;
          background: #fff;
          color: #111827;
        }

        .partner-contact-page__save {
          border: 1px solid #111827;
          background: #111827;
          color: #fff;
          cursor: pointer;
        }

        .partner-contact-page__save:disabled {
          background: #9ca3af;
          border-color: #9ca3af;
          cursor: not-allowed;
        }

        .partner-contact-page__message {
          padding: 12px;
          border-radius: 12px;
          font-weight: 700;
        }

        .partner-contact-page__message.is-success {
          background: #ecfdf5;
          border: 1px solid #a7f3d0;
          color: #065f46;
        }

        .partner-contact-page__message.is-error {
          background: #fef2f2;
          border: 1px solid #fecaca;
          color: #991b1b;
        }

        .partner-contact-page__card {
          padding: 20px;
        }

        .partner-contact-page__loading {
          opacity: 0.7;
        }

        .partner-contact-page__grid {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 20px;
          min-width: 0;
        }

        .partner-contact-page__col {
          display: grid;
          gap: 16px;
          min-width: 0;
        }

        .partner-contact-page__label {
          display: block;
          font-weight: 800;
          color: #111827;
          margin-bottom: 8px;
        }

        .partner-contact-page__input {
          width: 100%;
          min-width: 0;
          min-height: 48px;
          padding: 0 12px;
          border-radius: 12px;
          border: 1px solid #d1d5db;
          box-sizing: border-box;
          background: #fff;
        }

        .partner-contact-page__input.is-error {
          border-color: #ef4444;
        }

        .partner-contact-page__help {
          margin-top: 8px;
          font-size: 13px;
          color: #6b7280;
          line-height: 1.5;
        }

        .partner-contact-page__help.is-error {
          color: #b91c1c;
        }

        .partner-contact-page__toggle {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 16px;
          border: 1px solid #e5e7eb;
          border-radius: 12px;
          background: #fafafa;
          cursor: pointer;
          font-weight: 800;
          color: #111827;
        }

        .partner-contact-page__summary {
          border: 1px solid #e5e7eb;
          border-radius: 12px;
          padding: 16px;
          background: #f9fafb;
          display: grid;
          gap: 12px;
        }

        .partner-contact-page__summary-title {
          font-weight: 900;
          color: #111827;
        }

        .partner-contact-page__summary-list {
          display: grid;
          gap: 10px;
          color: #374151;
          line-height: 1.7;
          min-width: 0;
        }

        .partner-contact-page__summary-list strong {
          color: #111827;
          display: block;
          margin-bottom: 2px;
        }

        .partner-contact-page__summary-list div {
          overflow-wrap: anywhere;
          word-break: break-word;
        }

        .partner-contact-page__notice {
          padding: 14px;
          border-radius: 12px;
          background: #f9fafb;
          border: 1px solid #e5e7eb;
          color: #6b7280;
          line-height: 1.7;
          font-size: 14px;
          word-break: keep-all;
        }

        @media (max-width: 900px) {
          .partner-contact-page__grid {
            grid-template-columns: 1fr;
          }
        }

        @media (max-width: 640px) {
          .partner-contact-page {
            gap: 16px;
          }

          .partner-contact-page__hero,
          .partner-contact-page__card {
            padding: 16px;
          }

          .partner-contact-page__title {
            font-size: 24px;
          }

          .partner-contact-page__hero-actions {
            width: 100%;
            display: grid;
            grid-template-columns: 1fr;
          }

          .partner-contact-page__back,
          .partner-contact-page__save {
            width: 100%;
          }
        }
      `}</style>
    </main>
  );
}