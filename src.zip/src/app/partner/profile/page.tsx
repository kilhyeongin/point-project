import Link from "next/link";
import { redirect } from "next/navigation";
import { connectDB } from "@/lib/db";
import { getSessionFromCookies } from "@/lib/auth";
import { User } from "@/models/User";
import {
  getCategoryLabels,
  normalizeCategoryCodes,
} from "@/lib/partnerCategories";

export default async function PartnerProfilePage() {
  const session = await getSessionFromCookies();

  if (!session) {
    redirect("/login");
  }

  if (session.role !== "PARTNER") {
    redirect("/");
  }

  await connectDB();

  const me = await User.findById(
    session.uid,
    {
      username: 1,
      name: 1,
      partnerProfile: 1,
      status: 1,
    }
  ).lean();

  if (!me) {
    redirect("/login");
  }

  const profile = (me as any).partnerProfile ?? {};

  const categoryCodes = await normalizeCategoryCodes(
    profile.categories,
    profile.category
  );

  const categoryLabels = await getCategoryLabels(categoryCodes);

  return (
    <main style={{ display: "grid", gap: 20 }}>
      <section
        style={{
          border: "1px solid #e5e7eb",
          borderRadius: 20,
          background: "#fff",
          padding: 24,
          display: "grid",
          gap: 10,
        }}
      >
        <div style={{ fontSize: 12, fontWeight: 800, color: "#6b7280" }}>
          내 정보 관리
        </div>

        <h1 style={{ margin: 0, fontSize: 28, fontWeight: 900 }}>
          업체 프로필
        </h1>

        <div style={{ color: "#4b5563", lineHeight: 1.6 }}>
          고객에게 노출되는 업체 기본 정보를 관리할 수 있습니다.
        </div>
      </section>

      <section
        style={{
          border: "1px solid #e5e7eb",
          borderRadius: 20,
          background: "#fff",
          padding: 24,
          display: "grid",
          gap: 18,
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            gap: 12,
            flexWrap: "wrap",
            alignItems: "center",
          }}
        >
          <div>
            <div style={{ fontSize: 24, fontWeight: 900, color: "#111827" }}>
              {String((me as any).name ?? "")}
            </div>
            <div style={{ marginTop: 6, color: "#6b7280", fontWeight: 700 }}>
              @{String((me as any).username ?? "")}
            </div>
          </div>

          <div
            style={{
              display: "inline-flex",
              alignItems: "center",
              height: 38,
              padding: "0 14px",
              borderRadius: 999,
              fontWeight: 800,
              border: "1px solid #d1d5db",
              background: Boolean(profile.isPublished) ? "#ecfdf5" : "#f9fafb",
              color: Boolean(profile.isPublished) ? "#166534" : "#374151",
            }}
          >
            {Boolean(profile.isPublished) ? "공개중" : "비공개"}
          </div>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
            gap: 14,
          }}
        >
          <InfoBox
            label="카테고리"
            value={
              categoryLabels.length > 0 ? categoryLabels.join(", ") : "미설정"
            }
          />
          <InfoBox
            label="전화번호"
            value={String(profile.phone ?? "").trim() || "-"}
          />
          <InfoBox
            label="주소"
            value={String(profile.address ?? "").trim() || "-"}
          />
          <InfoBox
            label="대표 이미지"
            value={String(profile.coverImageUrl ?? "").trim() || "-"}
          />
          <InfoBox
            label="신청 링크"
            value={String(profile.applyUrl ?? "").trim() || "-"}
          />
          <InfoBox
            label="카카오채널 링크"
            value={String(profile.kakaoChannelUrl ?? "").trim() || "-"}
          />
        </div>

        <InfoBox
          label="업체 소개"
          value={String(profile.intro ?? "").trim() || "-"}
          full
        />

        <InfoBox
          label="고객 혜택 안내"
          value={String(profile.benefitText ?? "").trim() || "-"}
          full
        />

        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          <Link href="/partner/profile/edit" style={secondaryButton}>
            기본정보 수정
          </Link>
          <Link href="/partner/profile/category" style={primaryButton}>
            카테고리 수정
          </Link>
        </div>
      </section>
    </main>
  );
}

function InfoBox({
  label,
  value,
  full = false,
}: {
  label: string;
  value: string;
  full?: boolean;
}) {
  return (
    <div
      style={{
        border: "1px solid #e5e7eb",
        borderRadius: 16,
        padding: 16,
        background: "#fff",
        gridColumn: full ? "1 / -1" : undefined,
      }}
    >
      <div
        style={{
          fontSize: 13,
          fontWeight: 800,
          color: "#6b7280",
          marginBottom: 8,
        }}
      >
        {label}
      </div>
      <div
        style={{
          color: "#111827",
          lineHeight: 1.7,
          whiteSpace: "pre-wrap",
          wordBreak: "break-word",
        }}
      >
        {value}
      </div>
    </div>
  );
}

const primaryButton = {
  height: 44,
  padding: "0 16px",
  borderRadius: 12,
  border: "1px solid #111827",
  background: "#111827",
  color: "#fff",
  fontWeight: 800,
  textDecoration: "none",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
};

const secondaryButton = {
  height: 44,
  padding: "0 16px",
  borderRadius: 12,
  border: "1px solid #d1d5db",
  background: "#fff",
  color: "#111827",
  fontWeight: 800,
  textDecoration: "none",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
};