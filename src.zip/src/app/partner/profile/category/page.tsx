"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";

type CategoryOption = {
  code: string;
  name: string;
  description: string;
  isActive: boolean;
  isVisibleToPartner: boolean;
  isVisibleToCustomer: boolean;
  sortOrder: number;
};

type PartnerProfileResponse = {
  ok: boolean;
  item?: {
    category?: string;
    categories?: string[];
    intro?: string;
    benefitText?: string;
    kakaoChannelUrl?: string;
    applyUrl?: string;
    address?: string;
    phone?: string;
    coverImageUrl?: string;
    isPublished?: boolean;
  };
  error?: string;
  message?: string;
};

export default function PartnerProfileCategoryPage() {
  const [categories, setCategories] = useState<string[]>([]);
  const [options, setOptions] = useState<CategoryOption[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");

  async function load() {
    setLoading(true);
    setMsg("");

    try {
      const [profileRes, optionRes] = await Promise.all([
        fetch("/api/partner/profile", { cache: "no-store" }),
        fetch("/api/partner/category-options", { cache: "no-store" }),
      ]);

      const profileData: PartnerProfileResponse = await profileRes.json();
      const optionData = await optionRes.json();

      if (!profileRes.ok || !profileData?.ok) {
        setMsg(profileData?.error ?? profileData?.message ?? "카테고리 정보를 불러오지 못했습니다.");
        setCategories([]);
        setOptions([]);
        return;
      }

      if (!optionRes.ok || !optionData?.ok) {
        setMsg(optionData?.error ?? "카테고리 옵션을 불러오지 못했습니다.");
        setCategories([]);
        setOptions([]);
        return;
      }

      setCategories(Array.isArray(profileData.item?.categories) ? profileData.item!.categories! : []);
      setOptions(Array.isArray(optionData.items) ? optionData.items : []);
    } catch {
      setMsg("네트워크 오류");
      setCategories([]);
      setOptions([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  function toggleCategory(value: string) {
    setCategories((prev) => {
      if (prev.includes(value)) {
        return prev.filter((item) => item !== value);
      }
      return [...prev, value];
    });
  }

  async function save() {
    setSaving(true);
    setMsg("");

    try {
      const getRes = await fetch("/api/partner/profile", { cache: "no-store" });
      const getData: PartnerProfileResponse = await getRes.json();

      if (!getRes.ok || !getData?.ok || !getData.item) {
        setMsg(getData?.error ?? getData?.message ?? "기존 업체 정보를 불러오지 못했습니다.");
        setSaving(false);
        return;
      }

      const current = getData.item;

      const putRes = await fetch("/api/partner/profile", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          category: categories[0] ?? "",
          categories,
          intro: current.intro ?? "",
          benefitText: current.benefitText ?? "",
          kakaoChannelUrl: current.kakaoChannelUrl ?? "",
          applyUrl: current.applyUrl ?? "",
          address: current.address ?? "",
          phone: current.phone ?? "",
          coverImageUrl: current.coverImageUrl ?? "",
          isPublished: Boolean(current.isPublished),
        }),
      });

      const putData: PartnerProfileResponse = await putRes.json();

      if (!putRes.ok || !putData?.ok) {
        setMsg(putData?.error ?? putData?.message ?? "카테고리 저장에 실패했습니다.");
        setSaving(false);
        return;
      }

      setCategories(Array.isArray(putData.item?.categories) ? putData.item!.categories! : []);
      setMsg(putData.message ?? "카테고리가 저장되었습니다.");
    } catch {
      setMsg("네트워크 오류");
    } finally {
      setSaving(false);
    }
  }

  const messageIsSuccess =
    msg.includes("저장") && !msg.includes("실패") && !msg.includes("불러오지");

  const selectedLabels = useMemo(() => {
    const map = new Map(options.map((item) => [item.code, item.name]));
    return categories.map((value) => map.get(value) ?? value);
  }, [categories, options]);

  return (
    <main className="partner-category-page">
      <section className="partner-category-page__hero">
        <div>
          <div className="partner-category-page__eyebrow">내 정보 관리</div>
          <h1 className="partner-category-page__title">업체 카테고리 수정</h1>
          <div className="partner-category-page__desc">
            고객 관심사 추천에 사용할 카테고리를 선택해 주세요.
          </div>
        </div>

        <div className="partner-category-page__hero-actions">
          <Link href="/partner/profile" className="partner-category-page__back">
            돌아가기
          </Link>

          <button
            type="button"
            onClick={save}
            disabled={saving || loading}
            className="partner-category-page__save"
          >
            {saving ? "저장 중..." : "저장"}
          </button>
        </div>
      </section>

      {msg ? (
        <div
          className={`partner-category-page__message ${
            messageIsSuccess ? "is-success" : "is-error"
          }`}
        >
          {msg}
        </div>
      ) : null}

      <section className="partner-category-page__card">
        {loading ? (
          <div className="partner-category-page__loading">불러오는 중...</div>
        ) : (
          <div className="partner-category-page__body">
            <div className="partner-category-page__chip-wrap">
              {options.map((item) => {
                const checked = categories.includes(item.code);

                return (
                  <label
                    key={item.code}
                    className={`partner-category-page__chip ${
                      checked ? "is-checked" : ""
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={() => toggleCategory(item.code)}
                    />
                    <span>{item.name}</span>
                  </label>
                );
              })}
            </div>

            <div className="partner-category-page__summary">
              <strong>현재 선택</strong>
              <div className="partner-category-page__summary-text">
                {selectedLabels.length > 0
                  ? selectedLabels.join(", ")
                  : "선택된 카테고리가 없습니다."}
              </div>
            </div>

            <div className="partner-category-page__notice">
              여러 개 선택할 수 있습니다. 고객이 관심사로 선택한 항목과 일치할수록 추천에 노출될 가능성이 높아집니다.
            </div>
          </div>
        )}
      </section>

      <style jsx>{`
        .partner-category-page {
          display: grid;
          gap: 20px;
        }

        .partner-category-page__hero {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 16px;
          padding: 24px;
          border-radius: 20px;
          background: linear-gradient(135deg, #ffffff, #f8fafc);
          border: 1px solid #e5e7eb;
        }

        .partner-category-page__eyebrow {
          font-size: 12px;
          font-weight: 800;
          color: #6b7280;
          margin-bottom: 8px;
        }

        .partner-category-page__title {
          margin: 0;
          font-size: 28px;
          font-weight: 900;
          color: #111827;
        }

        .partner-category-page__desc {
          margin-top: 10px;
          color: #4b5563;
          line-height: 1.6;
        }

        .partner-category-page__hero-actions {
          display: flex;
          gap: 10px;
          flex-wrap: wrap;
        }

        .partner-category-page__back,
        .partner-category-page__save {
          height: 44px;
          padding: 0 16px;
          border-radius: 12px;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          font-weight: 800;
          text-decoration: none;
          cursor: pointer;
        }

        .partner-category-page__back {
          border: 1px solid #d1d5db;
          background: #fff;
          color: #111827;
        }

        .partner-category-page__save {
          border: 1px solid #111827;
          background: #111827;
          color: #fff;
        }

        .partner-category-page__message {
          padding: 14px 16px;
          border-radius: 14px;
          font-weight: 700;
          border: 1px solid #e5e7eb;
        }

        .partner-category-page__message.is-success {
          background: #f0fdf4;
          color: #166534;
          border-color: #bbf7d0;
        }

        .partner-category-page__message.is-error {
          background: #fef2f2;
          color: #991b1b;
          border-color: #fecaca;
        }

        .partner-category-page__card {
          border: 1px solid #e5e7eb;
          border-radius: 20px;
          background: #fff;
          padding: 24px;
        }

        .partner-category-page__loading {
          color: #6b7280;
          font-weight: 700;
        }

        .partner-category-page__body {
          display: grid;
          gap: 20px;
        }

        .partner-category-page__chip-wrap {
          display: flex;
          flex-wrap: wrap;
          gap: 12px;
        }

        .partner-category-page__chip {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 12px 14px;
          border-radius: 999px;
          border: 1px solid #d1d5db;
          background: #fff;
          font-weight: 700;
          cursor: pointer;
        }

        .partner-category-page__chip.is-checked {
          border-color: #111827;
          background: #111827;
          color: #fff;
        }

        .partner-category-page__chip input {
          display: none;
        }

        .partner-category-page__summary {
          display: grid;
          gap: 8px;
          padding: 16px;
          border: 1px solid #e5e7eb;
          border-radius: 14px;
          background: #f9fafb;
        }

        .partner-category-page__summary-text {
          color: #374151;
          line-height: 1.6;
        }

        .partner-category-page__notice {
          color: #6b7280;
          line-height: 1.6;
          font-size: 14px;
        }
      `}</style>
    </main>
  );
}