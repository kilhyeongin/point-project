"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";

type PartnerCategory =
  | "DRESS"
  | "MAKEUP"
  | "STUDIO"
  | "HANBOK"
  | "JEWELRY"
  | "TRAVEL"
  | "VIDEO"
  | "BOUQUET"
  | "SNAP"
  | "INVITATION"
  | "MC"
  | "BAND"
  | "GIFT"
  | "ETC";

type PartnerProfileResponse = {
  ok: boolean;
  item?: {
    category?: string;
    categories?: PartnerCategory[];
    intro?: string;
    benefitText?: string;
    kakaoChannelUrl?: string;
    applyUrl?: string;
    address?: string;
    phone?: string;
    coverImageUrl?: string;
    isPublished?: boolean;
  };
  error?: string;
  message?: string;
};

type FormState = {
  category: string;
  categories: PartnerCategory[];
  intro: string;
  benefitText: string;
  kakaoChannelUrl: string;
  applyUrl: string;
  address: string;
  phone: string;
  coverImageUrl: string;
  isPublished: boolean;
};

const EMPTY_FORM: FormState = {
  category: "",
  categories: [],
  intro: "",
  benefitText: "",
  kakaoChannelUrl: "",
  applyUrl: "",
  address: "",
  phone: "",
  coverImageUrl: "",
  isPublished: false,
};

function normalizeInput(value: string) {
  return value.trim();
}

function summarizeLength(current: string, max: number) {
  return `${current.length.toLocaleString()} / ${max.toLocaleString()}자`;
}

export default function PartnerProfileContentPage() {
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");

  async function load() {
    setLoading(true);
    setMsg("");

    try {
      const res = await fetch("/api/partner/profile", { cache: "no-store" });
      const data: PartnerProfileResponse = await res.json();

      if (!res.ok || !data?.ok || !data.item) {
        setMsg(data?.error ?? data?.message ?? "소개 정보를 불러오지 못했습니다.");
        setForm(EMPTY_FORM);
        setLoading(false);
        return;
      }

      setForm({
        category: data.item.category ?? "",
        categories: Array.isArray(data.item.categories) ? data.item.categories : [],
        intro: data.item.intro ?? "",
        benefitText: data.item.benefitText ?? "",
        kakaoChannelUrl: data.item.kakaoChannelUrl ?? "",
        applyUrl: data.item.applyUrl ?? "",
        address: data.item.address ?? "",
        phone: data.item.phone ?? "",
        coverImageUrl: data.item.coverImageUrl ?? "",
        isPublished: Boolean(data.item.isPublished),
      });
    } catch {
      setMsg("네트워크 오류");
      setForm(EMPTY_FORM);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  function updateField<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((prev) => ({
      ...prev,
      [key]: value,
    }));
  }

  async function save() {
    setSaving(true);
    setMsg("");

    try {
      const res = await fetch("/api/partner/profile", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          category: form.category,
          categories: form.categories,
          intro: normalizeInput(form.intro),
          benefitText: normalizeInput(form.benefitText),
          kakaoChannelUrl: form.kakaoChannelUrl,
          applyUrl: form.applyUrl,
          address: form.address,
          phone: form.phone,
          coverImageUrl: form.coverImageUrl,
          isPublished: form.isPublished,
        }),
      });

      const data: PartnerProfileResponse = await res.json();

      if (!res.ok || !data?.ok || !data.item) {
        setMsg(data?.error ?? data?.message ?? "저장에 실패했습니다.");
        setSaving(false);
        return;
      }

      setForm({
        category: data.item.category ?? "",
        categories: Array.isArray(data.item.categories) ? data.item.categories : [],
        intro: data.item.intro ?? "",
        benefitText: data.item.benefitText ?? "",
        kakaoChannelUrl: data.item.kakaoChannelUrl ?? "",
        applyUrl: data.item.applyUrl ?? "",
        address: data.item.address ?? "",
        phone: data.item.phone ?? "",
        coverImageUrl: data.item.coverImageUrl ?? "",
        isPublished: Boolean(data.item.isPublished),
      });

      setMsg(data.message ?? "저장되었습니다.");
    } catch {
      setMsg("네트워크 오류");
    } finally {
      setSaving(false);
    }
  }

  const messageIsSuccess =
    msg.includes("저장") && !msg.includes("실패") && !msg.includes("불러오지");

  const introCount = useMemo(() => form.intro.length, [form.intro]);
  const benefitCount = useMemo(() => form.benefitText.length, [form.benefitText]);

  return (
    <main className="partner-content-page">
      <section className="partner-content-page__hero">
        <div>
          <div className="partner-content-page__eyebrow">내 정보 관리</div>
          <h1 className="partner-content-page__title">소개 / 혜택 수정</h1>
          <div className="partner-content-page__desc">
            고객 페이지에 노출되는 소개글과 혜택 설명을 수정합니다.
          </div>
        </div>

        <div className="partner-content-page__hero-actions">
          <Link href="/partner/profile" className="partner-content-page__back">
            돌아가기
          </Link>

          <button
            type="button"
            onClick={save}
            disabled={saving || loading}
            className="partner-content-page__save"
          >
            {saving ? "저장 중..." : "저장"}
          </button>
        </div>
      </section>

      {msg ? (
        <div
          className={`partner-content-page__message ${
            messageIsSuccess ? "is-success" : "is-error"
          }`}
        >
          {msg}
        </div>
      ) : null}

      <section className="partner-content-page__card">
        {loading ? (
          <div className="partner-content-page__loading">불러오는 중...</div>
        ) : (
          <div className="partner-content-page__grid">
            <div className="partner-content-page__col">
              <label className="partner-content-page__label">소개글</label>

              <textarea
                value={form.intro}
                onChange={(e) => updateField("intro", e.target.value)}
                rows={12}
                maxLength={2000}
                placeholder="고객에게 보여줄 업체 소개글을 입력하세요."
                className="partner-content-page__textarea"
              />

              <div className="partner-content-page__meta">
                <div>고객이 업체를 처음 볼 때 확인하는 대표 소개 문구입니다.</div>
                <div>{summarizeLength(form.intro, 2000)}</div>
              </div>

              <div className="partner-content-page__preview">
                {introCount > 0 ? form.intro : "소개글 미리보기가 여기에 표시됩니다."}
              </div>
            </div>

            <div className="partner-content-page__col">
              <label className="partner-content-page__label">혜택 설명</label>

              <textarea
                value={form.benefitText}
                onChange={(e) => updateField("benefitText", e.target.value)}
                rows={12}
                maxLength={2000}
                placeholder="예: 방문 상담 시 5,000P 사용 가능"
                className="partner-content-page__textarea"
              />

              <div className="partner-content-page__meta">
                <div>고객에게 제공할 포인트 혜택이나 이벤트 내용을 안내합니다.</div>
                <div>{summarizeLength(form.benefitText, 2000)}</div>
              </div>

              <div className="partner-content-page__preview">
                {benefitCount > 0
                  ? form.benefitText
                  : "혜택 설명 미리보기가 여기에 표시됩니다."}
              </div>
            </div>
          </div>
        )}
      </section>

      <style jsx>{`
        .partner-content-page {
          display: grid;
          gap: 20px;
          min-width: 0;
        }

        .partner-content-page__hero,
        .partner-content-page__card {
          border: 1px solid #e5e7eb;
          border-radius: 18px;
          background: #fff;
          box-shadow: 0 4px 16px rgba(15, 23, 42, 0.04);
        }

        .partner-content-page__hero {
          padding: 20px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 16px;
          flex-wrap: wrap;
        }

        .partner-content-page__eyebrow {
          font-size: 14px;
          color: #6b7280;
          margin-bottom: 6px;
        }

        .partner-content-page__title {
          font-size: 28px;
          font-weight: 900;
          margin: 0;
          color: #111827;
          line-height: 1.2;
          word-break: keep-all;
        }

        .partner-content-page__desc {
          margin-top: 8px;
          color: #4b5563;
          line-height: 1.6;
          word-break: keep-all;
        }

        .partner-content-page__hero-actions {
          display: flex;
          gap: 10px;
          flex-wrap: wrap;
        }

        .partner-content-page__back,
        .partner-content-page__save {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          min-height: 44px;
          padding: 0 16px;
          border-radius: 12px;
          font-weight: 800;
          text-decoration: none;
          box-sizing: border-box;
        }

        .partner-content-page__back {
          border: 1px solid #d1d5db;
          background: #fff;
          color: #111827;
        }

        .partner-content-page__save {
          border: 1px solid #111827;
          background: #111827;
          color: #fff;
          cursor: pointer;
        }

        .partner-content-page__save:disabled {
          background: #9ca3af;
          border-color: #9ca3af;
          cursor: not-allowed;
        }

        .partner-content-page__message {
          padding: 12px;
          border-radius: 12px;
          font-weight: 700;
        }

        .partner-content-page__message.is-success {
          background: #ecfdf5;
          border: 1px solid #a7f3d0;
          color: #065f46;
        }

        .partner-content-page__message.is-error {
          background: #fef2f2;
          border: 1px solid #fecaca;
          color: #991b1b;
        }

        .partner-content-page__card {
          padding: 20px;
        }

        .partner-content-page__loading {
          opacity: 0.7;
        }

        .partner-content-page__grid {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 20px;
          min-width: 0;
        }

        .partner-content-page__col {
          display: grid;
          gap: 12px;
          min-width: 0;
        }

        .partner-content-page__label {
          display: block;
          font-weight: 800;
          color: #111827;
        }

        .partner-content-page__textarea {
          width: 100%;
          min-width: 0;
          border-radius: 14px;
          border: 1px solid #d1d5db;
          padding: 14px;
          resize: vertical;
          line-height: 1.7;
          box-sizing: border-box;
          background: #fff;
        }

        .partner-content-page__meta {
          display: flex;
          justify-content: space-between;
          gap: 12px;
          flex-wrap: wrap;
          font-size: 13px;
          color: #6b7280;
          line-height: 1.6;
        }

        .partner-content-page__preview {
          padding: 14px;
          border-radius: 12px;
          background: #f9fafb;
          border: 1px solid #e5e7eb;
          line-height: 1.7;
          color: #374151;
          min-height: 140px;
          white-space: pre-wrap;
          word-break: break-word;
          overflow-wrap: anywhere;
        }

        @media (max-width: 900px) {
          .partner-content-page__grid {
            grid-template-columns: 1fr;
          }
        }

        @media (max-width: 640px) {
          .partner-content-page {
            gap: 16px;
          }

          .partner-content-page__hero,
          .partner-content-page__card {
            padding: 16px;
          }

          .partner-content-page__title {
            font-size: 24px;
          }

          .partner-content-page__hero-actions {
            width: 100%;
            display: grid;
            grid-template-columns: 1fr;
          }

          .partner-content-page__back,
          .partner-content-page__save {
            width: 100%;
          }

          .partner-content-page__preview {
            min-height: 120px;
          }
        }
      `}</style>
    </main>
  );
}