"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";

type PartnerProfileResponse = {
  ok: boolean;
  item?: {
    category?: string;
    categories?: string[];
    intro?: string;
    benefitText?: string;
    kakaoChannelUrl?: string;
    applyUrl?: string;
    address?: string;
    phone?: string;
    coverImageUrl?: string;
    isPublished?: boolean;
  };
  error?: string;
  message?: string;
};

type FieldErrors = {
  coverImageUrl: string;
};

type FormState = {
  category: string;
  categories: string[];
  intro: string;
  benefitText: string;
  kakaoChannelUrl: string;
  applyUrl: string;
  address: string;
  phone: string;
  coverImageUrl: string;
  isPublished: boolean;
};

const EMPTY_FORM: FormState = {
  category: "",
  categories: [],
  intro: "",
  benefitText: "",
  kakaoChannelUrl: "",
  applyUrl: "",
  address: "",
  phone: "",
  coverImageUrl: "",
  isPublished: false,
};

const EMPTY_FIELD_ERRORS: FieldErrors = {
  coverImageUrl: "",
};

function normalizeInput(value: string) {
  return value.trim();
}

function isValidHttpUrl(value: string) {
  if (!value.trim()) return true;

  try {
    const parsed = new URL(value.trim());
    return parsed.protocol === "http:" || parsed.protocol === "https:";
  } catch {
    return false;
  }
}

function validateForm(url: string): FieldErrors {
  const next: FieldErrors = {
    coverImageUrl: "",
  };

  if (url.trim() && !isValidHttpUrl(url)) {
    next.coverImageUrl =
      "대표 이미지 주소는 http:// 또는 https:// 로 시작하는 올바른 주소만 입력할 수 있습니다.";
  }

  return next;
}

export default function PartnerProfileImagePage() {
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");
  const [fieldErrors, setFieldErrors] = useState<FieldErrors>(EMPTY_FIELD_ERRORS);
  const [imageError, setImageError] = useState(false);

  async function load() {
    setLoading(true);
    setMsg("");
    setFieldErrors(EMPTY_FIELD_ERRORS);

    try {
      const res = await fetch("/api/partner/profile", { cache: "no-store" });
      const data: PartnerProfileResponse = await res.json();

      if (!res.ok || !data?.ok || !data.item) {
        setMsg(data?.error ?? data?.message ?? "이미지 정보를 불러오지 못했습니다.");
        setForm(EMPTY_FORM);
        setLoading(false);
        return;
      }

      setForm({
        category: data.item.category ?? "",
        categories: Array.isArray(data.item.categories) ? data.item.categories : [],
        intro: data.item.intro ?? "",
        benefitText: data.item.benefitText ?? "",
        kakaoChannelUrl: data.item.kakaoChannelUrl ?? "",
        applyUrl: data.item.applyUrl ?? "",
        address: data.item.address ?? "",
        phone: data.item.phone ?? "",
        coverImageUrl: data.item.coverImageUrl ?? "",
        isPublished: Boolean(data.item.isPublished),
      });
      setImageError(false);
    } catch {
      setMsg("네트워크 오류");
      setForm(EMPTY_FORM);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  const trimmedImageUrl = useMemo(() => {
    return form.coverImageUrl.trim();
  }, [form.coverImageUrl]);

  useEffect(() => {
    setImageError(false);
  }, [trimmedImageUrl]);

  function updateField(value: string) {
    setForm((prev) => ({
      ...prev,
      coverImageUrl: value,
    }));
    setFieldErrors(EMPTY_FIELD_ERRORS);
  }

  async function save() {
    setSaving(true);
    setMsg("");

    const normalizedUrl = normalizeInput(form.coverImageUrl);
    const nextErrors = validateForm(normalizedUrl);
    setFieldErrors(nextErrors);

    if (nextErrors.coverImageUrl) {
      setMsg("입력값을 다시 확인해주세요.");
      setSaving(false);
      return;
    }

    try {
      const res = await fetch("/api/partner/profile", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          category: form.category,
          categories: form.categories,
          intro: form.intro,
          benefitText: form.benefitText,
          kakaoChannelUrl: form.kakaoChannelUrl,
          applyUrl: form.applyUrl,
          address: form.address,
          phone: form.phone,
          coverImageUrl: normalizedUrl,
          isPublished: form.isPublished,
        }),
      });

      const data: PartnerProfileResponse = await res.json();

      if (!res.ok || !data?.ok || !data.item) {
        setMsg(data?.error ?? data?.message ?? "저장에 실패했습니다.");
        setSaving(false);
        return;
      }

      setForm({
        category: data.item.category ?? "",
        categories: Array.isArray(data.item.categories) ? data.item.categories : [],
        intro: data.item.intro ?? "",
        benefitText: data.item.benefitText ?? "",
        kakaoChannelUrl: data.item.kakaoChannelUrl ?? "",
        applyUrl: data.item.applyUrl ?? "",
        address: data.item.address ?? "",
        phone: data.item.phone ?? "",
        coverImageUrl: data.item.coverImageUrl ?? "",
        isPublished: Boolean(data.item.isPublished),
      });

      setMsg(data.message ?? "저장되었습니다.");
      setImageError(false);
    } catch {
      setMsg("네트워크 오류");
    } finally {
      setSaving(false);
    }
  }

  const messageIsSuccess =
    msg.includes("저장") && !msg.includes("실패") && !msg.includes("확인");

  return (
    <main className="partner-image-page">
      <section className="partner-image-page__hero">
        <div>
          <div className="partner-image-page__eyebrow">내 정보 관리</div>
          <h1 className="partner-image-page__title">대표 이미지 수정</h1>
          <div className="partner-image-page__desc">
            고객 페이지 카드와 상세 화면에 노출될 대표 이미지를 등록하거나 수정합니다.
          </div>
        </div>

        <div className="partner-image-page__hero-actions">
          <Link href="/partner/profile" className="partner-image-page__back">
            돌아가기
          </Link>

          <button
            type="button"
            onClick={save}
            disabled={saving || loading}
            className="partner-image-page__save"
          >
            {saving ? "저장 중..." : "저장"}
          </button>
        </div>
      </section>

      {msg ? (
        <div
          className={`partner-image-page__message ${
            messageIsSuccess ? "is-success" : "is-error"
          }`}
        >
          {msg}
        </div>
      ) : null}

      <section className="partner-image-page__card">
        {loading ? (
          <div className="partner-image-page__loading">불러오는 중...</div>
        ) : (
          <div className="partner-image-page__grid">
            <section className="partner-image-panel">
              <div className="partner-image-panel__title">이미지 주소 입력</div>
              <div className="partner-image-panel__desc">
                브라우저에서 직접 열리는 이미지 URL만 입력해 주세요.
              </div>

              <div className="partner-image-panel__field">
                <label className="partner-image-panel__label">대표 이미지 URL</label>
                <input
                  value={form.coverImageUrl}
                  onChange={(e) => updateField(e.target.value)}
                  placeholder="https://example.com/image.jpg"
                  className={`partner-image-panel__input ${
                    fieldErrors.coverImageUrl ? "is-error" : ""
                  }`}
                />
                <div
                  className={`partner-image-panel__help ${
                    fieldErrors.coverImageUrl ? "is-error" : ""
                  }`}
                >
                  {fieldErrors.coverImageUrl ||
                    "권장 비율은 가로형 이미지입니다. http:// 또는 https:// 형식만 저장됩니다."}
                </div>
              </div>

              <div className="partner-image-panel__tips">
                <div className="partner-image-panel__tips-title">안내</div>
                <ul className="partner-image-panel__tips-list">
                  <li>고객 목록 카드와 상세페이지 상단 이미지에 사용됩니다.</li>
                  <li>너무 작은 이미지보다 가로형 고화질 이미지를 권장합니다.</li>
                  <li>이미지가 열리지 않으면 고객 화면에서도 정상 표시되지 않습니다.</li>
                </ul>
              </div>
            </section>

            <section className="partner-image-panel">
              <div className="partner-image-panel__title">미리보기</div>
              <div className="partner-image-panel__desc">
                저장 전에 실제 노출 형태를 미리 확인할 수 있습니다.
              </div>

              {!trimmedImageUrl ? (
                <div className="partner-image-panel__empty">
                  대표 이미지 URL을 입력하면 여기에서 미리보기가 표시됩니다.
                </div>
              ) : fieldErrors.coverImageUrl ? (
                <div className="partner-image-panel__error">
                  대표 이미지 주소 형식을 다시 확인해주세요.
                </div>
              ) : imageError ? (
                <div className="partner-image-panel__error">
                  이미지를 불러올 수 없습니다.
                  <br />
                  브라우저에서 직접 열리는 이미지 URL인지 확인해주세요.
                </div>
              ) : (
                <div className="partner-image-panel__preview-wrap">
                  <img
                    src={trimmedImageUrl}
                    alt="대표 이미지 미리보기"
                    onError={() => setImageError(true)}
                    className="partner-image-panel__preview"
                  />
                </div>
              )}
            </section>
          </div>
        )}
      </section>

      <style jsx>{`
        .partner-image-page {
          display: grid;
          gap: 20px;
          min-width: 0;
        }

        .partner-image-page__hero,
        .partner-image-page__card,
        .partner-image-page__message {
          border: 1px solid #e5e7eb;
          border-radius: 20px;
          background: #fff;
          box-shadow: 0 4px 16px rgba(15, 23, 42, 0.04);
        }

        .partner-image-page__hero {
          padding: 20px;
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 16px;
          flex-wrap: wrap;
        }

        .partner-image-page__eyebrow {
          font-size: 14px;
          color: #6b7280;
          margin-bottom: 6px;
        }

        .partner-image-page__title {
          font-size: 28px;
          font-weight: 900;
          margin: 0;
          color: #111827;
          line-height: 1.2;
          word-break: keep-all;
        }

        .partner-image-page__desc {
          margin-top: 8px;
          color: #4b5563;
          line-height: 1.6;
          word-break: keep-all;
        }

        .partner-image-page__hero-actions {
          display: flex;
          gap: 10px;
          flex-wrap: wrap;
        }

        .partner-image-page__back,
        .partner-image-page__save {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          min-height: 44px;
          padding: 0 16px;
          border-radius: 12px;
          font-weight: 800;
          text-decoration: none;
          box-sizing: border-box;
        }

        .partner-image-page__back {
          border: 1px solid #d1d5db;
          background: #fff;
          color: #111827;
        }

        .partner-image-page__save {
          border: 1px solid #111827;
          background: #111827;
          color: #fff;
          cursor: pointer;
        }

        .partner-image-page__save:disabled {
          background: #9ca3af;
          border-color: #9ca3af;
          cursor: not-allowed;
        }

        .partner-image-page__message {
          padding: 12px;
          font-weight: 700;
        }

        .partner-image-page__message.is-success {
          background: #ecfdf5;
          border-color: #a7f3d0;
          color: #065f46;
        }

        .partner-image-page__message.is-error {
          background: #fef2f2;
          border-color: #fecaca;
          color: #991b1b;
        }

        .partner-image-page__card {
          padding: 20px;
        }

        .partner-image-page__loading {
          opacity: 0.7;
        }

        .partner-image-page__grid {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 20px;
          min-width: 0;
        }

        .partner-image-panel {
          border: 1px solid #e5e7eb;
          border-radius: 18px;
          background: #fff;
          padding: 18px;
          display: grid;
          gap: 14px;
          min-width: 0;
        }

        .partner-image-panel__title {
          font-size: 22px;
          font-weight: 900;
          color: #111827;
          line-height: 1.25;
        }

        .partner-image-panel__desc {
          color: #6b7280;
          line-height: 1.6;
          word-break: keep-all;
        }

        .partner-image-panel__field {
          display: grid;
          gap: 8px;
        }

        .partner-image-panel__label {
          font-weight: 800;
          color: #111827;
        }

        .partner-image-panel__input {
          width: 100%;
          min-width: 0;
          min-height: 48px;
          padding: 0 12px;
          border-radius: 12px;
          border: 1px solid #d1d5db;
          box-sizing: border-box;
          background: #fff;
        }

        .partner-image-panel__input.is-error {
          border-color: #ef4444;
        }

        .partner-image-panel__help {
          font-size: 13px;
          color: #6b7280;
          line-height: 1.5;
        }

        .partner-image-panel__help.is-error {
          color: #b91c1c;
        }

        .partner-image-panel__tips {
          padding: 14px;
          border-radius: 14px;
          background: #f9fafb;
          border: 1px solid #e5e7eb;
        }

        .partner-image-panel__tips-title {
          font-weight: 900;
          color: #111827;
          margin-bottom: 8px;
        }

        .partner-image-panel__tips-list {
          margin: 0;
          padding-left: 18px;
          color: #4b5563;
          line-height: 1.7;
        }

        .partner-image-panel__preview-wrap {
          width: 100%;
          aspect-ratio: 16 / 9;
          border-radius: 16px;
          overflow: hidden;
          border: 1px solid #e5e7eb;
          background: #f3f4f6;
        }

        .partner-image-panel__preview {
          width: 100%;
          height: 100%;
          object-fit: cover;
          display: block;
        }

        .partner-image-panel__empty,
        .partner-image-panel__error {
          width: 100%;
          aspect-ratio: 16 / 9;
          border-radius: 16px;
          display: flex;
          align-items: center;
          justify-content: center;
          text-align: center;
          padding: 20px;
          font-weight: 700;
          line-height: 1.6;
        }

        .partner-image-panel__empty {
          border: 1px dashed #d1d5db;
          background: #f9fafb;
          color: #9ca3af;
        }

        .partner-image-panel__error {
          border: 1px solid #fecaca;
          background: #fef2f2;
          color: #991b1b;
        }

        @media (max-width: 900px) {
          .partner-image-page__grid {
            grid-template-columns: 1fr;
          }
        }

        @media (max-width: 640px) {
          .partner-image-page {
            gap: 16px;
          }

          .partner-image-page__hero,
          .partner-image-page__card,
          .partner-image-panel {
            padding: 16px;
          }

          .partner-image-page__title {
            font-size: 24px;
          }

          .partner-image-page__hero-actions {
            width: 100%;
            display: grid;
            grid-template-columns: 1fr;
          }

          .partner-image-page__back,
          .partner-image-page__save {
            width: 100%;
          }

          .partner-image-panel__title {
            font-size: 20px;
          }
        }
      `}</style>
    </main>
  );
}