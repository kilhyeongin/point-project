"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

type SessionInfo = {
  uid: string;
  username: string;
  name: string;
  role: "PARTNER";
};

type Props = {
  session: SessionInfo;
  children: React.ReactNode;
};

const MENU_ITEMS = [
  { href: "/partner", label: "대시보드" },
  { href: "/partner/profile", label: "내 정보 관리" },
  { href: "/partner/profile/category", label: "카테고리 수정" },
  { href: "/partner/profile/content", label: "소개 / 혜택 수정" },
  { href: "/partner/profile/contact", label: "연락처 / 링크 수정" },
  { href: "/partner/profile/image", label: "대표 이미지 수정" },
];

function navLinkStyle(active: boolean): React.CSSProperties {
  return {
    display: "block",
    padding: "12px 14px",
    borderRadius: 12,
    border: active ? "1px solid #111827" : "1px solid #e5e7eb",
    background: active ? "#111827" : "#fff",
    color: active ? "#fff" : "#374151",
    textDecoration: "none",
    fontWeight: 800,
    lineHeight: 1.4,
    transition: "all 0.15s ease",
    boxShadow: active ? "0 8px 20px rgba(17,24,39,0.12)" : "none",
    wordBreak: "keep-all",
  };
}

function chipStyle(active: boolean): React.CSSProperties {
  return {
    flex: "0 0 auto",
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    minHeight: 40,
    padding: "0 14px",
    borderRadius: 999,
    border: active ? "1px solid #111827" : "1px solid #d1d5db",
    background: active ? "#111827" : "#fff",
    color: active ? "#fff" : "#374151",
    textDecoration: "none",
    fontWeight: 800,
    whiteSpace: "nowrap",
  };
}

export default function PartnerShellClient({ session, children }: Props) {
  const pathname = usePathname();

  async function handleLogout() {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
    } finally {
      window.location.href = "/login";
    }
  }

  function isActive(href: string) {
    if (href === "/partner") return pathname === "/partner";
    return pathname === href || pathname.startsWith(`${href}/`);
  }

  return (
    <div className="partner-shell">
      <div className="partner-shell__wrap">
        {/* 데스크톱 사이드바 */}
        <aside className="partner-shell__sidebar">
          <div className="partner-shell__sidebar-card">
            <div className="partner-shell__eyebrow">PARTNER MENU</div>
            <div className="partner-shell__sidebar-title">제휴사 메뉴</div>
            <div className="partner-shell__sidebar-user">
              {session.name}님
              <br />
              <span>{session.username}</span>
            </div>

            <nav className="partner-shell__nav">
              {MENU_ITEMS.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  style={navLinkStyle(isActive(item.href))}
                >
                  {item.label}
                </Link>
              ))}
            </nav>

            <button
              type="button"
              onClick={handleLogout}
              className="partner-shell__logout"
            >
              로그아웃
            </button>
          </div>
        </aside>

        {/* 본문 */}
        <section className="partner-shell__main">
          {/* 모바일 상단 */}
          <section className="partner-shell__mobile-top">
            <div className="partner-shell__hero">
              <div className="partner-shell__eyebrow">PARTNER</div>
              <h1 className="partner-shell__hero-title">제휴사 페이지</h1>
              <div className="partner-shell__hero-desc">
                {session.name}님, 업체 정보를 관리할 수 있습니다.
              </div>
            </div>

            <div className="partner-shell__mobile-nav-card">
              <div className="partner-shell__mobile-nav-title">빠른 이동</div>

              <div className="partner-shell__chip-row">
                {MENU_ITEMS.map((item) => (
                  <Link
                    key={item.href}
                    href={item.href}
                    style={chipStyle(isActive(item.href))}
                  >
                    {item.label}
                  </Link>
                ))}
              </div>

              <button
                type="button"
                onClick={handleLogout}
                className="partner-shell__mobile-logout"
              >
                로그아웃
              </button>
            </div>
          </section>

          <div className="partner-shell__content">{children}</div>
        </section>
      </div>

      <style jsx>{`
        .partner-shell {
          min-height: 100vh;
          background: #f8fafc;
        }

        .partner-shell__wrap {
          max-width: 1280px;
          margin: 0 auto;
          padding: 16px;
          display: grid;
          grid-template-columns: 260px minmax(0, 1fr);
          gap: 20px;
        }

        .partner-shell__sidebar {
          min-width: 0;
        }

        .partner-shell__sidebar-card {
          position: sticky;
          top: 16px;
          border: 1px solid #e5e7eb;
          border-radius: 20px;
          background: #fff;
          box-shadow: 0 4px 16px rgba(15, 23, 42, 0.04);
          padding: 18px;
          display: grid;
          gap: 14px;
        }

        .partner-shell__eyebrow {
          font-size: 13px;
          color: #6b7280;
          font-weight: 800;
        }

        .partner-shell__sidebar-title {
          font-size: 28px;
          line-height: 1.15;
          font-weight: 900;
          color: #111827;
          word-break: keep-all;
          letter-spacing: -0.02em;
        }

        .partner-shell__sidebar-user {
          color: #4b5563;
          line-height: 1.6;
          word-break: keep-all;
        }

        .partner-shell__sidebar-user span {
          color: #6b7280;
          font-size: 14px;
        }

        .partner-shell__nav {
          display: grid;
          gap: 8px;
        }

        .partner-shell__logout {
          height: 44px;
          border: 1px solid #d1d5db;
          border-radius: 12px;
          background: #fff;
          color: #111827;
          font-weight: 800;
          cursor: pointer;
        }

        .partner-shell__main {
          min-width: 0;
          display: grid;
          gap: 16px;
        }

        .partner-shell__content {
          min-width: 0;
        }

        .partner-shell__mobile-top {
          display: none;
        }

        .partner-shell__hero,
        .partner-shell__mobile-nav-card {
          border: 1px solid #e5e7eb;
          border-radius: 20px;
          background: #fff;
          box-shadow: 0 4px 16px rgba(15, 23, 42, 0.04);
          padding: 18px;
        }

        .partner-shell__hero-title {
          margin: 6px 0 0;
          font-size: 32px;
          line-height: 1.15;
          font-weight: 900;
          color: #111827;
          word-break: keep-all;
          letter-spacing: -0.02em;
        }

        .partner-shell__hero-desc {
          margin-top: 10px;
          color: #4b5563;
          line-height: 1.7;
          word-break: keep-all;
        }

        .partner-shell__mobile-nav-title {
          font-size: 13px;
          color: #6b7280;
          font-weight: 800;
          margin-bottom: 10px;
        }

        .partner-shell__chip-row {
          display: flex;
          gap: 8px;
          overflow-x: auto;
          padding-bottom: 2px;
          scrollbar-width: thin;
          -webkit-overflow-scrolling: touch;
        }

        .partner-shell__chip-row::-webkit-scrollbar {
          height: 6px;
        }

        .partner-shell__chip-row::-webkit-scrollbar-thumb {
          background: #d1d5db;
          border-radius: 999px;
        }

        .partner-shell__mobile-logout {
          margin-top: 12px;
          width: 100%;
          height: 44px;
          border: 1px solid #d1d5db;
          border-radius: 12px;
          background: #fff;
          color: #111827;
          font-weight: 800;
          cursor: pointer;
        }

        @media (max-width: 1024px) {
          .partner-shell__wrap {
            grid-template-columns: 1fr;
            padding: 12px;
            gap: 16px;
          }

          .partner-shell__sidebar {
            display: none;
          }

          .partner-shell__mobile-top {
            display: grid;
            gap: 12px;
          }
        }

        @media (max-width: 640px) {
          .partner-shell__wrap {
            padding: 10px;
            gap: 12px;
          }

          .partner-shell__hero,
          .partner-shell__mobile-nav-card {
            padding: 16px;
          }

          .partner-shell__hero-title {
            font-size: 28px;
          }

          .partner-shell__hero-desc {
            font-size: 15px;
          }
        }
      `}</style>
    </div>
  );
}