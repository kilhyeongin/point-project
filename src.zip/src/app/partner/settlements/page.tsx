"use client";

import { useEffect, useState } from "react";

type SettlementItem = {
  id: string;
  periodKey: string;
  usedPoints: number;
  feeAmount: number;
  netPayable: number;
  status: string;
  paidAt?: string | null;
};

function formatNumber(n: number) {
  return Number(n || 0).toLocaleString();
}

export default function PartnerSettlementsPage() {
  const [items, setItems] = useState<SettlementItem[]>([]);
  const [loading, setLoading] = useState(false);

  async function load() {
    setLoading(true);

    const res = await fetch("/api/partner/settlements");
    const data = await res.json();

    if (data.ok) {
      setItems(data.items);
    }

    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  return (
    <main style={{ maxWidth: 1000, margin: "40px auto", padding: 16 }}>
      <h1 style={{ fontSize: 28, fontWeight: 900 }}>내 정산 내역</h1>

      <p style={{ marginTop: 8, opacity: 0.7 }}>
        제휴사 포인트 사용에 대한 정산 내역입니다.
      </p>

      <hr style={{ margin: "20px 0" }} />

      {loading && <p>불러오는 중...</p>}

      {!loading && (
        <div
          style={{
            border: "1px solid #ddd",
            borderRadius: 12,
            overflow: "hidden",
          }}
        >
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "120px 160px 160px 160px 120px 120px",
              padding: 12,
              background: "#f5f5f5",
              fontWeight: 900,
            }}
          >
            <div>기간</div>
            <div style={{ textAlign: "right" }}>사용포인트</div>
            <div style={{ textAlign: "right" }}>수수료</div>
            <div style={{ textAlign: "right" }}>지급액</div>
            <div>상태</div>
            <div>PDF</div>
          </div>

          {items.map((it) => (
            <div
              key={it.id}
              style={{
                display: "grid",
                gridTemplateColumns: "120px 160px 160px 160px 120px 120px",
                padding: 12,
                borderTop: "1px solid #eee",
                alignItems: "center",
              }}
            >
              <div>{it.periodKey}</div>

              <div style={{ textAlign: "right", fontWeight: 900 }}>
                {formatNumber(it.usedPoints)}P
              </div>

              <div style={{ textAlign: "right" }}>
                {formatNumber(it.feeAmount)}P
              </div>

              <div style={{ textAlign: "right", fontWeight: 900 }}>
                {formatNumber(it.netPayable)}P
              </div>

              <div>{it.status}</div>

              <div>
                <a
                  href={`/api/admin/settlements/pdf?periodKey=${it.periodKey}`}
                  target="_blank"
                  style={{
                    padding: "6px 10px",
                    borderRadius: 8,
                    border: "1px solid #111",
                    textDecoration: "none",
                    fontWeight: 900,
                  }}
                >
                  PDF
                </a>
              </div>
            </div>
          ))}

          {items.length === 0 && (
            <div style={{ padding: 16, textAlign: "center", opacity: 0.7 }}>
              정산 내역이 없습니다.
            </div>
          )}
        </div>
      )}
    </main>
  );
}