// src/app/partner/scan/page.tsx
// =======================================================
// PARTNER: QR 스캔으로 차감요청 생성
// -------------------------------------------------------
// ✔ html5-qrcode로 카메라 스캔
// ✔ 스캔 결과(payload)를 /api/partner/use-requests 로 전송
// =======================================================

"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Html5Qrcode } from "html5-qrcode";

function onlyDigitsToNumber(v: string) {
  const digits = v.replace(/[^\d]/g, "");
  if (!digits) return 0;
  const n = Number(digits);
  return Number.isFinite(n) ? n : 0;
}
function formatNumber(n: number) {
  return Number(n || 0).toLocaleString();
}

export default function PartnerScanPage() {
  const [scanned, setScanned] = useState<string>("");
  const [amountText, setAmountText] = useState<string>("0");
  const [note, setNote] = useState<string>("");
  const [msg, setMsg] = useState<string>("");

  const amountNum = useMemo(() => onlyDigitsToNumber(amountText), [amountText]);

  const qrRef = useRef<Html5Qrcode | null>(null);
  const regionId = "qr-reader-region";

  useEffect(() => {
    const qr = new Html5Qrcode(regionId);
    qrRef.current = qr;

    (async () => {
      setMsg("");
      try {
        const cams = await Html5Qrcode.getCameras();
        if (!cams || cams.length === 0) {
          setMsg("카메라를 찾을 수 없습니다.");
          return;
        }

        // 후면 카메라가 있으면 우선 사용
        const camId = cams[cams.length - 1].id;

        await qr.start(
          camId,
          { fps: 10, qrbox: 280 },
          (decodedText) => {
            // 중복 스캔 방지: 한 번만 고정
            if (!scanned) {
              setScanned(decodedText);
              setMsg("✅ 스캔 완료. 금액 입력 후 차감요청을 생성하세요.");
              // 스캔되면 카메라 정지
              qr.stop().catch(() => {});
            }
          },
          () => {}
        );
      } catch {
        setMsg("카메라 시작 실패 (권한을 허용했는지 확인)");
      }
    })();

    return () => {
    qrRef.current?.stop().catch(() => {});
    qrRef.current?.clear();
    qrRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function createUseRequestByQr() {
    setMsg("");

    if (!scanned) {
      setMsg("먼저 QR을 스캔해주세요.");
      return;
    }
    if (amountNum <= 0) {
      setMsg("금액을 1 이상 입력해주세요.");
      return;
    }

    try {
      const res = await fetch("/api/partner/use-requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          qrPayload: scanned,
          amount: amountNum,
          note: note.trim(),
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setMsg(data?.message ?? "차감요청 생성 실패");
        return;
      }

      setMsg(`✅ 차감요청 생성됨(승인대기) / ${formatNumber(amountNum)}P`);
      setScanned("");
      setAmountText("0");
      setNote("");

      // 스캔 재시작
      const qr = qrRef.current;
      if (qr) {
        const cams = await Html5Qrcode.getCameras();
        const camId = cams[cams.length - 1].id;
        await qr.start(
          camId,
          { fps: 10, qrbox: 280 },
          (decodedText) => {
            if (!scanned) {
              setScanned(decodedText);
              setMsg("✅ 스캔 완료. 금액 입력 후 차감요청을 생성하세요.");
              qr.stop().catch(() => {});
            }
          },
          () => {}
        );
      }
    } catch {
      setMsg("네트워크 오류");
    }
  }

  return (
    <main style={{ maxWidth: 700, margin: "40px auto", padding: 16 }}>
      <h1 style={{ fontSize: 24, fontWeight: 900 }}>QR 스캔 결제(차감요청)</h1>
      <p style={{ opacity: 0.75, marginTop: 8 }}>
        고객이 보여주는 QR을 스캔하고, 금액을 입력해 차감요청을 생성합니다. (관리자 승인 후 반영)
      </p>

      {msg && <p style={{ marginTop: 10, fontWeight: 900 }}>{msg}</p>}

      <div style={{ marginTop: 14, border: "1px solid #ddd", borderRadius: 16, padding: 12 }}>
        <div id={regionId} />
      </div>

      <div style={{ marginTop: 14, border: "1px solid #ddd", borderRadius: 16, padding: 16 }}>
        <div style={{ fontWeight: 900, marginBottom: 8 }}>스캔 결과</div>
        <div style={{ opacity: 0.75, wordBreak: "break-all" }}>
          {scanned ? scanned : "아직 스캔되지 않았습니다."}
        </div>

        <hr style={{ margin: "16px 0" }} />

        <label style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
          <span style={{ opacity: 0.8, fontWeight: 800 }}>금액</span>
          <input
            value={amountText}
            onChange={(e) => {
              const n = onlyDigitsToNumber(e.target.value);
              setAmountText(formatNumber(n));
            }}
            inputMode="numeric"
            style={{
              width: 220,
              padding: 10,
              borderRadius: 10,
              border: "1px solid #ccc",
              textAlign: "right",
              fontWeight: 900,
            }}
          />
          <span style={{ opacity: 0.8, fontWeight: 800 }}>P</span>
        </label>

        <div style={{ marginTop: 12 }}>
          <div style={{ fontWeight: 900 }}>메모(선택)</div>
          <input
            value={note}
            onChange={(e) => setNote(e.target.value)}
            style={{ width: "100%", padding: 10, borderRadius: 10, border: "1px solid #ccc", marginTop: 6 }}
          />
        </div>

        <button
          onClick={createUseRequestByQr}
          style={{
            marginTop: 14,
            width: "100%",
            padding: "12px 14px",
            borderRadius: 12,
            border: "1px solid #111",
            background: "#111",
            color: "#fff",
            fontWeight: 900,
            cursor: "pointer",
          }}
        >
          차감요청 생성
        </button>
      </div>
    </main>
  );
}