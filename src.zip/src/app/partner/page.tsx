"use client";

import { useEffect, useMemo, useState } from "react";

type RelationStatus = "LIKED" | "APPLIED";

type CustomerItem = {
  id: string;
  username: string;
  name: string;
  createdAt?: string;
  likedAt?: string;
  appliedAt?: string | null;
  balance?: number;
  relationStatus: RelationStatus;
  isMasked?: boolean;
  phone?: string;
  address?: string;
  detailAddress?: string;
};

type IssueReqItem = {
  id: string;
  status: "PENDING" | "APPROVED" | "REJECTED";
  amount: number;
  note?: string;
  createdAt: string;
  decidedAt?: string | null;
  to: { username: string; name: string } | null;
};

type TopupItem = {
  id: string;
  amount: number;
  status: "PENDING" | "APPROVED" | "REJECTED";
  note?: string;
  createdAt: string;
  decidedAt?: string | null;
};

type PointHistoryItem = {
  id: string;
  type: "ISSUE" | "USE";
  amount: number;
  note?: string;
  createdAt: string;
  customer: { username: string; name: string } | null;
};

type CustomerFilter = "ALL" | "LIKED" | "APPLIED";

function onlyDigitsToNumber(v: string) {
  const digits = v.replace(/[^\d]/g, "");
  if (!digits) return 0;
  const n = Number(digits);
  return Number.isFinite(n) ? n : 0;
}

function formatNumber(n: number) {
  return Number(n || 0).toLocaleString();
}

function statusLabel(s: string) {
  if (s === "PENDING") return "대기";
  if (s === "APPROVED") return "승인";
  if (s === "REJECTED") return "거절";
  return s;
}

function pointHistoryTypeLabel(type: string) {
  if (type === "ISSUE") return "포인트 지급";
  if (type === "USE") return "포인트 사용";
  return type;
}

function relationLabel(status: RelationStatus) {
  if (status === "LIKED") return "잠재고객";
  if (status === "APPLIED") return "신청고객";
  return status;
}

function formatDateText(v?: string | null) {
  if (!v) return "-";
  try {
    return new Date(v).toLocaleString();
  } catch {
    return "-";
  }
}

function cardStyle(): React.CSSProperties {
  return {
    border: "1px solid #e5e7eb",
    borderRadius: 20,
    padding: 20,
    background: "#fff",
    boxShadow: "0 4px 16px rgba(15,23,42,0.04)",
  };
}

function buttonStyle(dark = false, disabled = false): React.CSSProperties {
  return {
    minHeight: 44,
    padding: "0 16px",
    borderRadius: 12,
    border: dark ? "1px solid #111827" : "1px solid #d1d5db",
    background: disabled ? "#9ca3af" : dark ? "#111827" : "#fff",
    color: dark || disabled ? "#fff" : "#111827",
    cursor: disabled ? "not-allowed" : "pointer",
    fontWeight: 800,
  };
}

function filterChipStyle(active: boolean): React.CSSProperties {
  return {
    minHeight: 40,
    padding: "0 14px",
    borderRadius: 999,
    border: active ? "1px solid #111827" : "1px solid #d1d5db",
    background: active ? "#111827" : "#fff",
    color: active ? "#fff" : "#111827",
    cursor: "pointer",
    fontWeight: 800,
  };
}

function statusBadgeStyle(status: RelationStatus): React.CSSProperties {
  const isApplied = status === "APPLIED";
  return {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    minHeight: 28,
    padding: "0 10px",
    borderRadius: 999,
    fontSize: 12,
    fontWeight: 900,
    border: isApplied ? "1px solid #d1fae5" : "1px solid #e5e7eb",
    background: isApplied ? "#ecfdf5" : "#f8fafc",
    color: isApplied ? "#065f46" : "#374151",
  };
}

function EmptyText({ text }: { text: string }) {
  return (
    <div
      style={{
        opacity: 0.7,
        lineHeight: 1.7,
      }}
    >
      {text}
    </div>
  );
}

export default function PartnerPage() {
  const [myBalance, setMyBalance] = useState(0);
  const [balanceLoading, setBalanceLoading] = useState(false);

  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(false);
  const [items, setItems] = useState<CustomerItem[]>([]);
  const [error, setError] = useState("");
  const [customerFilter, setCustomerFilter] = useState<CustomerFilter>("ALL");

  const [openIssueUserId, setOpenIssueUserId] = useState<string | null>(null);
  const [openUseUserId, setOpenUseUserId] = useState<string | null>(null);

  const [issueAmountText, setIssueAmountText] = useState("0");
  const [issueNote, setIssueNote] = useState("");
  const [issueMsg, setIssueMsg] = useState("");

  const [useAmountText, setUseAmountText] = useState("0");
  const [useNote, setUseNote] = useState("");
  const [useMsg, setUseMsg] = useState("");

  const [topupAmountText, setTopupAmountText] = useState("100000");
  const [topupNote, setTopupNote] = useState("");
  const [topupMsg, setTopupMsg] = useState("");
  const [topupItems, setTopupItems] = useState<TopupItem[]>([]);

  const [reqItems, setReqItems] = useState<IssueReqItem[]>([]);
  const [reqLoading, setReqLoading] = useState(false);

  const [historyItems, setHistoryItems] = useState<PointHistoryItem[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);

  const debouncedQ = useMemo(() => q.trim(), [q]);
  const issueAmountNum = useMemo(
    () => onlyDigitsToNumber(issueAmountText),
    [issueAmountText]
  );
  const useAmountNum = useMemo(
    () => onlyDigitsToNumber(useAmountText),
    [useAmountText]
  );
  const topupAmountNum = useMemo(
    () => onlyDigitsToNumber(topupAmountText),
    [topupAmountText]
  );

  const likedCount = useMemo(
    () => items.filter((item) => item.relationStatus === "LIKED").length,
    [items]
  );
  const appliedCount = useMemo(
    () => items.filter((item) => item.relationStatus === "APPLIED").length,
    [items]
  );

  async function fetchMyBalance() {
    setBalanceLoading(true);
    try {
      const res = await fetch("/api/me/balance");
      const data = await res.json();
      if (res.ok && data.ok) {
        setMyBalance(Number(data.balance ?? 0));
      }
    } finally {
      setBalanceLoading(false);
    }
  }

  async function fetchCustomers() {
    setLoading(true);
    setError("");

    try {
      const params = new URLSearchParams();
      if (debouncedQ) params.set("q", debouncedQ);
      if (customerFilter !== "ALL") params.set("status", customerFilter);

      const query = params.toString();
      const url = query
        ? `/api/requesters/customers?${query}`
        : "/api/requesters/customers";

      const res = await fetch(url);
      const data = await res.json();

      if (!res.ok) {
        setError(data?.message ?? "고객 목록 조회 실패");
        setItems([]);
        return;
      }

      setItems(
        Array.isArray(data?.items)
          ? data.items.map((item: any) => ({
              ...item,
              relationStatus:
                item?.relationStatus === "APPLIED" ? "APPLIED" : "LIKED",
              balance: Number(item?.balance ?? 0),
            }))
          : []
      );
    } catch {
      setError("네트워크 오류");
      setItems([]);
    } finally {
      setLoading(false);
    }
  }

  async function fetchMyIssueRequests() {
    setReqLoading(true);
    try {
      const res = await fetch("/api/partner/issue-requests");
      const data = await res.json();

      if (!res.ok) {
        setReqItems([]);
        return;
      }

      setReqItems(data?.items ?? []);
    } catch {
      setReqItems([]);
    } finally {
      setReqLoading(false);
    }
  }

  async function fetchMyTopups() {
    try {
      const res = await fetch("/api/topup-requests");
      const data = await res.json();

      if (!res.ok) {
        setTopupItems([]);
        return;
      }

      setTopupItems(data?.items ?? []);
    } catch {
      setTopupItems([]);
    }
  }

  async function fetchPointHistory() {
    setHistoryLoading(true);
    try {
      const res = await fetch("/api/partner/point-history");
      const data = await res.json();

      if (!res.ok) {
        setHistoryItems([]);
        return;
      }

      setHistoryItems(data?.items ?? []);
    } catch {
      setHistoryItems([]);
    } finally {
      setHistoryLoading(false);
    }
  }

  useEffect(() => {
    fetchMyBalance();
    fetchCustomers();
    fetchMyIssueRequests();
    fetchMyTopups();
    fetchPointHistory();
  }, []);

  useEffect(() => {
    const t = setTimeout(() => {
      fetchCustomers();
    }, 250);

    return () => clearTimeout(t);
  }, [debouncedQ, customerFilter]);

  async function createIssueRequest(customer: CustomerItem) {
    setIssueMsg("");

    if (customer.relationStatus !== "APPLIED") {
      setIssueMsg("신청고객에게만 포인트를 지급할 수 있습니다.");
      return;
    }

    if (issueAmountNum <= 0) {
      setIssueMsg("지급 포인트를 1 이상 입력해주세요.");
      return;
    }

    try {
      const res = await fetch("/api/issue-requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: customer.id,
          amount: issueAmountNum,
          note: issueNote.trim(),
        }),
      });

      const data = await res.json();

      if (!res.ok || !data.ok) {
        setIssueMsg(data?.message ?? "포인트 지급 실패");
        return;
      }

      setIssueMsg(
        `✅ ${customer.username} 고객에게 ${formatNumber(
          issueAmountNum
        )}P 지급 완료 / 내 잔액 ${formatNumber(data.balanceAfter ?? 0)}P`
      );

      setOpenIssueUserId(null);
      setIssueAmountText("0");
      setIssueNote("");

      await fetchMyBalance();
      await fetchCustomers();
      await fetchMyIssueRequests();
      await fetchPointHistory();
    } catch {
      setIssueMsg("네트워크 오류");
    }
  }

  async function useDirect(customer: CustomerItem) {
    setUseMsg("");

    if (customer.relationStatus !== "APPLIED") {
      setUseMsg("신청고객에게만 포인트 사용 처리를 할 수 있습니다.");
      return;
    }

    if (useAmountNum <= 0) {
      setUseMsg("차감 포인트를 1 이상 입력해주세요.");
      return;
    }

    try {
      const res = await fetch("/api/partner/use-direct", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: customer.id,
          amount: useAmountNum,
          note: useNote.trim(),
        }),
      });

      const data = await res.json();

      if (!res.ok || !data.ok) {
        setUseMsg(data?.message ?? "포인트 사용 처리 실패");
        return;
      }

      setUseMsg(
        `✅ ${customer.username} 고객 포인트 ${formatNumber(
          useAmountNum
        )}P 차감 완료 / 고객 잔액 ${formatNumber(data.balanceAfter ?? 0)}P`
      );

      setOpenUseUserId(null);
      setUseAmountText("0");
      setUseNote("");

      await fetchCustomers();
      await fetchPointHistory();
    } catch {
      setUseMsg("네트워크 오류");
    }
  }

  async function createTopupRequest() {
    setTopupMsg("");

    if (topupAmountNum <= 0) {
      setTopupMsg("충전 요청 금액을 1 이상 입력해주세요.");
      return;
    }

    try {
      const res = await fetch("/api/topup-requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          amount: topupAmountNum,
          note: topupNote.trim(),
        }),
      });

      const data = await res.json();

      if (!res.ok || !data.ok) {
        setTopupMsg(data?.message ?? "충전 요청 생성 실패");
        return;
      }

      setTopupMsg(
        `✅ 충전 요청이 등록되었습니다. (${formatNumber(topupAmountNum)}P)`
      );
      setTopupAmountText("100000");
      setTopupNote("");

      await fetchMyTopups();
    } catch {
      setTopupMsg("네트워크 오류");
    }
  }

  return (
    <main className="partner-dashboard">
      <section
        style={{
          ...cardStyle(),
          display: "flex",
          justifyContent: "space-between",
          gap: 16,
          flexWrap: "wrap",
          alignItems: "center",
        }}
      >
        <div>
          <div style={{ fontSize: 14, color: "#6b7280", marginBottom: 6 }}>
            운영 요약
          </div>
          <h1
            style={{
              fontSize: 28,
              fontWeight: 900,
              margin: 0,
              lineHeight: 1.2,
              wordBreak: "keep-all",
            }}
          >
            제휴사 대시보드
          </h1>
          <div style={{ marginTop: 8, color: "#4b5563", lineHeight: 1.7 }}>
            잠재고객과 신청고객을 구분해서 확인하고, 신청고객에게만 포인트 처리를 진행합니다.
          </div>
        </div>

        <div
          style={{
            border: "1px solid #e5e7eb",
            borderRadius: 16,
            padding: "14px 16px",
            background: "#fafafa",
            minWidth: 220,
            width: "100%",
            maxWidth: 280,
          }}
        >
          <div style={{ fontSize: 13, color: "#6b7280", marginBottom: 6 }}>
            내 포인트 잔액
          </div>
          <div style={{ fontSize: 30, fontWeight: 900 }}>
            {balanceLoading ? "조회 중..." : `${formatNumber(myBalance)}P`}
          </div>
        </div>
      </section>

      <div className="partner-dashboard__grid">
        <section style={cardStyle()}>
          <div style={{ fontSize: 26, fontWeight: 900, marginBottom: 14, lineHeight: 1.2 }}>
            포인트 충전 요청
          </div>

          <div className="partner-dashboard__form-row">
            <input
              value={topupAmountText}
              onChange={(e) =>
                setTopupAmountText(String(onlyDigitsToNumber(e.target.value)))
              }
              inputMode="numeric"
              placeholder="충전 요청 금액"
              className="partner-dashboard__input"
            />
            <button onClick={createTopupRequest} style={buttonStyle(true)}>
              충전 요청
            </button>
          </div>

          <input
            value={topupNote}
            onChange={(e) => setTopupNote(e.target.value)}
            placeholder="입금자명 / 메모"
            className="partner-dashboard__input"
            style={{ marginTop: 10 }}
          />

          {topupMsg ? (
            <div style={{ marginTop: 12, fontWeight: 800, lineHeight: 1.6 }}>
              {topupMsg}
            </div>
          ) : null}
        </section>

        <section style={cardStyle()}>
          <div style={{ fontSize: 26, fontWeight: 900, marginBottom: 14, lineHeight: 1.2 }}>
            내 충전 요청 내역
          </div>

          {topupItems.length === 0 ? (
            <EmptyText text="충전 요청 내역이 없습니다." />
          ) : (
            <div style={{ display: "grid", gap: 10 }}>
              {topupItems.map((it) => (
                <div
                  key={it.id}
                  style={{
                    border: "1px solid #eef2f7",
                    borderRadius: 14,
                    padding: 14,
                    display: "grid",
                    gap: 6,
                  }}
                >
                  <div style={{ fontWeight: 900, lineHeight: 1.5 }}>
                    {formatNumber(it.amount)}P / {statusLabel(it.status)}
                  </div>
                  <div style={{ opacity: 0.7, fontSize: 14, lineHeight: 1.6 }}>
                    요청일: {new Date(it.createdAt).toLocaleString()}
                  </div>
                  <div style={{ opacity: 0.7, fontSize: 14, lineHeight: 1.6 }}>
                    {it.decidedAt
                      ? `처리일: ${new Date(it.decidedAt).toLocaleString()}`
                      : "처리 대기"}
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>

      <section style={{ ...cardStyle(), marginTop: 20 }}>
        <div
          style={{
            display: "flex",
            gap: 10,
            alignItems: "center",
            flexWrap: "wrap",
            marginBottom: 14,
          }}
        >
          <div style={{ fontSize: 24, fontWeight: 900 }}>고객 포인트 처리</div>

          <div className="partner-dashboard__chip-row">
            <button
              type="button"
              style={filterChipStyle(customerFilter === "ALL")}
              onClick={() => setCustomerFilter("ALL")}
            >
              전체 {items.length}명
            </button>
            <button
              type="button"
              style={filterChipStyle(customerFilter === "LIKED")}
              onClick={() => setCustomerFilter("LIKED")}
            >
              잠재고객 {likedCount}명
            </button>
            <button
              type="button"
              style={filterChipStyle(customerFilter === "APPLIED")}
              onClick={() => setCustomerFilter("APPLIED")}
            >
              신청고객 {appliedCount}명
            </button>
          </div>

          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="고객 검색 (아이디/이름)"
            className="partner-dashboard__input"
            style={{ flex: "1 1 260px", minWidth: 0 }}
          />

          <button onClick={fetchCustomers} style={buttonStyle(false)}>
            검색
          </button>
        </div>

        <div
          style={{
            marginBottom: 14,
            padding: 14,
            borderRadius: 14,
            background: "#f8fafc",
            border: "1px solid #e5e7eb",
            lineHeight: 1.7,
            color: "#374151",
          }}
        >
          잠재고객은 고객이 업체를 찜한 상태이며 최소 정보만 확인할 수 있습니다. 신청고객은 고객이 상담/이용 신청을 완료한 상태이며 상세정보 확인과 포인트 지급·사용 처리가 가능합니다.
        </div>

        {error ? (
          <div style={{ marginBottom: 10, color: "tomato", fontWeight: 800 }}>
            {error}
          </div>
        ) : null}

        {issueMsg ? (
          <div style={{ marginBottom: 10, fontWeight: 900, lineHeight: 1.6 }}>
            {issueMsg}
          </div>
        ) : null}

        {useMsg ? (
          <div style={{ marginBottom: 10, fontWeight: 900, lineHeight: 1.6 }}>
            {useMsg}
          </div>
        ) : null}

        <div style={{ opacity: 0.7, marginBottom: 10 }}>
          {loading ? "불러오는 중..." : `총 ${items.length}명`}
        </div>

        <div className="partner-dashboard__customer-table">
          <div className="partner-dashboard__customer-head">
            <div>구분</div>
            <div>아이디</div>
            <div>이름</div>
            <div>연결일</div>
            <div style={{ textAlign: "right" }}>고객 잔액</div>
            <div style={{ textAlign: "right" }}>작업</div>
          </div>

          {items.map((c) => {
            const issueOpened = openIssueUserId === c.id;
            const useOpened = openUseUserId === c.id;
            const isApplied = c.relationStatus === "APPLIED";

            return (
              <div key={c.id} style={{ borderBottom: "1px solid #f1f5f9" }}>
                <div className="partner-dashboard__customer-row">
                  <div>
                    <span style={statusBadgeStyle(c.relationStatus)}>
                      {relationLabel(c.relationStatus)}
                    </span>
                  </div>

                  <div>{c.username}</div>

                  <div>
                    <div style={{ fontWeight: 800 }}>{c.name}</div>
                    {isApplied ? (
                      <div style={{ marginTop: 4, fontSize: 13, color: "#6b7280" }}>
                        {c.phone || "-"}
                      </div>
                    ) : (
                      <div style={{ marginTop: 4, fontSize: 13, color: "#9ca3af" }}>
                        최소 정보 공개
                      </div>
                    )}
                  </div>

                  <div style={{ opacity: 0.7 }}>
                    {formatDateText(isApplied ? c.appliedAt : c.likedAt ?? c.createdAt)}
                  </div>

                  <div style={{ textAlign: "right", fontWeight: 800 }}>
                    {isApplied ? `${formatNumber(c.balance ?? 0)}P` : "-"}
                  </div>

                  <div
                    style={{
                      display: "flex",
                      justifyContent: "flex-end",
                      gap: 8,
                      flexWrap: "wrap",
                    }}
                  >
                    {isApplied ? (
                      <>
                        <button
                          onClick={() => {
                            setIssueMsg("");
                            setOpenUseUserId(null);
                            setOpenIssueUserId(issueOpened ? null : c.id);
                          }}
                          style={buttonStyle(issueOpened)}
                        >
                          {issueOpened ? "지급 닫기" : "지급"}
                        </button>

                        <button
                          onClick={() => {
                            setUseMsg("");
                            setOpenIssueUserId(null);
                            setOpenUseUserId(useOpened ? null : c.id);
                          }}
                          style={buttonStyle(useOpened)}
                        >
                          {useOpened ? "사용 닫기" : "사용"}
                        </button>
                      </>
                    ) : (
                      <div
                        style={{
                          fontSize: 13,
                          color: "#6b7280",
                          fontWeight: 700,
                        }}
                      >
                        신청 전
                      </div>
                    )}
                  </div>
                </div>

                {isApplied && issueOpened && (
                  <div style={{ padding: 12, background: "#fafafa" }}>
                    <div style={{ fontWeight: 900, marginBottom: 10 }}>
                      지급 대상: {c.name} ({c.username})
                    </div>

                    <div className="partner-dashboard__detail-grid">
                      <div>
                        <strong>전화번호</strong>
                        <div>{c.phone || "-"}</div>
                      </div>
                      <div>
                        <strong>주소</strong>
                        <div>
                          {[c.address, c.detailAddress].filter(Boolean).join(" " ) || "-"}
                        </div>
                      </div>
                    </div>

                    <div className="partner-dashboard__form-row" style={{ marginTop: 12 }}>
                      <input
                        value={issueAmountText}
                        onChange={(e) =>
                          setIssueAmountText(
                            formatNumber(onlyDigitsToNumber(e.target.value))
                          )
                        }
                        inputMode="numeric"
                        placeholder="지급 포인트"
                        className="partner-dashboard__input"
                        style={{ textAlign: "right", fontWeight: 800 }}
                      />

                      <button
                        onClick={() => createIssueRequest(c)}
                        style={buttonStyle(true)}
                      >
                        즉시 지급
                      </button>
                    </div>

                    <input
                      value={issueNote}
                      onChange={(e) => setIssueNote(e.target.value)}
                      placeholder="메모(선택)"
                      className="partner-dashboard__input"
                      style={{ marginTop: 10 }}
                    />

                    <div style={{ marginTop: 10, opacity: 0.7, lineHeight: 1.6 }}>
                      지급 즉시 제휴사 잔액에서 차감되고 고객 지갑에 적립됩니다.
                    </div>
                  </div>
                )}

                {isApplied && useOpened && (
                  <div style={{ padding: 12, background: "#fff8f0" }}>
                    <div style={{ fontWeight: 900, marginBottom: 10 }}>
                      사용 처리 대상: {c.name} ({c.username})
                    </div>

                    <div className="partner-dashboard__detail-grid">
                      <div>
                        <strong>전화번호</strong>
                        <div>{c.phone || "-"}</div>
                      </div>
                      <div>
                        <strong>주소</strong>
                        <div>
                          {[c.address, c.detailAddress].filter(Boolean).join(" ") || "-"}
                        </div>
                      </div>
                    </div>

                    <div className="partner-dashboard__form-row" style={{ marginTop: 12 }}>
                      <input
                        value={useAmountText}
                        onChange={(e) =>
                          setUseAmountText(
                            formatNumber(onlyDigitsToNumber(e.target.value))
                          )
                        }
                        inputMode="numeric"
                        placeholder="차감 포인트"
                        className="partner-dashboard__input"
                        style={{ textAlign: "right", fontWeight: 800 }}
                      />

                      <button
                        onClick={() => useDirect(c)}
                        style={buttonStyle(true)}
                      >
                        즉시 차감
                      </button>
                    </div>

                    <input
                      value={useNote}
                      onChange={(e) => setUseNote(e.target.value)}
                      placeholder="사용처 / 주문번호 / 메모"
                      className="partner-dashboard__input"
                      style={{ marginTop: 10 }}
                    />

                    <div style={{ marginTop: 10, opacity: 0.7, lineHeight: 1.6 }}>
                      고객 포인트를 제휴사에서 즉시 차감합니다. 정산 데이터에도 반영됩니다.
                    </div>
                  </div>
                )}
              </div>
            );
          })}

          {!loading && items.length === 0 ? (
            <div style={{ padding: 20, textAlign: "center", opacity: 0.7 }}>
              {customerFilter === "LIKED"
                ? "잠재고객이 없습니다."
                : customerFilter === "APPLIED"
                ? "신청고객이 없습니다."
                : "고객이 없습니다."}
            </div>
          ) : null}
        </div>

        <div className="partner-dashboard__customer-mobile">
          {items.map((c) => {
            const issueOpened = openIssueUserId === c.id;
            const useOpened = openUseUserId === c.id;
            const isApplied = c.relationStatus === "APPLIED";

            return (
              <article key={c.id} className="partner-dashboard__customer-card">
                <div className="partner-dashboard__customer-card-top">
                  <div>
                    <div style={{ marginBottom: 8 }}>
                      <span style={statusBadgeStyle(c.relationStatus)}>
                        {relationLabel(c.relationStatus)}
                      </span>
                    </div>
                    <div className="partner-dashboard__customer-name">{c.name}</div>
                    <div className="partner-dashboard__customer-id">{c.username}</div>
                  </div>

                  <div className="partner-dashboard__customer-balance">
                    {isApplied ? `${formatNumber(c.balance ?? 0)}P` : "-"}
                  </div>
                </div>

                <div className="partner-dashboard__customer-meta">
                  <div>
                    <strong>{isApplied ? "신청일" : "찜한 일시"}</strong>
                    <div>{formatDateText(isApplied ? c.appliedAt : c.likedAt ?? c.createdAt)}</div>
                  </div>

                  <div>
                    <strong>전화번호</strong>
                    <div>{isApplied ? c.phone || "-" : "비공개"}</div>
                  </div>

                  <div>
                    <strong>주소</strong>
                    <div>
                      {isApplied
                        ? [c.address, c.detailAddress].filter(Boolean).join(" ") || "-"
                        : "비공개"}
                    </div>
                  </div>
                </div>

                <div className="partner-dashboard__customer-actions">
                  {isApplied ? (
                    <>
                      <button
                        onClick={() => {
                          setIssueMsg("");
                          setOpenUseUserId(null);
                          setOpenIssueUserId(issueOpened ? null : c.id);
                        }}
                        style={buttonStyle(issueOpened)}
                      >
                        {issueOpened ? "지급 닫기" : "지급"}
                      </button>

                      <button
                        onClick={() => {
                          setUseMsg("");
                          setOpenIssueUserId(null);
                          setOpenUseUserId(useOpened ? null : c.id);
                        }}
                        style={buttonStyle(useOpened)}
                      >
                        {useOpened ? "사용 닫기" : "사용"}
                      </button>
                    </>
                  ) : (
                    <div
                      style={{
                        fontSize: 14,
                        fontWeight: 800,
                        color: "#6b7280",
                      }}
                    >
                      신청 완료 후 포인트 처리 가능
                    </div>
                  )}
                </div>

                {isApplied && issueOpened && (
                  <div className="partner-dashboard__mobile-open-box is-issue">
                    <div style={{ fontWeight: 900, marginBottom: 10 }}>
                      지급 대상: {c.name} ({c.username})
                    </div>

                    <div className="partner-dashboard__form-row">
                      <input
                        value={issueAmountText}
                        onChange={(e) =>
                          setIssueAmountText(
                            formatNumber(onlyDigitsToNumber(e.target.value))
                          )
                        }
                        inputMode="numeric"
                        placeholder="지급 포인트"
                        className="partner-dashboard__input"
                        style={{ textAlign: "right", fontWeight: 800 }}
                      />

                      <button
                        onClick={() => createIssueRequest(c)}
                        style={buttonStyle(true)}
                      >
                        즉시 지급
                      </button>
                    </div>

                    <input
                      value={issueNote}
                      onChange={(e) => setIssueNote(e.target.value)}
                      placeholder="메모(선택)"
                      className="partner-dashboard__input"
                      style={{ marginTop: 10 }}
                    />

                    <div style={{ marginTop: 10, opacity: 0.7, lineHeight: 1.6 }}>
                      지급 즉시 제휴사 잔액에서 차감되고 고객 지갑에 적립됩니다.
                    </div>
                  </div>
                )}

                {isApplied && useOpened && (
                  <div className="partner-dashboard__mobile-open-box is-use">
                    <div style={{ fontWeight: 900, marginBottom: 10 }}>
                      사용 처리 대상: {c.name} ({c.username})
                    </div>

                    <div className="partner-dashboard__form-row">
                      <input
                        value={useAmountText}
                        onChange={(e) =>
                          setUseAmountText(
                            formatNumber(onlyDigitsToNumber(e.target.value))
                          )
                        }
                        inputMode="numeric"
                        placeholder="차감 포인트"
                        className="partner-dashboard__input"
                        style={{ textAlign: "right", fontWeight: 800 }}
                      />

                      <button
                        onClick={() => useDirect(c)}
                        style={buttonStyle(true)}
                      >
                        즉시 차감
                      </button>
                    </div>

                    <input
                      value={useNote}
                      onChange={(e) => setUseNote(e.target.value)}
                      placeholder="사용처 / 주문번호 / 메모"
                      className="partner-dashboard__input"
                      style={{ marginTop: 10 }}
                    />

                    <div style={{ marginTop: 10, opacity: 0.7, lineHeight: 1.6 }}>
                      고객 포인트를 제휴사에서 즉시 차감합니다. 정산 데이터에도 반영됩니다.
                    </div>
                  </div>
                )}
              </article>
            );
          })}

          {!loading && items.length === 0 ? (
            <div style={{ padding: 20, textAlign: "center", opacity: 0.7 }}>
              {customerFilter === "LIKED"
                ? "잠재고객이 없습니다."
                : customerFilter === "APPLIED"
                ? "신청고객이 없습니다."
                : "고객이 없습니다."}
            </div>
          ) : null}
        </div>
      </section>

      <div className="partner-dashboard__grid" style={{ marginTop: 20 }}>
        <section style={cardStyle()}>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              gap: 10,
              flexWrap: "wrap",
              marginBottom: 12,
            }}
          >
            <div style={{ fontSize: 24, fontWeight: 900 }}>최근 고객 지급 이력</div>
            <button onClick={fetchMyIssueRequests} style={buttonStyle(false)}>
              새로고침
            </button>
          </div>

          {reqLoading ? (
            <EmptyText text="불러오는 중..." />
          ) : reqItems.length === 0 ? (
            <EmptyText text="지급 이력이 없습니다." />
          ) : (
            <div style={{ display: "grid", gap: 10 }}>
              {reqItems.map((it) => (
                <div
                  key={it.id}
                  style={{
                    border: "1px solid #eef2f7",
                    borderRadius: 14,
                    padding: 14,
                    display: "grid",
                    gap: 6,
                  }}
                >
                  <div style={{ fontWeight: 900, lineHeight: 1.6 }}>
                    {it.to?.name} ({it.to?.username}) / {formatNumber(it.amount)}P /{" "}
                    {statusLabel(it.status)}
                  </div>
                  <div style={{ opacity: 0.7, fontSize: 14, lineHeight: 1.6 }}>
                    실행일: {new Date(it.createdAt).toLocaleString()}
                  </div>
                  <div style={{ opacity: 0.7, fontSize: 14, lineHeight: 1.6 }}>
                    {it.decidedAt
                      ? `처리시각: ${new Date(it.decidedAt).toLocaleString()}`
                      : "-"}
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        <section style={cardStyle()}>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              gap: 10,
              flexWrap: "wrap",
              marginBottom: 12,
            }}
          >
            <div style={{ fontSize: 24, fontWeight: 900 }}>최근 포인트 처리 이력</div>
            <button onClick={fetchPointHistory} style={buttonStyle(false)}>
              새로고침
            </button>
          </div>

          {historyLoading ? (
            <EmptyText text="불러오는 중..." />
          ) : historyItems.length === 0 ? (
            <EmptyText text="처리 이력이 없습니다." />
          ) : (
            <div style={{ display: "grid", gap: 10 }}>
              {historyItems.map((it) => (
                <div
                  key={it.id}
                  style={{
                    border: "1px solid #eef2f7",
                    borderRadius: 14,
                    padding: 14,
                    display: "grid",
                    gap: 6,
                  }}
                >
                  <div style={{ fontWeight: 900, lineHeight: 1.6 }}>
                    {it.customer?.name} ({it.customer?.username})
                  </div>
                  <div style={{ opacity: 0.85, lineHeight: 1.6 }}>
                    {pointHistoryTypeLabel(it.type)} /{" "}
                    {it.type === "ISSUE" ? "+" : "-"}
                    {formatNumber(Math.abs(it.amount))}P
                  </div>
                  {it.note ? (
                    <div style={{ opacity: 0.8, fontSize: 14, lineHeight: 1.6 }}>
                      메모: {it.note}
                    </div>
                  ) : null}
                  <div style={{ opacity: 0.7, fontSize: 14, lineHeight: 1.6 }}>
                    처리시각: {new Date(it.createdAt).toLocaleString()}
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>

      <style jsx>{`
        .partner-dashboard {
          min-width: 0;
        }

        .partner-dashboard__grid {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 16px;
          min-width: 0;
        }

        .partner-dashboard__chip-row {
          display: flex;
          gap: 8px;
          flex-wrap: wrap;
        }

        .partner-dashboard__form-row {
          display: flex;
          gap: 10px;
          align-items: center;
          flex-wrap: wrap;
        }

        .partner-dashboard__detail-grid {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 10px;
          padding: 12px;
          border-radius: 12px;
          background: #ffffff;
          border: 1px solid #e5e7eb;
        }

        .partner-dashboard__detail-grid strong {
          display: block;
          color: #111827;
          margin-bottom: 4px;
        }

        .partner-dashboard__input {
          width: 100%;
          min-width: 0;
          min-height: 48px;
          padding: 0 12px;
          border-radius: 12px;
          border: 1px solid #d1d5db;
          box-sizing: border-box;
          background: #fff;
        }

        .partner-dashboard__customer-table {
          border: 1px solid #e5e7eb;
          border-radius: 14px;
          overflow: hidden;
          background: #fff;
        }

        .partner-dashboard__customer-head,
        .partner-dashboard__customer-row {
          display: grid;
          grid-template-columns: 120px 160px minmax(180px, 1fr) 180px 140px 220px;
          column-gap: 10px;
          align-items: center;
          padding: 12px;
        }

        .partner-dashboard__customer-head {
          background: #f8fafc;
          font-weight: 800;
          border-bottom: 1px solid #e5e7eb;
        }

        .partner-dashboard__customer-mobile {
          display: none;
        }

        .partner-dashboard__customer-card {
          border: 1px solid #e5e7eb;
          border-radius: 16px;
          background: #fff;
          padding: 14px;
          display: grid;
          gap: 12px;
        }

        .partner-dashboard__customer-card-top {
          display: flex;
          justify-content: space-between;
          gap: 12px;
          align-items: flex-start;
        }

        .partner-dashboard__customer-name {
          font-size: 20px;
          font-weight: 900;
          color: #111827;
          line-height: 1.2;
        }

        .partner-dashboard__customer-id {
          margin-top: 6px;
          color: #6b7280;
          line-height: 1.5;
        }

        .partner-dashboard__customer-balance {
          font-weight: 900;
          color: #111827;
          white-space: nowrap;
        }

        .partner-dashboard__customer-meta {
          display: grid;
          gap: 8px;
          color: #374151;
          line-height: 1.6;
        }

        .partner-dashboard__customer-meta strong {
          color: #111827;
          display: block;
          margin-bottom: 2px;
        }

        .partner-dashboard__customer-actions {
          display: flex;
          gap: 8px;
          flex-wrap: wrap;
        }

        .partner-dashboard__mobile-open-box {
          border-radius: 14px;
          padding: 12px;
        }

        .partner-dashboard__mobile-open-box.is-issue {
          background: #fafafa;
        }

        .partner-dashboard__mobile-open-box.is-use {
          background: #fff8f0;
        }

        @media (max-width: 1200px) {
          .partner-dashboard__customer-head,
          .partner-dashboard__customer-row {
            grid-template-columns: 110px 130px minmax(160px, 1fr) 160px 120px 200px;
          }
        }

        @media (max-width: 1100px) {
          .partner-dashboard__grid {
            grid-template-columns: 1fr;
          }

          .partner-dashboard__detail-grid {
            grid-template-columns: 1fr;
          }
        }

        @media (max-width: 900px) {
          .partner-dashboard__customer-table {
            display: none;
          }

          .partner-dashboard__customer-mobile {
            display: grid;
            gap: 12px;
          }
        }

        @media (max-width: 640px) {
          .partner-dashboard__form-row {
            display: grid;
            grid-template-columns: 1fr;
          }

          .partner-dashboard__customer-card-top {
            display: grid;
            gap: 8px;
          }

          .partner-dashboard__customer-actions {
            display: grid;
            grid-template-columns: 1fr 1fr;
          }
        }
      `}</style>
    </main>
  );
}