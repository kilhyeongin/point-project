// src/app/api/customer/favorites/[partnerId]/route.ts
// =======================================================
// CUSTOMER 관심업체 등록 / 해제
// -------------------------------------------------------
// POST   : 관심업체 등록(LIKED)
// DELETE : 관심업체 해제
// =======================================================

import { NextResponse } from "next/server";
import mongoose from "mongoose";
import { getSessionFromCookies } from "@/lib/auth";
import { connectDB } from "@/lib/db";
import { User } from "@/models/User";
import { FavoritePartner } from "@/models/FavoritePartner";

type Params = {
  params: Promise<{ partnerId: string }>;
};

function unauthorized(message = "로그인이 필요합니다.") {
  return NextResponse.json({ ok: false, error: message }, { status: 401 });
}

function forbidden(message = "고객만 사용할 수 있습니다.") {
  return NextResponse.json({ ok: false, error: message }, { status: 403 });
}

function badRequest(message: string) {
  return NextResponse.json({ ok: false, error: message }, { status: 400 });
}

function notFound(message: string) {
  return NextResponse.json({ ok: false, error: message }, { status: 404 });
}

async function validatePartner(partnerId: string) {
  if (!partnerId || !mongoose.Types.ObjectId.isValid(partnerId)) {
    return {
      ok: false as const,
      response: badRequest("유효한 partnerId가 필요합니다."),
    };
  }

  const partner = await User.findOne(
    {
      _id: partnerId,
      role: "PARTNER",
      status: "ACTIVE",
      "partnerProfile.isPublished": true,
    },
    {
      _id: 1,
    }
  ).lean();

  if (!partner) {
    return {
      ok: false as const,
      response: notFound("존재하지 않거나 공개되지 않은 업체입니다."),
    };
  }

  return { ok: true as const };
}

export async function POST(_req: Request, { params }: Params) {
  try {
    const session = await getSessionFromCookies();

    if (!session) return unauthorized();
    if (session.role !== "CUSTOMER") return forbidden();

    const { partnerId } = await params;

    await connectDB();

    const valid = await validatePartner(partnerId);
    if (!valid.ok) return valid.response;

    const existing = await FavoritePartner.findOne({
      customerId: session.uid,
      partnerId,
    }).lean();

    if (existing?.status === "APPLIED") {
      return NextResponse.json({
        ok: true,
        isFavorite: true,
        status: "APPLIED",
        message: "이미 신청한 업체입니다.",
      });
    }

    await FavoritePartner.findOneAndUpdate(
      {
        customerId: session.uid,
        partnerId,
      },
      {
        $setOnInsert: {
          customerId: session.uid,
          partnerId,
          status: "LIKED",
        },
      },
      {
        upsert: true,
        new: true,
        setDefaultsOnInsert: true,
      }
    );

    return NextResponse.json({
      ok: true,
      isFavorite: true,
      status: "LIKED",
      message: "관심업체에 저장되었습니다.",
    });
  } catch (error) {
    console.error("[CUSTOMER_FAVORITE_POST_ERROR]", error);
    return NextResponse.json(
      { ok: false, error: "관심업체 저장에 실패했습니다." },
      { status: 500 }
    );
  }
}

export async function DELETE(_req: Request, { params }: Params) {
  try {
    const session = await getSessionFromCookies();

    if (!session) return unauthorized();
    if (session.role !== "CUSTOMER") return forbidden();

    const { partnerId } = await params;

    if (!partnerId || !mongoose.Types.ObjectId.isValid(partnerId)) {
      return badRequest("유효한 partnerId가 필요합니다.");
    }

    await connectDB();

    await FavoritePartner.findOneAndDelete({
      customerId: session.uid,
      partnerId,
    });

    return NextResponse.json({
      ok: true,
      isFavorite: false,
      message: "관심업체가 해제되었습니다.",
    });
  } catch (error) {
    console.error("[CUSTOMER_FAVORITE_DELETE_ERROR]", error);
    return NextResponse.json(
      { ok: false, error: "관심업체 해제에 실패했습니다." },
      { status: 500 }
    );
  }
}
