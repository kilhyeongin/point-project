import { NextRequest, NextResponse } from "next/server";
import { connectDB } from "@/lib/db";
import { getSessionFromCookies } from "@/lib/auth";
import { User } from "@/models/User";
import {
  getCategoryLabels,
  normalizeCategoryCodes,
} from "@/lib/partnerCategories";

function textIncludes(source: unknown, keyword: string) {
  return String(source ?? "").toLowerCase().includes(keyword.toLowerCase());
}

export async function GET(req: NextRequest) {
  try {
    const session = await getSessionFromCookies();

    if (!session) {
      return NextResponse.json(
        { ok: false, error: "로그인이 필요합니다." },
        { status: 401 }
      );
    }

    if (session.role !== "CUSTOMER") {
      return NextResponse.json(
        { ok: false, error: "고객만 접근할 수 있습니다." },
        { status: 403 }
      );
    }

    const { searchParams } = new URL(req.url);
    const keyword = String(searchParams.get("q") ?? "").trim();
    const category = String(searchParams.get("category") ?? "").trim();

    await connectDB();

    const docs = await User.find(
      {
        role: "PARTNER",
        status: "ACTIVE",
        "partnerProfile.isPublished": true,
      },
      {
        username: 1,
        name: 1,
        partnerProfile: 1,
      }
    )
      .sort({ createdAt: -1 })
      .lean();

    const normalizedFilterCategories = await normalizeCategoryCodes(
      category ? [category] : [],
      undefined,
      {
        onlyActive: true,
        visibleToCustomerOnly: true,
      }
    );

    const items = [];

    for (const doc of docs as any[]) {
      const profile = doc.partnerProfile ?? {};

      const categoryCodes = await normalizeCategoryCodes(
        profile.categories,
        profile.category
      );

      if (
        normalizedFilterCategories.length > 0 &&
        !categoryCodes.some((code) => normalizedFilterCategories.includes(code))
      ) {
        continue;
      }

      const categoryLabels = await getCategoryLabels(categoryCodes);

      const searchable = [
        doc.name,
        doc.username,
        profile.intro,
        profile.benefitText,
        profile.address,
        ...categoryLabels,
      ];

      if (
        keyword &&
        !searchable.some((value) => textIncludes(value, keyword))
      ) {
        continue;
      }

      items.push({
        id: String(doc._id),
        username: String(doc.username ?? ""),
        name: String(doc.name ?? ""),
        category: categoryCodes[0] ?? "",
        categories: categoryCodes,
        categoryLabels,
        intro: String(profile.intro ?? ""),
        benefitText: String(profile.benefitText ?? ""),
        address: String(profile.address ?? ""),
        phone: String(profile.phone ?? ""),
        applyUrl: String(profile.applyUrl ?? ""),
        kakaoChannelUrl: String(profile.kakaoChannelUrl ?? ""),
        coverImageUrl: String(profile.coverImageUrl ?? ""),
      });
    }

    return NextResponse.json({
      ok: true,
      items,
    });
  } catch (error) {
    console.error("[CUSTOMER_PARTNERS_GET_ERROR]", error);
    return NextResponse.json(
      { ok: false, error: "제휴사 목록을 불러오지 못했습니다." },
      { status: 500 }
    );
  }
}