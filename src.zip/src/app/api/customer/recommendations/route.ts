import { NextResponse } from "next/server";
import { connectDB } from "@/lib/db";
import { getSessionFromCookies } from "@/lib/auth";
import { User } from "@/models/User";
import {
  getCategoryLabels,
  normalizeCategoryCodes,
} from "@/lib/partnerCategories";

export async function GET() {
  try {
    const session = await getSessionFromCookies();

    if (!session) {
      return NextResponse.json(
        { ok: false, error: "로그인이 필요합니다." },
        { status: 401 }
      );
    }

    if (session.role !== "CUSTOMER") {
      return NextResponse.json(
        { ok: false, error: "고객만 접근할 수 있습니다." },
        { status: 403 }
      );
    }

    await connectDB();

    const me = await User.findById(
      session.uid,
      {
        customerProfile: 1,
      }
    ).lean();

    if (!me) {
      return NextResponse.json(
        { ok: false, error: "고객 정보를 찾을 수 없습니다." },
        { status: 404 }
      );
    }

    const myInterests = await normalizeCategoryCodes(
      (me as any)?.customerProfile?.interests ?? [],
      undefined,
      {
        onlyActive: true,
        visibleToCustomerOnly: true,
      }
    );

    const partnerDocs = await User.find(
      {
        role: "PARTNER",
        status: "ACTIVE",
        "partnerProfile.isPublished": true,
      },
      {
        username: 1,
        name: 1,
        partnerProfile: 1,
      }
    )
      .sort({ createdAt: -1 })
      .lean();

    const scoredItems = [];

    for (const doc of partnerDocs as any[]) {
      const profile = doc.partnerProfile ?? {};

      const categoryCodes = await normalizeCategoryCodes(
        profile.categories,
        profile.category
      );

      const matchCount = categoryCodes.filter((code) =>
        myInterests.includes(code)
      ).length;

      if (myInterests.length > 0 && matchCount === 0) {
        continue;
      }

      const categoryLabels = await getCategoryLabels(categoryCodes);

      scoredItems.push({
        id: String(doc._id),
        username: String(doc.username ?? ""),
        name: String(doc.name ?? ""),
        category: categoryCodes[0] ?? "",
        categories: categoryCodes,
        categoryLabels,
        intro: String(profile.intro ?? ""),
        benefitText: String(profile.benefitText ?? ""),
        address: String(profile.address ?? ""),
        phone: String(profile.phone ?? ""),
        applyUrl: String(profile.applyUrl ?? ""),
        kakaoChannelUrl: String(profile.kakaoChannelUrl ?? ""),
        coverImageUrl: String(profile.coverImageUrl ?? ""),
        score: matchCount,
      });
    }

    scoredItems.sort((a, b) => b.score - a.score);

    return NextResponse.json({
      ok: true,
      items: scoredItems.slice(0, 12),
      interests: myInterests,
    });
  } catch (error) {
    console.error("[CUSTOMER_RECOMMENDATIONS_GET_ERROR]", error);
    return NextResponse.json(
      { ok: false, error: "추천 제휴사를 불러오지 못했습니다." },
      { status: 500 }
    );
  }
}