import { NextResponse } from "next/server";
import mongoose from "mongoose";
import { getSessionFromCookies } from "@/lib/auth";
import { connectDB } from "@/lib/db";
import { FavoritePartner } from "@/models/FavoritePartner";
import { User } from "@/models/User";

type Params = {
  params: Promise<{ partnerId: string }>;
};

export async function POST(_req: Request, { params }: Params) {
  const session = await getSessionFromCookies();

  if (!session) {
    return NextResponse.json(
      { ok: false, message: "로그인이 필요합니다." },
      { status: 401 }
    );
  }

  if (session.role !== "CUSTOMER") {
    return NextResponse.json(
      { ok: false, message: "고객만 신청할 수 있습니다." },
      { status: 403 }
    );
  }

  const { partnerId } = await params;

  if (!partnerId || !mongoose.Types.ObjectId.isValid(partnerId)) {
    return NextResponse.json(
      { ok: false, message: "잘못된 업체 ID입니다." },
      { status: 400 }
    );
  }

  await connectDB();

  const partner = await User.findOne(
    {
      _id: partnerId,
      role: "PARTNER",
      status: "ACTIVE",
      "partnerProfile.isPublished": true,
    },
    { _id: 1 }
  ).lean();

  if (!partner) {
    return NextResponse.json(
      { ok: false, message: "신청할 수 없는 업체입니다." },
      { status: 404 }
    );
  }

  const now = new Date();

  await FavoritePartner.findOneAndUpdate(
    {
      customerId: session.uid,
      partnerId,
    },
    {
      $set: {
        customerId: session.uid,
        partnerId,
        status: "APPLIED",
        appliedAt: now,
      },
      $setOnInsert: {
        createdAt: now,
      },
    },
    {
      upsert: true,
      new: true,
      setDefaultsOnInsert: true,
    }
  );

  return NextResponse.json({
    ok: true,
    partnerId,
    status: "APPLIED",
    appliedAt: now,
    message: "제휴사 신청이 완료되었습니다.",
  });
}
