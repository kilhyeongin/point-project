// src/app/api/partner/use-requests/route.ts
// =======================================================
// PARTNER 전용: 포인트 차감요청(UseRequest) API
// -------------------------------------------------------
// GET  : 내가 만든 차감요청 목록 조회 (+ 대상 고객 정보 포함)
// POST : 차감요청 생성
//   - 방법 A) toUsername 로 생성
//   - 방법 B) qrToken(스캔) 로 생성  ✅
// =======================================================

import { NextResponse } from "next/server";
import mongoose from "mongoose";
import jwt from "jsonwebtoken";
import { getSessionFromCookies } from "@/lib/auth";
import { connectDB } from "@/lib/db";
import { User } from "@/models/User";
import { UseRequest } from "@/models/UseRequest";

function parseQrPayload(v: string) {
  const s = String(v || "").trim();
  if (!s) return "";
  // 고객 QR은 "POINTQR:<jwt>" 형태
  if (s.startsWith("POINTQR:")) return s.replace("POINTQR:", "").trim();
  return s;
}

export async function GET(req: Request) {
  const session = await getSessionFromCookies();
  if (!session) {
    return NextResponse.json({ ok: false, message: "로그인이 필요합니다." }, { status: 401 });
  }
  if (session.role !== "PARTNER") {
    return NextResponse.json({ ok: false, message: "제휴사만 접근 가능합니다." }, { status: 403 });
  }

  const { searchParams } = new URL(req.url);
  const statusParam = String(searchParams.get("status") ?? "ALL").toUpperCase();

  await connectDB();

  const filter: any = { partnerId: new mongoose.Types.ObjectId(session.uid) };
  if (["PENDING", "APPROVED", "REJECTED"].includes(statusParam)) {
    filter.status = statusParam;
  }

  const docs = await UseRequest.find(filter)
    .sort({ createdAt: -1 })
    .limit(50)
    .populate("userId", "username name");

  const items = docs.map((d: any) => ({
    id: d._id.toString(),
    status: d.status,
    amount: d.amount,
    note: d.note,
    createdAt: d.createdAt,
    decidedAt: d.decidedAt,
    to: d.userId ? { username: d.userId.username, name: d.userId.name } : null,
  }));

  return NextResponse.json({ ok: true, items });
}

export async function POST(req: Request) {
  const session = await getSessionFromCookies();
  if (!session) {
    return NextResponse.json({ ok: false, message: "로그인이 필요합니다." }, { status: 401 });
  }
  if (session.role !== "PARTNER") {
    return NextResponse.json({ ok: false, message: "제휴사만 요청할 수 있습니다." }, { status: 403 });
  }

  let body: any = {};
  try {
    body = await req.json();
  } catch {
    body = {};
  }

  const toUsername = String(body?.toUsername ?? "").trim().toLowerCase();
  const qrTokenRaw = String(body?.qrToken ?? "").trim();      // ✅ QR에서 들어오는 값
  const qrPayloadRaw = String(body?.qrPayload ?? "").trim();  // (스캐너가 payload 통째로 보낼 때 대비)
  const amount = Number(body?.amount ?? 0);
  const note = String(body?.note ?? "").trim();

  if (!Number.isFinite(amount) || amount <= 0) {
    return NextResponse.json({ ok: false, message: "amount는 1 이상 숫자여야 합니다." }, { status: 400 });
  }

  const HARD_MAX = 100_000_000;
  if (amount > HARD_MAX) {
    return NextResponse.json({ ok: false, message: "요청 금액이 너무 큽니다." }, { status: 400 });
  }

  await connectDB();

  // ✅ 대상 고객 찾기: (A) username 또는 (B) QR 토큰
  let targetUser: any = null;

  if (toUsername) {
    targetUser = await User.findOne(
      { username: toUsername },
      { _id: 1, role: 1, status: 1, username: 1, name: 1 }
    );
  } else {
    const secret = process.env.QR_SECRET;
    if (!secret) {
      return NextResponse.json({ ok: false, message: "QR_SECRET이 설정되어 있지 않습니다." }, { status: 500 });
    }

    const token = parseQrPayload(qrTokenRaw || qrPayloadRaw);
    if (!token) {
      return NextResponse.json({ ok: false, message: "toUsername 또는 qrToken이 필요합니다." }, { status: 400 });
    }

    try {
      const decoded: any = jwt.verify(token, secret, {
        issuer: "point-platform",
        audience: "partner-scan",
      });

      if (decoded?.typ !== "customer_qr") {
        return NextResponse.json({ ok: false, message: "QR 타입이 올바르지 않습니다." }, { status: 400 });
      }

      const customerId = String(decoded?.sub ?? "");
      if (!customerId) {
        return NextResponse.json({ ok: false, message: "QR에 고객 정보가 없습니다." }, { status: 400 });
      }

      targetUser = await User.findById(
        new mongoose.Types.ObjectId(customerId),
        { _id: 1, role: 1, status: 1, username: 1, name: 1 }
      );
    } catch (e: any) {
      const m = String(e?.message ?? "");
      const friendly =
        m.includes("jwt expired") ? "QR이 만료되었습니다. 고객에게 QR을 새로고침 요청하세요." :
        "QR 검증 실패";
      return NextResponse.json({ ok: false, message: friendly }, { status: 400 });
    }
  }

  if (!targetUser) {
    return NextResponse.json({ ok: false, message: "대상 고객을 찾을 수 없습니다." }, { status: 404 });
  }
  if (targetUser.status !== "ACTIVE") {
    return NextResponse.json({ ok: false, message: "대상 사용자가 활성 상태가 아닙니다." }, { status: 400 });
  }
  if (targetUser.role !== "CUSTOMER") {
    return NextResponse.json({ ok: false, message: "차감 대상은 고객(CUSTOMER)만 가능합니다." }, { status: 400 });
  }

  // UseRequest 생성
  const userId = new mongoose.Types.ObjectId(String(targetUser._id));
  const partnerId = new mongoose.Types.ObjectId(session.uid);

  const doc = await UseRequest.create({
    userId,
    partnerId,
    amount: Math.abs(amount),
    status: "PENDING",
    note,
  });

  return NextResponse.json({
    ok: true,
    request: {
      id: doc._id.toString(),
      to: { username: targetUser.username, name: targetUser.name },
      amount: doc.amount,
      status: doc.status,
      note: doc.note,
      createdAt: doc.createdAt,
    },
  });
}