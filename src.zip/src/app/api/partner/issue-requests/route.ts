// src/app/api/partner/issue-requests/route.ts
// =======================================================
// PARTNER 전용: 내가 실행한 고객 포인트 지급 이력 조회
// =======================================================

import { NextResponse } from "next/server";
import mongoose from "mongoose";
import { getSessionFromCookies } from "@/lib/auth";
import { connectDB } from "@/lib/db";
import { IssueRequest } from "@/models/IssueRequest";
import { User } from "@/models/User";

export async function GET(req: Request) {
  const session = await getSessionFromCookies();

  if (!session) {
    return NextResponse.json(
      { ok: false, message: "로그인이 필요합니다." },
      { status: 401 }
    );
  }

  if (session.role !== "PARTNER") {
    return NextResponse.json(
      { ok: false, message: "제휴사만 접근 가능합니다." },
      { status: 403 }
    );
  }

  const { searchParams } = new URL(req.url);
  const statusParam = String(searchParams.get("status") ?? "ALL").toUpperCase();

  await connectDB();

  const filter: any = {
    requesterId: new mongoose.Types.ObjectId(session.uid),
  };

  if (["PENDING", "APPROVED", "REJECTED"].includes(statusParam)) {
    filter.status = statusParam;
  }

  const docs = await IssueRequest.find(filter)
    .sort({ createdAt: -1 })
    .limit(100);

  const items = await Promise.all(
    docs.map(async (d: any) => {
      const user = await User.findById(d.userId, { username: 1, name: 1 });

      return {
        id: String(d._id),
        status: d.status,
        amount: d.amount,
        note: d.note ?? "",
        createdAt: d.createdAt,
        decidedAt: d.decidedAt ?? null,
        ledgerId: d.ledgerId ? String(d.ledgerId) : null,
        to: user
          ? {
              username: user.username,
              name: user.name,
            }
          : null,
      };
    })
  );

  return NextResponse.json({ ok: true, items });
}