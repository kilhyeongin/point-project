// src/app/api/topup-requests/[id]/approve/route.ts
// =======================================================
// 비활성화된 레거시 API
// -------------------------------------------------------
// 충전 승인은 이제 /api/admin/topup-requests/[id]/approve 로만 처리합니다.
// 이 경로는 더 이상 사용하지 않습니다.
// =======================================================

import { NextResponse } from "next/server";
import { getSessionFromCookies } from "@/lib/auth";

export async function PATCH() {
  const session = await getSessionFromCookies();

  if (!session) {
    return NextResponse.json(
      { ok: false, message: "로그인이 필요합니다." },
      { status: 401 }
    );
  }

  return NextResponse.json(
    {
      ok: false,
      message:
        "이 경로는 더 이상 사용하지 않습니다. /api/admin/topup-requests/[id]/approve 경로를 사용하세요.",
    },
    { status: 410 }
  );
}