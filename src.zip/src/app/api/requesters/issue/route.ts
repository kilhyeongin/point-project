// src/app/api/requesters/issue/route.ts
// =======================================================
// 비활성화된 레거시 API
// -------------------------------------------------------
// 고객 포인트 지급은 이제 /api/issue-requests 에서
// PARTNER 즉시 실행 구조로 처리합니다.
// =======================================================

import { NextResponse } from "next/server";
import { getSessionFromCookies } from "@/lib/auth";

export async function POST() {
  const session = await getSessionFromCookies();

  if (!session) {
    return NextResponse.json(
      { ok: false, message: "로그인이 필요합니다." },
      { status: 401 }
    );
  }

  return NextResponse.json(
    {
      ok: false,
      message:
        "이 경로는 더 이상 사용하지 않습니다. 고객 포인트 지급은 /api/issue-requests 를 사용하세요.",
    },
    { status: 410 }
  );
}