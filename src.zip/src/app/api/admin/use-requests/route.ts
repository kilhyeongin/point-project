// src/app/api/admin/use-requests/route.ts
// =======================================================
// ADMIN 전용: 사용요청 목록 조회 API
// -------------------------------------------------------
// ✔ ADMIN만 접근
// ✔ 기본: PENDING 목록
// ✔ status 쿼리로 필터 가능 (?status=PENDING|APPROVED|REJECTED)
// =======================================================

import { NextResponse } from "next/server";
import { getSessionFromCookies } from "@/lib/auth";
import { connectDB } from "@/lib/db";
import { UseRequest } from "@/models/UseRequest";
import { User } from "@/models/User";

export async function GET(req: Request) {
  const session = await getSessionFromCookies();
  if (!session) {
    return NextResponse.json({ ok: false, message: "로그인이 필요합니다." }, { status: 401 });
  }
  if (session.role !== "ADMIN") {
    return NextResponse.json({ ok: false, message: "관리자 권한이 없습니다." }, { status: 403 });
  }

  const { searchParams } = new URL(req.url);
  const statusParam = String(searchParams.get("status") ?? "PENDING").toUpperCase();

  await connectDB();

  const filter: any = {};
  if (["PENDING", "APPROVED", "REJECTED"].includes(statusParam)) {
    filter.status = statusParam;
  }

  const docs = await UseRequest.find(filter).sort({ createdAt: -1 }).limit(50);

  const items = await Promise.all(
    docs.map(async (d: any) => {
      const user = await User.findById(d.userId, { username: 1, name: 1 });
      const partner = await User.findById(d.partnerId, { username: 1, name: 1 });

      return {
        id: d._id.toString(),
        status: d.status,
        amount: d.amount,
        note: d.note,
        createdAt: d.createdAt,
        to: user ? { username: user.username, name: user.name } : null,
        requester: partner ? { username: partner.username, name: partner.name } : null,
      };
    })
  );

  return NextResponse.json({ ok: true, items });
}