// src/app/api/admin/accounts/route.ts
// =======================================================
// ADMIN: 계정 잔액 조회 API
// -------------------------------------------------------
// ✔ 관리자만 접근
// ✔ Wallet 기준 현재 잔액 계산
// ✔ PARTNER / CUSTOMER / ADMIN 반환
// =======================================================

import { NextResponse } from "next/server";
import mongoose from "mongoose";
import { getSessionFromCookies } from "@/lib/auth";
import { connectDB } from "@/lib/db";
import { User } from "@/models/User";
import { getWalletBalancesMap } from "@/services/wallet";

export async function GET() {
  const session = await getSessionFromCookies();

  if (!session) {
    return NextResponse.json(
      { ok: false, message: "로그인이 필요합니다." },
      { status: 401 }
    );
  }

  if (session.role !== "ADMIN") {
    return NextResponse.json(
      { ok: false, message: "관리자만 접근 가능합니다." },
      { status: 403 }
    );
  }

  await connectDB();

  const users = await User.find(
    { status: { $in: ["ACTIVE", "PENDING", "BLOCKED"] } },
    { username: 1, name: 1, role: 1, status: 1, createdAt: 1 }
  ).sort({ createdAt: -1 });

  const userIds = users.map(
    (u: any) => new mongoose.Types.ObjectId(String(u._id))
  );

  const balanceMap = await getWalletBalancesMap(userIds);

  const items = users.map((u: any) => ({
    id: String(u._id),
    username: u.username,
    name: u.name,
    role: u.role,
    status: u.status,
    balance: balanceMap.get(String(u._id)) ?? 0,
  }));

  return NextResponse.json({
    ok: true,
    items,
  });
}