// src/app/api/admin/fee-policies/[id]/route.ts
// =======================================================
// ADMIN: 수수료 정책 단건 수정/삭제
// -------------------------------------------------------
// PATCH  : 수정
// DELETE : 삭제
// =======================================================

import { NextResponse } from "next/server";
import mongoose from "mongoose";
import { getSessionFromCookies } from "@/lib/auth";
import { connectDB } from "@/lib/db";
import { FeePolicy } from "@/models/FeePolicy";

function toDateOrNull(v: any): Date | null {
  if (v === null || v === undefined || v === "") return null;
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? null : d;
}

type Params = { params: Promise<{ id: string }> };

export async function PATCH(req: Request, { params }: Params) {
  const session = await getSessionFromCookies();
  if (!session) {
    return NextResponse.json({ ok: false, message: "로그인이 필요합니다." }, { status: 401 });
  }
  if (session.role !== "ADMIN") {
    return NextResponse.json({ ok: false, message: "관리자만 접근 가능합니다." }, { status: 403 });
  }

  const { id } = await params;
  if (!mongoose.Types.ObjectId.isValid(id)) {
    return NextResponse.json({ ok: false, message: "id가 올바르지 않습니다." }, { status: 400 });
  }

  let body: any = {};
  try {
    body = await req.json();
  } catch {
    body = {};
  }

  const feeRate = body?.feeRate !== undefined ? Number(body.feeRate) : undefined;
  const startAt = body?.startAt !== undefined ? toDateOrNull(body.startAt) : undefined;
  const endAt = body?.endAt !== undefined ? toDateOrNull(body.endAt) : undefined;
  const note = body?.note !== undefined ? String(body.note ?? "").trim() : undefined;

  const $set: any = {};
  if (feeRate !== undefined) {
    if (!Number.isFinite(feeRate) || feeRate < 0 || feeRate > 1) {
      return NextResponse.json({ ok: false, message: "feeRate는 0~1 사이 숫자여야 합니다." }, { status: 400 });
    }
    $set.feeRate = feeRate;
  }
  if (startAt !== undefined) {
    if (!startAt) {
      return NextResponse.json({ ok: false, message: "startAt이 올바르지 않습니다." }, { status: 400 });
    }
    $set.startAt = startAt;
  }
  if (endAt !== undefined) {
    // null 허용
    $set.endAt = endAt ?? null;
  }
  if (note !== undefined) {
    $set.note = note;
  }

  await connectDB();

  const before = await FeePolicy.findById(id, { startAt: 1, endAt: 1 });
  if (!before) {
    return NextResponse.json({ ok: false, message: "정책을 찾을 수 없습니다." }, { status: 404 });
  }

  const nextStart = $set.startAt ?? before.startAt;
  const nextEnd = $set.endAt === undefined ? before.endAt : $set.endAt;

  if (nextEnd && new Date(nextEnd).getTime() < new Date(nextStart).getTime()) {
    return NextResponse.json({ ok: false, message: "endAt은 startAt보다 빠를 수 없습니다." }, { status: 400 });
  }

  await FeePolicy.updateOne({ _id: id }, { $set });

  return NextResponse.json({ ok: true });
}

export async function DELETE(_req: Request, { params }: Params) {
  const session = await getSessionFromCookies();
  if (!session) {
    return NextResponse.json({ ok: false, message: "로그인이 필요합니다." }, { status: 401 });
  }
  if (session.role !== "ADMIN") {
    return NextResponse.json({ ok: false, message: "관리자만 접근 가능합니다." }, { status: 403 });
  }

  const { id } = await params;
  if (!mongoose.Types.ObjectId.isValid(id)) {
    return NextResponse.json({ ok: false, message: "id가 올바르지 않습니다." }, { status: 400 });
  }

  await connectDB();
  await FeePolicy.deleteOne({ _id: id });

  return NextResponse.json({ ok: true });
}