// src/app/api/admin/fee-policies/route.ts
// =======================================================
// ADMIN: 수수료 정책 CRUD (목록/생성)
// -------------------------------------------------------
// GET  : 목록 조회 (최신순)
// POST : 정책 생성
// =======================================================

import { NextResponse } from "next/server";
import mongoose from "mongoose";
import { getSessionFromCookies } from "@/lib/auth";
import { connectDB } from "@/lib/db";
import { FeePolicy } from "@/models/FeePolicy";
import { User } from "@/models/User";

function toDateOrNull(v: any): Date | null {
  if (v === null || v === undefined || v === "") return null;
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? null : d;
}

export async function GET(req: Request) {
  const session = await getSessionFromCookies();
  if (!session) {
    return NextResponse.json({ ok: false, message: "로그인이 필요합니다." }, { status: 401 });
  }
  if (session.role !== "ADMIN") {
    return NextResponse.json({ ok: false, message: "관리자만 접근 가능합니다." }, { status: 403 });
  }

  const { searchParams } = new URL(req.url);
  const q = String(searchParams.get("q") ?? "").trim();

  await connectDB();

  const filter: any = {};
  if (q) {
    // counterparty(업체) username/name 으로 검색
    const users = await User.find(
      {
        $and: [
          { role: "PARTNER" },
          {
            $or: [
              { username: { $regex: q, $options: "i" } },
              { name: { $regex: q, $options: "i" } },
            ],
          },
        ],
      },
      { _id: 1 }
    ).limit(50);

    const ids = users.map((u: any) => u._id);
    if (ids.length === 0) return NextResponse.json({ ok: true, items: [] });

    filter.counterpartyId = { $in: ids };
  }

  const docs = await FeePolicy.find(filter)
    .sort({ createdAt: -1 })
    .limit(300)
    .populate("counterpartyId", "username name role");

  const items = docs.map((d: any) => ({
    id: d._id.toString(),
    feeRate: Number(d.feeRate ?? 0),
    startAt: d.startAt,
    endAt: d.endAt,
    note: d.note ?? "",
    counterparty: d.counterpartyId
      ? {
          id: String(d.counterpartyId._id),
          username: d.counterpartyId.username,
          name: d.counterpartyId.name,
          role: d.counterpartyId.role,
        }
      : null,
    createdAt: d.createdAt,
    updatedAt: d.updatedAt,
  }));

  return NextResponse.json({ ok: true, items });
}

export async function POST(req: Request) {
  const session = await getSessionFromCookies();
  if (!session) {
    return NextResponse.json({ ok: false, message: "로그인이 필요합니다." }, { status: 401 });
  }
  if (session.role !== "ADMIN") {
    return NextResponse.json({ ok: false, message: "관리자만 접근 가능합니다." }, { status: 403 });
  }

  let body: any = {};
  try {
    body = await req.json();
  } catch {
    body = {};
  }

  const counterpartyId = String(body?.counterpartyId ?? "").trim();
  const feeRate = Number(body?.feeRate);
  const startAt = toDateOrNull(body?.startAt);
  const endAt = toDateOrNull(body?.endAt);
  const note = String(body?.note ?? "").trim();

  if (!counterpartyId || !mongoose.Types.ObjectId.isValid(counterpartyId)) {
    return NextResponse.json({ ok: false, message: "counterpartyId가 올바르지 않습니다." }, { status: 400 });
  }
  if (!Number.isFinite(feeRate) || feeRate < 0 || feeRate > 1) {
    return NextResponse.json({ ok: false, message: "feeRate는 0~1 사이 숫자여야 합니다. (예: 0.03)" }, { status: 400 });
  }
  if (!startAt) {
    return NextResponse.json({ ok: false, message: "startAt(시작일)이 필요합니다." }, { status: 400 });
  }
  if (endAt && endAt.getTime() < startAt.getTime()) {
    return NextResponse.json({ ok: false, message: "endAt은 startAt보다 빠를 수 없습니다." }, { status: 400 });
  }

  await connectDB();

  const user = await User.findById(counterpartyId, { role: 1, status: 1 });
  if (!user) {
    return NextResponse.json({ ok: false, message: "업체를 찾을 수 없습니다." }, { status: 404 });
  }
  if (String(user.role) !== "PARTNER") {
    return NextResponse.json({ ok: false, message: "제휴사만 등록 가능합니다." }, { status: 400 });
  }

  const doc = await FeePolicy.create({
    counterpartyId: new mongoose.Types.ObjectId(counterpartyId),
    feeRate,
    startAt,
    endAt: endAt ?? null,
    note,
  });

  return NextResponse.json({ ok: true, id: String(doc._id) });
}