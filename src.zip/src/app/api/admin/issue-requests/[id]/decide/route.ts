// src/app/api/admin/issue-requests/[id]/decide/route.ts
// =======================================================
// 비활성화된 레거시 API
// -------------------------------------------------------
// 예전에는 관리자 승인형 지급 요청 구조였지만,
// 현재는 제휴사가 잔액 범위 내에서 즉시 지급합니다.
// 따라서 관리자 승인/거절 기능은 더 이상 사용하지 않습니다.
// =======================================================

import { NextResponse } from "next/server";
import { getSessionFromCookies } from "@/lib/auth";

export async function PATCH() {
  const session = await getSessionFromCookies();

  if (!session) {
    return NextResponse.json(
      { ok: false, message: "로그인이 필요합니다." },
      { status: 401 }
    );
  }

  if (session.role !== "ADMIN") {
    return NextResponse.json(
      { ok: false, message: "관리자만 접근 가능합니다." },
      { status: 403 }
    );
  }

  return NextResponse.json(
    {
      ok: false,
      message:
        "이 기능은 더 이상 사용하지 않습니다. 고객 포인트 지급은 제휴사가 잔액 범위 내에서 즉시 실행합니다.",
    },
    { status: 410 }
  );
}