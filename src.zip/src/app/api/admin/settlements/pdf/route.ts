// src/app/api/admin/settlements/pdf/route.ts
// =======================================================
// ADMIN: 정산서 PDF
// -------------------------------------------------------
// - 수수료 없음
// - 지급액 = netPayable
// =======================================================

import { NextResponse } from "next/server";
import mongoose from "mongoose";
import { PDFDocument, StandardFonts } from "pdf-lib";
import { getSessionFromCookies } from "@/lib/auth";
import { connectDB } from "@/lib/db";
import { Settlement } from "@/models/Settlement";
import { User } from "@/models/User";

function formatNumber(n: number) {
  return Number(n || 0).toLocaleString();
}

export async function GET(req: Request) {
  const session = await getSessionFromCookies();

  if (!session || session.role !== "ADMIN") {
    return NextResponse.json(
      { ok: false, message: "관리자만 접근 가능합니다." },
      { status: 403 }
    );
  }

  const { searchParams } = new URL(req.url);
  const periodKey = String(searchParams.get("periodKey") ?? "").trim();
  const counterpartyId = String(searchParams.get("counterpartyId") ?? "").trim();

  if (!periodKey || !mongoose.Types.ObjectId.isValid(counterpartyId)) {
    return NextResponse.json(
      { ok: false, message: "periodKey / counterpartyId를 확인해주세요." },
      { status: 400 }
    );
  }

  await connectDB();

  const doc = await Settlement.findOne({
    periodKey,
    counterpartyId: new mongoose.Types.ObjectId(counterpartyId),
  }).lean();

  if (!doc) {
    return NextResponse.json(
      { ok: false, message: "정산 데이터를 찾을 수 없습니다." },
      { status: 404 }
    );
  }

  const counterparty = await User.findById(counterpartyId, {
    username: 1,
    name: 1,
  }).lean();

  const pdf = await PDFDocument.create();
  const page = pdf.addPage([595, 842]);
  const font = await pdf.embedFont(StandardFonts.Helvetica);

  let y = 790;

  function drawLine(text: string, size = 12) {
    page.drawText(text, {
      x: 50,
      y,
      size,
      font,
    });
    y -= size + 10;
  }

  function drawHr() {
    page.drawLine({
      start: { x: 50, y },
      end: { x: 545, y },
      thickness: 1,
    });
    y -= 18;
  }

  const partnerName = counterparty?.name ?? "-";
  const partnerUsername = counterparty?.username ?? "-";
  const useCount = Number((doc as any).useCount ?? 0);
  const usedPoints = Number((doc as any).usedPoints ?? 0);
  const netPayable = Number((doc as any).netPayable ?? usedPoints);
  const status = String((doc as any).status ?? "");

  drawLine("Settlement Statement", 18);
  drawLine(`Period: ${periodKey}`, 12);
  drawHr();

  drawLine(`Partner: ${partnerName} (${partnerUsername})`, 12);
  drawLine(`Status: ${status}`, 12);
  drawLine(`Use Count: ${formatNumber(useCount)}`, 12);
  drawLine(`Used Points: ${formatNumber(usedPoints)}P`, 12);
  drawHr();

  drawLine(`Payable Amount: ${formatNumber(netPayable)}P`, 14);

  const pdfBytes = await pdf.save();
  const body = Buffer.from(pdfBytes);

  return new NextResponse(body, {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `inline; filename="settlement-${periodKey}-${partnerUsername}.pdf"`,
    },
  });
}