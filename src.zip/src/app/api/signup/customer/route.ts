import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { connectDB } from "@/lib/db";
import { User } from "@/models/User";

function text(value: unknown, max = 100) {
  return String(value ?? "").trim().slice(0, max);
}

function normalizeUsername(value: unknown) {
  return String(value ?? "").trim().toLowerCase().slice(0, 30);
}

function normalizePhone(value: unknown) {
  return String(value ?? "")
    .replace(/[^\d\-+\s()]/g, "")
    .trim()
    .slice(0, 30);
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    const name = text(body?.name, 50);
    const username = normalizeUsername(body?.username);
    const password = String(body?.password ?? "");
    const passwordConfirm = String(body?.passwordConfirm ?? "");
    const phone = normalizePhone(body?.phone);
    const address = text(body?.address, 200);
    const detailAddress = text(body?.detailAddress, 200);

    if (!name) {
      return NextResponse.json({ ok: false, error: "이름을 입력해 주세요." }, { status: 400 });
    }

    if (!username || username.length < 4) {
      return NextResponse.json({ ok: false, error: "아이디는 4자 이상 입력해 주세요." }, { status: 400 });
    }

    if (!password || password.length < 4) {
      return NextResponse.json({ ok: false, error: "비밀번호는 4자 이상 입력해 주세요." }, { status: 400 });
    }

    if (password !== passwordConfirm) {
      return NextResponse.json({ ok: false, error: "비밀번호 확인이 일치하지 않습니다." }, { status: 400 });
    }

    if (!phone) {
      return NextResponse.json({ ok: false, error: "전화번호를 입력해 주세요." }, { status: 400 });
    }

    if (!address) {
      return NextResponse.json({ ok: false, error: "주소를 입력해 주세요." }, { status: 400 });
    }

    await connectDB();

    const exists = await User.findOne({ username }, { _id: 1 }).lean();
    if (exists) {
      return NextResponse.json({ ok: false, error: "이미 사용 중인 아이디입니다." }, { status: 409 });
    }

    const passwordHash = await bcrypt.hash(password, 10);

    await User.create({
      username,
      passwordHash,
      name,
      role: "CUSTOMER",
      status: "ACTIVE",
      pointBalance: 0,
      customerProfile: {
        phone,
        address,
        detailAddress,
        onboardingCompleted: false,
        interests: [],
      },
    });

    return NextResponse.json({
      ok: true,
      message: "고객 회원가입이 완료되었습니다.",
    });
  } catch (error) {
    console.error("[CUSTOMER_SIGNUP_POST_ERROR]", error);
    return NextResponse.json(
      { ok: false, error: "고객 회원가입에 실패했습니다." },
      { status: 500 }
    );
  }
}