// src/app/api/me/debug/route.ts
import { NextResponse } from "next/server";
import { getSessionFromCookies } from "@/lib/auth";

export async function GET() {
  const session = await getSessionFromCookies();
  return NextResponse.json({
    ok: true,
    session,
  });
}