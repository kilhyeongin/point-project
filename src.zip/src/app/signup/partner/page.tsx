"use client";

import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function PartnerSignupPage() {
  const router = useRouter();

  const [form, setForm] = useState({
    businessName: "",
    contactName: "",
    username: "",
    password: "",
    passwordConfirm: "",
    contactPhone: "",
    address: "",
    detailAddress: "",
  });

  const [msg, setMsg] = useState("");
  const [saving, setSaving] = useState(false);

  async function submit() {
    setSaving(true);
    setMsg("");

    try {
      const res = await fetch("/api/signup/partner", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });

      const data = await res.json();

      if (!res.ok || !data?.ok) {
        setMsg(data?.error ?? "회원가입에 실패했습니다.");
        return;
      }

      alert("제휴사 가입이 완료되었습니다. 관리자 승인 후 이용 가능합니다.");
      router.push("/login");
    } catch {
      setMsg("네트워크 오류");
    } finally {
      setSaving(false);
    }
  }

  return (
    <main style={pageStyle}>
      <section style={boxStyle}>
        <div>
          <div style={eyebrowStyle}>제휴사 회원가입</div>
          <h1 style={titleStyle}>업체 정보 입력</h1>
          <p style={descStyle}>
            제휴사는 가입 후 승인대기 상태로 등록되며, 관리자 승인 후 이용할 수 있습니다.
          </p>
        </div>

        <div style={gridStyle}>
          <input
            placeholder="업체명"
            value={form.businessName}
            onChange={(e) => setForm({ ...form, businessName: e.target.value })}
            style={inputStyle}
          />
          <input
            placeholder="담당자명"
            value={form.contactName}
            onChange={(e) => setForm({ ...form, contactName: e.target.value })}
            style={inputStyle}
          />
          <input
            placeholder="아이디"
            value={form.username}
            onChange={(e) => setForm({ ...form, username: e.target.value })}
            style={inputStyle}
          />
          <input
            type="password"
            placeholder="비밀번호"
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            style={inputStyle}
          />
          <input
            type="password"
            placeholder="비밀번호 확인"
            value={form.passwordConfirm}
            onChange={(e) =>
              setForm({ ...form, passwordConfirm: e.target.value })
            }
            style={inputStyle}
          />
          <input
            placeholder="담당자 전화번호"
            value={form.contactPhone}
            onChange={(e) => setForm({ ...form, contactPhone: e.target.value })}
            style={inputStyle}
          />
          <input
            placeholder="업체 주소"
            value={form.address}
            onChange={(e) => setForm({ ...form, address: e.target.value })}
            style={inputStyle}
          />
          <input
            placeholder="상세주소(선택)"
            value={form.detailAddress}
            onChange={(e) =>
              setForm({ ...form, detailAddress: e.target.value })
            }
            style={inputStyle}
          />
        </div>

        {msg ? <div style={errorStyle}>{msg}</div> : null}

        <div style={{ display: "flex", gap: 10 }}>
          <button onClick={submit} disabled={saving} style={primaryButton}>
            {saving ? "가입 중..." : "회원가입"}
          </button>
          <Link href="/signup" style={secondaryButton}>
            이전
          </Link>
        </div>
      </section>
    </main>
  );
}

const pageStyle = {
  minHeight: "100vh",
  display: "grid",
  placeItems: "center",
  background: "#f8fafc",
  padding: 24,
};

const boxStyle = {
  width: "100%",
  maxWidth: 720,
  background: "#fff",
  border: "1px solid #e5e7eb",
  borderRadius: 24,
  padding: 28,
  display: "grid",
  gap: 20,
};

const eyebrowStyle = { fontSize: 13, fontWeight: 800, color: "#6b7280" };
const titleStyle = { margin: "8px 0 0", fontSize: 28, fontWeight: 900 };
const descStyle = { marginTop: 10, color: "#4b5563", lineHeight: 1.6 };

const gridStyle = {
  display: "grid",
  gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
  gap: 12,
};

const inputStyle = {
  height: 46,
  borderRadius: 12,
  border: "1px solid #d1d5db",
  padding: "0 12px",
};

const errorStyle = {
  padding: 12,
  borderRadius: 12,
  border: "1px solid #fecaca",
  background: "#fef2f2",
  color: "#991b1b",
  fontWeight: 700,
};

const primaryButton = {
  height: 46,
  padding: "0 16px",
  borderRadius: 12,
  border: "1px solid #111827",
  background: "#111827",
  color: "#fff",
  fontWeight: 800,
};

const secondaryButton = {
  height: 46,
  padding: "0 16px",
  borderRadius: 12,
  border: "1px solid #d1d5db",
  background: "#fff",
  color: "#111827",
  fontWeight: 800,
  textDecoration: "none",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
};