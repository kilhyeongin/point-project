"use client";

import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function CustomerSignupPage() {
  const router = useRouter();

  const [form, setForm] = useState({
    name: "",
    username: "",
    password: "",
    passwordConfirm: "",
    phone: "",
    address: "",
    detailAddress: "",
  });

  const [msg, setMsg] = useState("");
  const [saving, setSaving] = useState(false);

  async function submit() {
    setSaving(true);
    setMsg("");

    try {
      const res = await fetch("/api/signup/customer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });

      const data = await res.json();

      if (!res.ok || !data?.ok) {
        setMsg(data?.error ?? "회원가입에 실패했습니다.");
        return;
      }

      alert("회원가입이 완료되었습니다. 로그인해 주세요.");
      router.push("/login");
    } catch {
      setMsg("네트워크 오류");
    } finally {
      setSaving(false);
    }
  }

  return (
    <main style={pageStyle}>
      <section style={boxStyle}>
        <div>
          <div style={eyebrowStyle}>일반 고객 회원가입</div>
          <h1 style={titleStyle}>고객 정보 입력</h1>
          <p style={descStyle}>
            가입 후 관심사를 선택하고 추천 제휴사를 확인할 수 있습니다.
          </p>
        </div>

        <div style={gridStyle}>
          <input
            placeholder="이름"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            style={inputStyle}
          />
          <input
            placeholder="아이디"
            value={form.username}
            onChange={(e) => setForm({ ...form, username: e.target.value })}
            style={inputStyle}
          />
          <input
            type="password"
            placeholder="비밀번호"
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            style={inputStyle}
          />
          <input
            type="password"
            placeholder="비밀번호 확인"
            value={form.passwordConfirm}
            onChange={(e) =>
              setForm({ ...form, passwordConfirm: e.target.value })
            }
            style={inputStyle}
          />
          <input
            placeholder="전화번호"
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
            style={inputStyle}
          />
          <input
            placeholder="주소"
            value={form.address}
            onChange={(e) => setForm({ ...form, address: e.target.value })}
            style={inputStyle}
          />
          <input
            placeholder="상세주소(선택)"
            value={form.detailAddress}
            onChange={(e) =>
              setForm({ ...form, detailAddress: e.target.value })
            }
            style={{ ...inputStyle, gridColumn: "1 / -1" }}
          />
        </div>

        {msg ? <div style={errorStyle}>{msg}</div> : null}

        <div style={{ display: "flex", gap: 10 }}>
          <button onClick={submit} disabled={saving} style={primaryButton}>
            {saving ? "가입 중..." : "회원가입"}
          </button>
          <Link href="/signup" style={secondaryButton}>
            이전
          </Link>
        </div>
      </section>
    </main>
  );
}

const pageStyle = {
  minHeight: "100vh",
  display: "grid",
  placeItems: "center",
  background: "#f8fafc",
  padding: 24,
};

const boxStyle = {
  width: "100%",
  maxWidth: 720,
  background: "#fff",
  border: "1px solid #e5e7eb",
  borderRadius: 24,
  padding: 28,
  display: "grid",
  gap: 20,
};

const eyebrowStyle = { fontSize: 13, fontWeight: 800, color: "#6b7280" };
const titleStyle = { margin: "8px 0 0", fontSize: 28, fontWeight: 900 };
const descStyle = { marginTop: 10, color: "#4b5563", lineHeight: 1.6 };

const gridStyle = {
  display: "grid",
  gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
  gap: 12,
};

const inputStyle = {
  height: 46,
  borderRadius: 12,
  border: "1px solid #d1d5db",
  padding: "0 12px",
};

const errorStyle = {
  padding: 12,
  borderRadius: 12,
  border: "1px solid #fecaca",
  background: "#fef2f2",
  color: "#991b1b",
  fontWeight: 700,
};

const primaryButton = {
  height: 46,
  padding: "0 16px",
  borderRadius: 12,
  border: "1px solid #111827",
  background: "#111827",
  color: "#fff",
  fontWeight: 800,
};

const secondaryButton = {
  height: 46,
  padding: "0 16px",
  borderRadius: 12,
  border: "1px solid #d1d5db",
  background: "#fff",
  color: "#111827",
  fontWeight: 800,
  textDecoration: "none",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
};