import Link from "next/link";

export default function SignupSelectPage() {
  return (
    <main
      style={{
        minHeight: "100vh",
        display: "grid",
        placeItems: "center",
        background: "#f8fafc",
        padding: 24,
      }}
    >
      <section
        style={{
          width: "100%",
          maxWidth: 760,
          background: "#fff",
          border: "1px solid #e5e7eb",
          borderRadius: 24,
          padding: 28,
          boxShadow: "0 10px 30px rgba(15,23,42,0.06)",
          display: "grid",
          gap: 20,
        }}
      >
        <div>
          <div style={{ fontSize: 13, fontWeight: 800, color: "#6b7280" }}>
            회원가입
          </div>
          <h1 style={{ margin: "8px 0 0", fontSize: 30, fontWeight: 900 }}>
            가입 유형을 선택해 주세요
          </h1>
          <p style={{ marginTop: 10, color: "#4b5563", lineHeight: 1.6 }}>
            일반 고객과 제휴사는 가입 정보와 가입 후 진행 흐름이 다릅니다.
          </p>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
            gap: 16,
          }}
        >
          <Link href="/signup/customer" style={cardStyle}>
            <strong style={{ fontSize: 20 }}>일반 고객 가입</strong>
            <span style={descStyle}>
              추천 제휴사 확인, 관심사 선택, 포인트/혜택 이용
            </span>
          </Link>

          <Link href="/signup/partner" style={cardStyle}>
            <strong style={{ fontSize: 20 }}>제휴사 가입</strong>
            <span style={descStyle}>
              업체 등록 후 관리자 승인, 고객 연결 및 혜택 운영
            </span>
          </Link>
        </div>
      </section>
    </main>
  );
}

const cardStyle = {
  border: "1px solid #e5e7eb",
  borderRadius: 20,
  padding: 24,
  textDecoration: "none",
  color: "#111827",
  background: "#fff",
  display: "grid",
  gap: 10,
};

const descStyle = {
  color: "#6b7280",
  lineHeight: 1.6,
};