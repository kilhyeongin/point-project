// src/app/(auth)/login/page.tsx
// 로그인 페이지 (username 기반)
// - /api/auth/login 호출
// - 성공하면 / 로 이동

"use client";

import { useState } from "react";

export default function LoginPage() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setMsg(null);
    setLoading(true);

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });

      const data = await res.json();

      if (!res.ok) {
        setMsg(data?.message ?? "로그인 실패");
        return;
      }

      // 로그인 성공 -> 홈으로 이동
      window.location.href = "/";
    } catch {
      setMsg("네트워크 오류");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ maxWidth: 420, margin: "40px auto", padding: 16 }}>
      <h1 style={{ fontSize: 22, fontWeight: 700, marginBottom: 16 }}>로그인</h1>

      <form onSubmit={onSubmit} style={{ display: "grid", gap: 12 }}>
        <label style={{ display: "grid", gap: 6 }}>
          <span>아이디</span>
          <input
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            placeholder="아이디 입력"
            required
            style={{ padding: 10, border: "1px solid #444", borderRadius: 10 }}
          />
        </label>

        <label style={{ display: "grid", gap: 6 }}>
          <span>비밀번호</span>
          <input
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            type="password"
            placeholder="••••••••"
            required
            style={{ padding: 10, border: "1px solid #444", borderRadius: 10 }}
          />
        </label>

        <button
          disabled={loading}
          type="submit"
          style={{
            padding: 12,
            borderRadius: 12,
            border: "none",
            background: "#fff",
            color: "#000",
            fontWeight: 700,
            cursor: "pointer",
            opacity: loading ? 0.6 : 1,
          }}
        >
          {loading ? "로그인 중..." : "로그인"}
        </button>

        {msg && <p style={{ color: "tomato", margin: 0 }}>{msg}</p>}

        <a href="/signup" style={{ color: "#bbb", fontSize: 14 }}>
          회원가입 하러가기 →
        </a>
      </form>
    </div>
  );
}