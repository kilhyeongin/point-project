// src/models/FavoritePartner.ts
// =======================================================
// CUSTOMER ↔ PARTNER 관계 모델
// -------------------------------------------------------
// - 고객이 제휴사를 찜하면 LIKED
// - 고객이 제휴사에 신청하면 APPLIED
// - customerId + partnerId 복합 유니크
// =======================================================

import mongoose, { Schema, model, models } from "mongoose";

export type FavoritePartnerStatus = "LIKED" | "APPLIED";

export interface IFavoritePartner {
  customerId: mongoose.Types.ObjectId;
  partnerId: mongoose.Types.ObjectId;
  status: FavoritePartnerStatus;
  createdAt: Date;
  updatedAt: Date;
  appliedAt?: Date | null;
}

const FavoritePartnerSchema = new Schema<IFavoritePartner>(
  {
    customerId: {
      type: Schema.Types.ObjectId,
      ref: "User",
      required: true,
      index: true,
    },

    partnerId: {
      type: Schema.Types.ObjectId,
      ref: "User",
      required: true,
      index: true,
    },

    status: {
      type: String,
      enum: ["LIKED", "APPLIED"],
      default: "LIKED",
      required: true,
      index: true,
    },

    appliedAt: {
      type: Date,
      default: null,
    },
  },
  {
    timestamps: true,
  }
);

FavoritePartnerSchema.index({ customerId: 1, partnerId: 1 }, { unique: true });
FavoritePartnerSchema.index({ partnerId: 1, status: 1, createdAt: -1 });
FavoritePartnerSchema.index({ customerId: 1, status: 1, createdAt: -1 });

export const FavoritePartner =
  models.FavoritePartner ||
  model<IFavoritePartner>("FavoritePartner", FavoritePartnerSchema);
