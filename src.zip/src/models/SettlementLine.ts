// src/models/SettlementLine.ts
// =======================================================
// 정산 라인(업체별 집계) 모델
// -------------------------------------------------------
// ✔ 마감된 periodKey에 대해 counterparty(업체)별 사용포인트를 고정 저장한다.
// ✔ 이후 엑셀/지급/증빙은 이 데이터를 기준으로 한다.
// =======================================================

import mongoose, { Schema, model, models } from "mongoose";

export type SettlementLineStatus = "OPEN" | "PAID";

const SettlementLineSchema = new Schema(
  {
    periodKey: { type: String, required: true, index: true },

    // 정산 대상(제휴사)
    counterpartyId: {
      type: Schema.Types.ObjectId,
      ref: "User",
      required: true,
      index: true,
    },

    // 집계값
    useCount: { type: Number, default: 0 },
    usedPoints: { type: Number, default: 0 },

    // (선택) 수수료/지급액: 지금은 0으로 두고 확장 가능
    feeRate: { type: Number, default: 0 }, // 예: 0.05
    feeAmount: { type: Number, default: 0 }, // usedPoints * feeRate 같은 계산값
    netPayable: { type: Number, default: 0 }, // usedPoints - feeAmount (혹은 KRW 환산 후 금액)

    status: { type: String, enum: ["OPEN", "PAID"], default: "OPEN", index: true },

    // 지급 처리
    paidAt: { type: Date, default: null },
    paidById: { type: Schema.Types.ObjectId, ref: "User", default: null, index: true },
    payoutRef: { type: String, default: "" }, // 은행거래번호/송금ID 등
    note: { type: String, default: "" },
  },
  { timestamps: true }
);

// periodKey + counterpartyId 유니크 (한 달에 업체 1줄)
SettlementLineSchema.index({ periodKey: 1, counterpartyId: 1 }, { unique: true });

export const SettlementLine =
  models.SettlementLine || model("SettlementLine", SettlementLineSchema);