// src/models/FeePolicy.ts
// =======================================================
// 수수료 정책 테이블
// -------------------------------------------------------
// ✔ 업체별 계약 feeRate 저장
// ✔ 기간별 계약 가능
// ✔ SettlementClose 시 자동 적용
// =======================================================

import mongoose, { Schema, model, models } from "mongoose";

const FeePolicySchema = new Schema(
  {
    counterpartyId: {
      type: Schema.Types.ObjectId,
      ref: "User",
      required: true,
      index: true,
    },

    feeRate: {
      type: Number,
      required: true,
      default: 0,
    },

    startAt: {
      type: Date,
      required: true,
    },

    endAt: {
      type: Date,
      default: null,
    },

    note: {
      type: String,
      default: "",
    },
  },
  { timestamps: true }
);

export const FeePolicy =
  models.FeePolicy || model("FeePolicy", FeePolicySchema);