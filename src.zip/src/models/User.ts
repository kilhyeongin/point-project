import { Schema, models, model } from "mongoose";

export type UserRole = "ADMIN" | "HOST" | "PARTNER" | "CUSTOMER";
export type UserStatus = "ACTIVE" | "PENDING" | "BLOCKED";

const CustomerProfileSchema = new Schema(
  {
    phone: {
      type: String,
      default: "",
      trim: true,
    },
    address: {
      type: String,
      default: "",
      trim: true,
    },
    detailAddress: {
      type: String,
      default: "",
      trim: true,
    },
    onboardingCompleted: {
      type: Boolean,
      default: false,
      index: true,
    },
    interests: {
      type: [String],
      default: [],
    },
  },
  { _id: false }
);

const PartnerProfileSchema = new Schema(
  {
    businessName: {
      type: String,
      default: "",
      trim: true,
    },
    contactName: {
      type: String,
      default: "",
      trim: true,
    },
    contactPhone: {
      type: String,
      default: "",
      trim: true,
    },
    address: {
      type: String,
      default: "",
      trim: true,
    },
    detailAddress: {
      type: String,
      default: "",
      trim: true,
    },
    category: {
      type: String,
      default: "",
      trim: true,
    },
    categories: {
      type: [String],
      default: [],
    },
    intro: {
      type: String,
      default: "",
      trim: true,
    },
    benefitText: {
      type: String,
      default: "",
      trim: true,
    },
    kakaoChannelUrl: {
      type: String,
      default: "",
      trim: true,
    },
    applyUrl: {
      type: String,
      default: "",
      trim: true,
    },
    phone: {
      type: String,
      default: "",
      trim: true,
    },
    coverImageUrl: {
      type: String,
      default: "",
      trim: true,
    },
    isPublished: {
      type: Boolean,
      default: false,
      index: true,
    },
  },
  { _id: false }
);

const UserSchema = new Schema(
  {
    username: {
      type: String,
      required: true,
      unique: true,
      index: true,
      trim: true,
      lowercase: true,
    },
    passwordHash: {
      type: String,
      required: true,
    },
    name: {
      type: String,
      required: true,
      trim: true,
    },
    role: {
      type: String,
      required: true,
      enum: ["ADMIN", "HOST", "PARTNER", "CUSTOMER"],
      index: true,
    },
    status: {
      type: String,
      required: true,
      enum: ["ACTIVE", "PENDING", "BLOCKED"],
      default: "ACTIVE",
      index: true,
    },
    pointBalance: {
      type: Number,
      default: 0,
      min: 0,
    },
    customerProfile: {
      type: CustomerProfileSchema,
      default: () => ({}),
    },
    partnerProfile: {
      type: PartnerProfileSchema,
      default: () => ({}),
    },
  },
  {
    timestamps: true,
  }
);

UserSchema.index({ role: 1, status: 1 });
UserSchema.index({ role: 1, "partnerProfile.isPublished": 1 });
UserSchema.index({ role: 1, "partnerProfile.categories": 1 });

export const User = models.User || model("User", UserSchema);